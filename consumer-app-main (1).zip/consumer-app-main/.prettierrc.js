// Prettier configuration
// https://prettier.io/docs/en/configuration.html
module.exports = {
  bracketSpacing: true,
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'all',
  semi: true,
};
