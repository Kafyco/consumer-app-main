import { UoM } from 'api/models';

export const getUnitsName = (unit: UoM) => {};

export const getUnitsSymbol = (unit: UoM) => (unit ? unit?.symbol?.toLowerCase() : '');

export const getUnitsBareSymbol = (unit: UoM) =>
  unit && !unit?.allowBareNumber ? unit?.symbol.toLowerCase() : '';
