import { Address as AddressType } from 'api/models';

const getAddressLine = (info: AddressType) => {
  const { line1, line3 } = info;
  return [line1, line3].filter((a) => !!a).join(', ');
};

export default getAddressLine;
