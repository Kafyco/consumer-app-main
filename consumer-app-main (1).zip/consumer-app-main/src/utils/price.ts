export const priceAmount = (amount: number | string) =>
  amount ? (typeof amount === 'string' ? parseFloat(amount) : amount).toFixed(2) : '0.00';

export const priceWithCurrency = (currency: string, amount: number | string) =>
  `${(currency ?? '').toUpperCase()} ${priceAmount(amount)}`;

export const priceFunctionFactory = (currency: string) => (amount: number | string) =>
  priceWithCurrency(currency, amount);
