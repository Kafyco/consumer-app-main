import * as Updates from 'expo-updates';

type EnvironmentVariables = {
  envName: 'PRODUCTION' | 'STAGING' | 'DEVELOPMENT';
  apiBaseUrl: string;
};

let environment: EnvironmentVariables;

export const ENV_PRODUCTION = 'PRODUCTION';
export const ENV_STAGING = 'STAGING';
export const ENV_DEVELOPMENT = 'DEVELOPMENT';

export const getEnvironment = (): EnvironmentVariables => {
  if (environment) {
    return environment;
  }

  if (Updates.channel === 'production') {
    environment = {
      envName: ENV_PRODUCTION,
      apiBaseUrl: 'https://api.kafy.co',
    };
  } else if (Updates.channel === 'preview') {
    environment = {
      envName: ENV_STAGING,
      apiBaseUrl: 'https://api.dev.kafy.co',
    };
  } else {
    // assume any other release channel is development
    environment = {
      envName: ENV_DEVELOPMENT,
      // apiBaseUrl: 'http://localhost:880',
      apiBaseUrl: 'https://api.kafy.co',
    };
  }

  return environment;
};

export const isEnvironmentName = (names: string | string[]) => {
  const env = getEnvironment();
  let comparison = names;

  if (typeof names === 'string') {
    comparison = [names];
  }

  return comparison.includes(env.envName);
};

export const getEnvironmentProp = (key: string) => {
  return getEnvironment()[key];
};

export default getEnvironment;
