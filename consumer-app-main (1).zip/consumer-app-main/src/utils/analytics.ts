// { init, track, setUserId, reset }
import * as Amplitude from '@amplitude/analytics-react-native';
// import * as Amplitude from 'expo-analytics-amplitude';
import Constants from 'expo-constants';

import { isEnvironmentName, ENV_PRODUCTION, ENV_STAGING } from './environment';

export type TrackingOptions = {
  [name: string]: any;
};

let isInitialized = false;
const apiKey = Constants.expoConfig?.extra?.amplitudeApiKey;
const canUseAmplitude = isEnvironmentName([ENV_PRODUCTION, ENV_STAGING]) && apiKey;

export const initialize = async (): Promise<void> => {
  if (isInitialized || !canUseAmplitude) {
    return;
  }

  await Amplitude.init(apiKey);
  isInitialized = true;
};

export const identify = async (id: string | null, options?: TrackingOptions): Promise<void> => {
  initialize();

  if (!canUseAmplitude) {
    return;
  }

  if (id) {
    await Amplitude.setUserId(id);

    if (options) {
      const identifyObj = new Amplitude.Identify();

      Object.entries(options).forEach(([key, value]) => {
        identifyObj.set(key, value);
      });

      await Amplitude.identify(identifyObj);
    }
  } else {
    await Amplitude.reset();
  }
};

export const logEvent = async (event: string, options?: TrackingOptions): Promise<void> => {
  initialize();

  if (!canUseAmplitude) {
    return;
  }

  await Amplitude.track(event, options);
};

export const logScreenView = async (
  screenName: string,
  options?: TrackingOptions,
): Promise<void> => {
  initialize();

  if (!canUseAmplitude) {
    return;
  }

  logEvent('SCREEN', {
    screenName,
    options,
  });
};
