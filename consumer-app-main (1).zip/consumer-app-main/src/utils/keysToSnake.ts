import camelToSnake from './camelToSnake';
import keysTransformer from './keysTransformer';

const keysToSnake = (obj: any) => keysTransformer(camelToSnake, obj);

export default keysToSnake;
