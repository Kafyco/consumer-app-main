import parsePhoneNumber, {
  findPhoneNumbersInText,
  isValidPhoneNumber,
  CountryCode,
} from 'libphonenumber-js';

export const validatePhoneNumber = (phoneNumber: string | undefined, countryCode?: CountryCode) =>
  isValidPhoneNumber(phoneNumber ?? '', countryCode ?? 'QA');

export const getFullNumber = (phoneNumber: string | undefined, countryCode?: CountryCode) =>
  parsePhoneNumber(phoneNumber ?? '', countryCode ?? 'QA')?.number;

export const getLocalPhoneNumber = (phoneNumber: string) => {
  const numbers = findPhoneNumbersInText(phoneNumber);

  if (numbers?.length) {
    const { number } = numbers[0];
    return number.nationalNumber;
  }

  return [];
};

export const getCountryCodeFromNumber = (phoneNumber: string) =>
  parsePhoneNumber(phoneNumber)?.country;
