import { Address as AddressType } from 'api/models';

const getAddressName = (info: AddressType) => {
  const { addressName, line1 } = info;
  return addressName || line1;
};

export default getAddressName;
