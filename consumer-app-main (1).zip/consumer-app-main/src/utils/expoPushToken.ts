import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import * as Sentry from 'sentry-expo';

import { registerUserToken, unregisterUserToken } from 'api/index';

// const projectId = '@supplymeapp/portal';

export const registerExpoPushToken = async () => {
  try {
    const { data } = await Notifications.getExpoPushTokenAsync({
      projectId: Constants.expoConfig?.extra?.eas.projectId,
    });

    if (__DEV__) {
      console.log('Push Token:', data);
    }

    await registerUserToken(data);
  } catch (err) {
    Sentry.Native.captureException(err);
  }
};

export const unregisterExpoToken = async () => {
  try {
    const { data } = await Notifications.getExpoPushTokenAsync({
      projectId: Constants.expoConfig?.extra?.eas.projectId,
    });

    await unregisterUserToken(data);
  } catch (err) {
    Sentry.Native.captureException(err);
  }
};
