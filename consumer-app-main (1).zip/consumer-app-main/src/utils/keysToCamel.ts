import snakeToCamel from './snakeToCamel';
import keysTransformer from './keysTransformer';

const keysToCamel = (obj: any) => keysTransformer(snakeToCamel, obj);

export default keysToCamel;
