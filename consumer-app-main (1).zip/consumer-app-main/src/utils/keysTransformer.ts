const keyTransformer = (trasformer: Function, obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map((val) => keyTransformer(trasformer, val));
  }

  if (typeof obj === 'object' && Object(obj) === obj) {
    return Object.keys(obj).reduce((res, key) => {
      res[trasformer(key)] = keyTransformer(trasformer, obj[key]);
      return res;
    }, {});
  }

  return obj;
};

export default keyTransformer;
