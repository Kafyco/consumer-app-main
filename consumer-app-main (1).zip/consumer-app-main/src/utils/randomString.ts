// => 27cd07c78229
const randomString = (): string => Math.random().toString(16).slice(-12);

export default randomString;
