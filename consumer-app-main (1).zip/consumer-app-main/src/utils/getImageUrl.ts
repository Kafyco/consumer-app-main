import { PixelRatio } from 'react-native';

const getMultiplier = (() => {
  const pixelRatio = PixelRatio.get();
  let multiplier = 1;

  if (pixelRatio > 1) {
    multiplier = 2;
  }
  // if (pixelRatio > 2) {
  //   multiplier = 3;
  // }

  return () => multiplier;
})();

/**
 *
 */
const getImageUrl = (source: any, size: string) => {
  const multiplier = `x${getMultiplier()}`;
  return source?.[size]?.[multiplier];
};

export default getImageUrl;
