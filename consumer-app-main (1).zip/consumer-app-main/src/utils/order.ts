import { ORDER_DELIVERED, ORDER_CANCELED, ORDER_FAILED } from 'constants/Order';

export const getStatusColorName = (status: string) => {
  switch (status) {
    case ORDER_DELIVERED:
      return 'regular';
    case ORDER_CANCELED:
    case ORDER_FAILED:
      return 'danger';
    default:
      return 'success';
  }
};
