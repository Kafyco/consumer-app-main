import * as React from 'react';

import { Partner } from 'api/models';

type MerchantContextType = {
  merchant?: Partner;
  merchantId: string;
};

const defaultValues = {
  merchant: undefined,
  merchantId: '',
};

const MerchantContext = React.createContext<MerchantContextType>(defaultValues);

type MerchantContextProps = MerchantContextType & { children: React.ReactNode };

export const MerchantContextProvider = ({
  children,
  merchant,
  merchantId,
}: MerchantContextProps) => (
  <MerchantContext.Provider value={{ merchant, merchantId }}>{children}</MerchantContext.Provider>
);

export const useMerchant = () => React.useContext(MerchantContext);
