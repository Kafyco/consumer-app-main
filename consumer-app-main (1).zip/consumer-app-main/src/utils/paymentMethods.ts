import dayjs from 'dayjs';
import {
  PaymentMethod,
  Bankcard,
  CheckoutPayment,
  Transaction,
  Order as OrderType,
} from 'api/models';
import { CARD_PAYMENT_CODES } from 'constants/Payments';

export type GroupedPaymentMethod = {
  code: string;
  options?: Bankcard[];
};

export type OrderPaymentMethod = {
  code: string;
  info?: Bankcard;
};

export const populatePaymentMethods = (
  merchantMethods: PaymentMethod[] = [],
  userMethods: Bankcard[] = [],
) => {
  const methods = Array.from(merchantMethods);

  return (
    methods
      // Move card options on top
      .sort((a) => (CARD_PAYMENT_CODES.includes(a.code) ? -1 : 1))
      // Serialize available methods into options list.
      .reduce<GroupedPaymentMethod[]>((results, { code }) => {
        if (CARD_PAYMENT_CODES.includes(code)) {
          let options = userMethods.filter((item) => item.sourceTypeCode === code);

          results.push({ code, options });
        } else {
          results.push({ code });
        }

        return results;
      }, [])
  );
};

export const paymentMethodExists = (data: GroupedPaymentMethod[], search: CheckoutPayment) => {
  const method = data.find((group) => group.code === search.method);
  let exists = !!method;

  if (method && search.cardId) {
    exists = !!method.options?.find((item) => item.id === search.cardId);
  }

  return exists;
};

export const paymentMethodFromOrder = ({
  paymentSources,
  paymentTransactions,
}: OrderType): OrderPaymentMethod => {
  const { code } = paymentSources?.[0]?.sourceType ?? {};
  const transaction = paymentTransactions?.[0];
  const result: OrderPaymentMethod = { code };

  if (CARD_PAYMENT_CODES.includes(code)) {
    result.info = paymentInfoFromTransaction(transaction);
  }

  return result;
};

export const paymentInfoFromTransaction = (transaction: Transaction): Bankcard | undefined => {
  const params = transaction?.source?.label?.split('|');

  if (params?.length > 1) {
    return {
      name: params[0],
      number: getCardNumber(params[1]),
    } as Bankcard;
  }

  return undefined;
};

export const getCardNumber = (str: string) => str.slice(-4);

export const getExpDate = (date: string) => dayjs(date).format('MM/YYYY');

export const isExpired = (date: string) => dayjs().isAfter(date, 'months');
