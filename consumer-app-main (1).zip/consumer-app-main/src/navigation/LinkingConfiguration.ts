import * as Linking from 'expo-linking';

export default {
  prefixes: [Linking.createURL('/')],
  config: {
    screens: {
      Root: {
        screens: {
          OnboardingAddress: 'onboarding/address',
          OnboardingNotifications: 'onboarding/notifications',
          Home: { path: 'home' },
          Search: 'search/:search?',
          MerchantRoot: {
            path: 'merchant/:merchantId',
            parse: {
              merchantId: Number,
            },
            initialRouteName: 'MerchantHome',
            screens: {
              MerchantCategory: {
                path: 'category/:categoryId/:subCategoryId?',
              },
              MerchantBasket: 'basket',
              MerchantCheckout: 'checkout',
              MerchantSearch: 'search/:search?',
            },
          },
          AccountHome: 'account',
          AccountDetails: 'account/profile',
          PasswordChange: 'account/password',
          Addresses: 'account/addresses',
          AddressForm: 'account/address/:addressId?',
          Orders: 'orders',
          OrderDetails: 'orders/:orderNumber',
          MyMerchants: 'my-merchants',
          PaymentMethods: 'account/payment-methods',
          CardAttachment: 'account/payment-methods/new',
          Login: 'login',
          Registration: 'register',
        },
      },
      NotFound: '*',
    },
  },
};
