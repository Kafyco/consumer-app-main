import * as React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import useSelector from 'hooks/useSelector';
import { selectIsAuthenticated } from 'reducers/app';
import { selectAddressesStatus, selectTotalAddresses } from 'reducers/addresses';

import LandingScreen from 'screens/Authorization/LandingScreen';
import NotificationsScreen from 'screens/Authorization/NotificationsScreen';
import LoginScreen from 'screens/Authorization/LoginScreen';
import RegistrationScreen from 'screens/Authorization/RegistrationScreen';

// Onboarding
import OnboardingAddressScreen from 'screens/Authorization/AddressScreen';
// Main app
import HomeScreen from 'screens/HomeScreen';
import SearchScreen from 'screens/SearchScreen';
import AccountScreen from 'screens/AccountScreen';
import AccountDetailsScreen from 'screens/AccountDetailsScreen';
import PasswordChangeScreen from 'screens/PasswordChangeScreen';
import AddressesScreen from 'screens/AddressesScreen';
import AddressLocationScreen from 'screens/AddressLocationScreen';
import AddressFormScreen from 'screens/AddressFormScreen';
import CheckoutOrderConfirmedScreen from 'screens/CheckoutOrderConfirmedScreen';
import OrdersScreen from 'screens/OrdersScreen';
import OrderDetailsScreen from 'screens/OrderDetailsScreen';
import MyMerchantsScreen from 'screens/MyMerchantsScreen';
import PaymentMethodsScreen from 'screens/PaymentMethodsScreen';
import CardAttachmentScreen from 'screens/CardAttachmentScreen';

import LoadingScreen from 'components/LoadingScreen';

import MerchantRoot from './MerchantRoot';

export type MainNavigationParamList = {
  Landing: undefined;
  Notifications: undefined;
  Login: undefined;
  Registration: undefined;
  Loading: undefined;

  Home: {
    addressId?: string | number;
  };
  Search: {
    search?: string;
  };
  MerchantRoot: {
    merchantId: string;
  };
  AccountHome: undefined;
  AccountDetails: undefined;
  PasswordChange: undefined;
  Addresses: undefined;
  AddressLocation: undefined;
  AddressForm: {
    addressId?: number | string;
  };
  CheckoutOrderConfirmed: {
    orderNumber: number | string;
  };
  Orders: undefined;
  OrderDetails: {
    orderNumber: number | string;
  };
  MyMerchants: undefined;
  PaymentMethods: undefined;
  CardAttachment: undefined;

  OnboardingAddress: undefined;
};

const Stack = createStackNavigator<MainNavigationParamList>();

export default function MainNavigator() {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const addressesStatus = useSelector(selectAddressesStatus);
  const totalAddresses = useSelector(selectTotalAddresses);
  const [shouldRequestAddress, setShouldRequestAddress] = React.useState<boolean | undefined>(
    undefined,
  );

  React.useEffect(() => {
    if (isAuthenticated && addressesStatus === 'fulfilled' && shouldRequestAddress === undefined) {
      setShouldRequestAddress(!totalAddresses);
    }
  }, [addressesStatus, totalAddresses, isAuthenticated]);

  if (isAuthenticated && shouldRequestAddress === undefined) {
    return <LoadingScreen />;
  }

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {isAuthenticated ? (
        <>
          {shouldRequestAddress && (
            <Stack.Screen name="OnboardingAddress" component={OnboardingAddressScreen} />
          )}
          <Stack.Screen name="Home" component={HomeScreen} options={{ gestureEnabled: false }} />
          <Stack.Screen name="Search" component={SearchScreen} />
          <Stack.Screen name="MerchantRoot" component={MerchantRoot} />
          <Stack.Screen
            name="CheckoutOrderConfirmed"
            component={CheckoutOrderConfirmedScreen}
            options={{ gestureEnabled: false }}
          />
          <Stack.Screen name="AccountHome" component={AccountScreen} />
          <Stack.Screen name="AccountDetails" component={AccountDetailsScreen} />
          <Stack.Screen name="PasswordChange" component={PasswordChangeScreen} />
          <Stack.Screen name="Addresses" component={AddressesScreen} />
          <Stack.Screen name="AddressLocation" component={AddressLocationScreen} />
          <Stack.Screen name="AddressForm" component={AddressFormScreen} />
          <Stack.Screen name="Orders" component={OrdersScreen} />
          <Stack.Screen name="OrderDetails" component={OrderDetailsScreen} />
          <Stack.Screen name="MyMerchants" component={MyMerchantsScreen} />
          <Stack.Screen name="PaymentMethods" component={PaymentMethodsScreen} />
          <Stack.Screen name="CardAttachment" component={CardAttachmentScreen} />
        </>
      ) : (
        <>
          <Stack.Screen name="Landing" component={LandingScreen} />
          <Stack.Screen name="Notifications" component={NotificationsScreen} />
          <Stack.Screen
            name="Registration"
            component={RegistrationScreen}
            options={{ gestureEnabled: false }}
          />
          <Stack.Screen name="Login" component={LoginScreen} />
        </>
      )}
    </Stack.Navigator>
  );
}
