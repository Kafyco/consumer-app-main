import * as React from 'react';
import { StackScreenProps, createStackNavigator, TransitionPresets } from '@react-navigation/stack';

import { MainNavigationParamList } from 'navigation/MainNavigator';

//
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import {
  getAndSetCurrentMerchant,
  resetCurrentMerchant,
  selectMerchantById,
  setCurrentMerchantId,
} from 'reducers/merchants';
import { fetchMerchantCategories, resetCategories } from 'reducers/categories';
import { fetchMerchantBasket, resetBasket } from 'reducers/basket';

// Screens
import MerchantScreen from 'screens/MerchantScreen';
import CategoryScreen from 'screens/CategoryScreen';
import BasketScreen from 'screens/BasketScreen';
import CheckoutScreen from 'screens/CheckoutScreen';
import CardAttachmentScreen from 'screens/CardAttachmentScreen';
import MerchantSearchScreen from 'screens/MerchantSearchScreen';

import { MerchantContextProvider } from 'utils/merchantContext';

export type MerchantRootParamList = {
  MerchantHome: undefined;
  MerchantCategory: {
    categoryId: string;
    subCategoryId?: string;
  };
  MerchantBasket: undefined;
  MerchantCheckout: undefined;
  MerchantCheckoutAddCard: undefined;
  MerchantSearch: {
    search?: string;
  };
} & MainNavigationParamList;

type Props = StackScreenProps<MerchantRootParamList, 'MerchantRoot'>;

const MercahntStack = createStackNavigator<MerchantRootParamList>();

export default function MerchantRoot({ route }: Props) {
  const { merchantId } = route.params;
  const dispatch = useDispatch();
  const merchant = useSelector((state) => selectMerchantById(state, merchantId));

  // Fetch globally required information of the merchant.
  React.useEffect(() => {
    if (merchant) {
      dispatch(setCurrentMerchantId(merchantId));
    } else {
      dispatch(getAndSetCurrentMerchant(merchantId));
    }

    dispatch(fetchMerchantCategories(merchantId));
    dispatch(fetchMerchantBasket(merchantId));

    return () => {
      dispatch(resetCurrentMerchant());
      dispatch(resetCategories());
      dispatch(resetBasket());
    };
  }, [merchantId, merchant?.id]);

  return (
    <MerchantContextProvider merchantId={merchantId} merchant={merchant}>
      <MercahntStack.Navigator
        initialRouteName="MerchantHome"
        screenOptions={{ headerShown: false }}
      >
        <MercahntStack.Screen name="MerchantHome" component={MerchantScreen} />
        <MercahntStack.Screen name="MerchantCategory" component={CategoryScreen} />
        <MercahntStack.Screen name="MerchantBasket" component={BasketScreen} />
        <MercahntStack.Screen name="MerchantCheckout" component={CheckoutScreen} />
        <MercahntStack.Screen name="MerchantCheckoutAddCard" component={CardAttachmentScreen} />
        <MercahntStack.Screen
          name="MerchantSearch"
          component={MerchantSearchScreen}
          initialParams={{ search: '' }}
          options={{
            ...TransitionPresets.ModalSlideFromBottomIOS,
          }}
        />
      </MercahntStack.Navigator>
    </MerchantContextProvider>
  );
}
