export { default } from './PoweredByGoogle';
