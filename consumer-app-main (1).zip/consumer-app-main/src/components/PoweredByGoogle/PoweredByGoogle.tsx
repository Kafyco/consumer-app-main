import * as React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const PoweredByGoogle = () => {
  const insets = useSafeAreaInsets();

  return (
    <View style={{ paddingBottom: insets.bottom }}>
      <View style={styles.inner}>
        <Image
          style={styles.poweredByGoogle}
          source={require('assets/images/powered_by_google/powered_by_google_on_white.png')}
        />
      </View>
    </View>
  );
};

export default PoweredByGoogle;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  inner: {
    padding: 8,
  },
  poweredByGoogle: {
    alignSelf: 'center',
    width: 114,
    height: 18,
    resizeMode: 'contain',
  },
});
