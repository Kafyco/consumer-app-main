import * as React from 'react';
import { StyleProp, ViewStyle } from 'react-native';

import BottomSheet from 'components/BottomSheet';
import Button from 'components/Button';

interface BottomButtonProps {
  label: string;
  disabled?: boolean;
  loading?: boolean;
  positionStatic?: boolean;
  icon?: string;
  style?: StyleProp<ViewStyle>;
  onPress?(): void;
}

const BottomButton = ({
  label,
  onPress,
  positionStatic,
  style,
  ...buttonProps
}: BottomButtonProps) => {
  return (
    <BottomSheet positionStatic={positionStatic} style={style}>
      <Button mode="contained" onPress={onPress} {...buttonProps}>
        {label}
      </Button>
    </BottomSheet>
  );
};

export default BottomButton;
