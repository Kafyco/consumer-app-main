export { default } from './BottomButton';
