export { default } from './SplashLogo';
export { defaultWidth, defaultHeight } from './constants';
