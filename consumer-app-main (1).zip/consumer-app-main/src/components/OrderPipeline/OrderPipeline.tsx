import * as React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';

import { ORDER_PIPELINE } from 'constants/Order';
import Colors from 'constants/Colors';

const OrderPipeline = ({ status }: { status: string }) => {
  const inPipeline = ORDER_PIPELINE.includes(status);
  const stages = React.useMemo(() => {
    let statusFound = false;
    return ORDER_PIPELINE.map<ViewStyle[]>((s) => {
      if (inPipeline) {
        if (statusFound) {
          return [styles.item];
        } else if (status === s) {
          statusFound = true;
          return [styles.item, styles.current];
        } else {
          return [styles.item, styles.passed];
        }
      }
      return [styles.item];
    });
  }, [status]);

  return (
    <View style={styles.wrap}>
      {stages.map((s, i) => (
        <View key={i} style={s} />
      ))}
    </View>
  );
};

export default OrderPipeline;

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'stretch',
    marginHorizontal: -2,
    marginVertical: 4,
  },
  item: {
    flexGrow: 1,
    marginHorizontal: 2,
    height: 4,
    backgroundColor: Colors.light,
  },
  passed: {
    backgroundColor: Colors.success,
  },
  current: {
    backgroundColor: Colors.success,
  },
});
