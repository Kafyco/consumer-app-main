export {
  default,
  CATEGORY_HEADER_HEIGHT,
  CATEGORY_HEADER_COLLAPSED_HEIGHT,
} from './CategoryHeader';
