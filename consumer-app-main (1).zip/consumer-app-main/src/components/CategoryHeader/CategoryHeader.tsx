import React from 'react';
import { StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import Animated, {
  useDerivedValue,
  useAnimatedStyle,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';

import Colors from 'constants/Colors';
import Layout from 'constants/Layout';
import { CategoryList as CategoryType } from 'api/models';

import Text from 'components/Text';
import ScreenHeader, { SCREEN_HEADER_HEIGHT } from 'components/ScreenHeader';
import MerchantSearch from 'components/MerchantSearch';
import ScrollableTabs, { TabProps, SCROLLABLE_TABS_HEIGHT } from 'components/ScrollableTabs';

export const SUBTITLE_HEIGHT = 38;
export const COLLAPSIN_STARTS_AT = SCREEN_HEADER_HEIGHT - 8;
export const CATEGORY_HEADER_HEIGHT = 220;
export const CATEGORY_HEADER_COLLAPSED_HEIGHT = COLLAPSIN_STARTS_AT + SCROLLABLE_TABS_HEIGHT;

export interface CategoryHeaderProps {
  scrollY: Animated.SharedValue<number>;
  category: CategoryType;
  subCategories: Array<CategoryType>;
  currentCategoryId: number | string | undefined;
  onTabPress?(item: any, index: number): void;
  onSearchBegin?(): void;
}

const CategoryHeader = ({
  scrollY,
  category,
  subCategories,
  currentCategoryId,
  onTabPress,
  onSearchBegin,
}: CategoryHeaderProps) => {
  const [t] = useTranslation();
  const tabs = React.useMemo<TabProps[]>(() => {
    // First tab is to show all products in parent category
    const allProducts = {
      id: undefined,
      title: t('all-products-tab'),
      active: currentCategoryId === undefined,
    };
    // Map categories to tabs and add All Products tab at the beginning
    return subCategories.reduce(
      (res, { id, name }) => {
        res.push({
          id,
          title: name,
          active: String(id) === String(currentCategoryId),
        });
        return res;
      },
      [allProducts],
    );
  }, [subCategories, currentCategoryId]);

  // Animations
  const isSticked = useDerivedValue(
    () => scrollY.value >= CATEGORY_HEADER_HEIGHT - CATEGORY_HEADER_COLLAPSED_HEIGHT,
    [scrollY.value],
  );
  const containerAnimatedStyle = useAnimatedStyle(() => {
    const translateY = Math.min(scrollY.value, COLLAPSIN_STARTS_AT) * -1;
    if (isSticked.value) {
      return {
        transform: [{ translateY }],
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
      };
    }
    return {
      transform: [{ translateY }],
      shadowRadius: 0,
      shadowOpacity: 0,
      elevation: 0,
    };
  });
  const screenHeaderAnimatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollY.value, [0, COLLAPSIN_STARTS_AT], [1, 0], Extrapolate.CLAMP),
  }));
  const subtitleAnimatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      scrollY.value,
      [COLLAPSIN_STARTS_AT, COLLAPSIN_STARTS_AT + 16],
      [1, 0],
      Extrapolate.CLAMP,
    ),
    height: interpolate(
      scrollY.value,
      [COLLAPSIN_STARTS_AT, COLLAPSIN_STARTS_AT + SUBTITLE_HEIGHT],
      [SUBTITLE_HEIGHT, 0],
      Extrapolate.CLAMP,
    ),
  }));

  return (
    <Animated.View style={[styles.headerContainer, containerAnimatedStyle]}>
      <ScreenHeader headerTitle={category.name} style={screenHeaderAnimatedStyle} />
      <MerchantSearch placeholder={t('search-within-supplier')} onSearchBegin={onSearchBegin} />
      <Animated.View style={[styles.subCategories, subtitleAnimatedStyle]}>
        <Text size={14}>{t('subcategories')}</Text>
      </Animated.View>
      <ScrollableTabs data={tabs} onPress={onTabPress} scrollOnPress />
    </Animated.View>
  );
};

export default CategoryHeader;

const styles = StyleSheet.create({
  headerContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 0,
    shadowOpacity: 0,
    elevation: 0,
  },
  subCategories: {
    height: SUBTITLE_HEIGHT,
    justifyContent: 'flex-end',
    paddingHorizontal: Layout.screenPadding,
    overflow: 'hidden',
  },
});
