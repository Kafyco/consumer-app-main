import * as React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { BottomSheetModal, BottomSheetBackdrop } from '@gorhom/bottom-sheet';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';

import { Product as ProductType } from 'api/models';
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import Layout from 'constants/Layout';
import Colors from 'constants/Colors';
import { getUnitsSymbol } from 'utils/uom';

import {
  selectBasketStagedProduct,
  selectBasketLineByProductId,
  addToBasket,
  removeBasketLine,
  updateLineQty,
} from 'reducers/basket';

import { Title } from 'components/Text';
import Button from 'components/Button';
import ButtonClose from 'components/ButtonClose';

import PickerIOs from './PickerIOs';
import PickerAndroid from './PickerAndroid';

const SNAP_POINTS = [350];

const getValues = (item: ProductType) => {
  if (!item) return [];

  const qtyStep = parseFloat(item.displayQuantityStep) || 1;
  const minQty = parseFloat(item.displayQuantityMinimum) || 1;
  const maxQty = parseFloat(item?.displayQuantityMaximum) || qtyStep * 100;
  let values: Array<number> = [minQty];

  for (let i = 1; values[i - 1] < maxQty; i += 1) {
    // Fix desimal issues of JS
    values.push(Math.floor((minQty + i * qtyStep) * 1000) / 1000);
  }

  return values;
};

interface AddToCartWidgetProps {
  onDismiss?(): void;
}
const AddToCartWidget = React.forwardRef<BottomSheetModal, AddToCartWidgetProps>(
  ({ onDismiss }, ref) => {
    const [t] = useTranslation();
    const insets = useSafeAreaInsets();
    const dispatch = useDispatch();
    const item = useSelector(selectBasketStagedProduct);
    const basketLine = useSelector((state) => selectBasketLineByProductId(state, item?.id));
    const modalRef = React.useRef<BottomSheetModal | null>();
    const [quantity, setQuantity] = React.useState<number>(0);
    const [isLoading, setIsLoading] = React.useState(false);
    const [isRemoving, setIsRemoving] = React.useState(false);
    const values = React.useMemo(() => (item ? getValues(item) : []), [item]);
    const unitsString = React.useMemo(() => (item ? getUnitsSymbol(item.unit) : ''), [item]);
    const options = React.useMemo(
      () => values.map((value) => ({ label: `${value} ${unitsString}`, value })),
      [values],
    );

    const handleOnClose = () => {
      modalRef.current?.dismiss();
    };

    const handleOnAddOrUpdate = async () => {
      if (isLoading) {
        return;
      }
      const timer = setTimeout(setIsLoading, 300, true);

      if (basketLine) {
        await dispatch(
          updateLineQty({
            lineId: basketLine.id,
            productId: basketLine.product.id,
            quantity,
          }),
        );
      } else {
        await dispatch(
          addToBasket({
            productId: item?.id,
            quantity,
          }),
        );
      }

      clearTimeout(timer);
      setIsLoading(false);
      handleOnClose();
    };

    const handleRemove = async () => {
      if (isRemoving) {
        return;
      }
      if (basketLine) {
        const timer = setTimeout(setIsRemoving, 300, true);
        await dispatch(
          removeBasketLine({
            lineId: basketLine.id,
            productId: basketLine.product.id,
          }),
        );
        clearTimeout(timer);
        setIsRemoving(false);
        handleOnClose();
      }
    };

    React.useEffect(() => {
      setQuantity(parseInt(basketLine?.quantity, 10) || values[0]);
    }, [item]);

    return (
      <BottomSheetModal
        ref={(node) => {
          modalRef.current = node;
          if (typeof ref === 'function') {
            ref(node);
          } else if (ref) {
            ref.current = node;
          }
        }}
        snapPoints={SNAP_POINTS}
        style={styles.container}
        onDismiss={onDismiss}
        backdropComponent={(props) => (
          <BottomSheetBackdrop {...props} disappearsOnIndex={-1} appearsOnIndex={0} />
        )}
      >
        <View style={[styles.inner, { marginBottom: insets.bottom }]}>
          {item ? (
            <View style={styles.fill}>
              <View style={styles.title}>
                <Title level={2}>{t('choose-quantity')}</Title>
                <ButtonClose onPress={handleOnClose} />
              </View>
              <View style={styles.pickerContainer}>
                {Platform.OS === 'ios' ? (
                  <PickerIOs
                    options={options}
                    selectedValue={quantity}
                    onValueChange={(itemValue) => setQuantity(itemValue)}
                  />
                ) : (
                  <PickerAndroid
                    options={options}
                    selectedValue={quantity}
                    onValueChange={(itemValue) => setQuantity(itemValue)}
                  />
                )}
              </View>
              <View style={styles.actions}>
                <View>
                  {basketLine ? (
                    <Button
                      mode="text"
                      icon="trash"
                      color={Colors.text}
                      loading={isRemoving}
                      onPress={handleRemove}
                      disabled={isLoading}
                    >
                      {t('remove')}
                    </Button>
                  ) : null}
                </View>
                <View>
                  <Button
                    mode="contained"
                    onPress={handleOnAddOrUpdate}
                    loading={isLoading}
                    disabled={isRemoving}
                  >
                    {basketLine ? t('update') : t('add-to-cart')}
                  </Button>
                </View>
              </View>
            </View>
          ) : (
            __DEV__ && (
              <Title level={2}>Looks like you forgot to stage product to the basket 🧐</Title>
            )
          )}
        </View>
      </BottomSheetModal>
    );
  },
);

export default AddToCartWidget;

const styles = StyleSheet.create({
  fill: {
    flex: 1,
  },
  container: {
    borderTopStartRadius: 20,
    borderTopEndRadius: 20,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.34,
    shadowRadius: 6.27,

    elevation: 10,
  },
  inner: {
    flex: 1,
    paddingHorizontal: Layout.screenPadding,
    paddingBottom: Layout.screenPadding,
  },
  title: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  pickerContainer: {
    flexGrow: 1,
  },
});
