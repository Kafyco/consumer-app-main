import * as React from 'react';
import { Picker } from '@react-native-picker/picker';

type Option = {
  label: string;
  value: any;
};

interface Props {
  selectedValue: any;
  options: Option[];
  onValueChange(value: any): void;
}

const PickerIOs = ({ selectedValue, options, onValueChange }: Props) => (
  <Picker selectedValue={selectedValue} onValueChange={onValueChange} style={{ flex: 1 }}>
    {options.map(({ label, value }) => (
      <Picker.Item key={`pi-${value}`} label={label} value={value} />
    ))}
  </Picker>
);

export default PickerIOs;
