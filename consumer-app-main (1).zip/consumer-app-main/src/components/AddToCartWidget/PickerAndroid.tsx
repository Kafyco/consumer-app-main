import * as React from 'react';
import { StyleSheet, View, TouchableHighlight } from 'react-native';
import { RadioButton } from 'react-native-paper';
import { BottomSheetScrollView } from '@gorhom/bottom-sheet';

import Colors from 'constants/Colors';
import Text from 'components/Text';

type Option = {
  label: string;
  value: any;
};

interface Props {
  selectedValue: any;
  options: Option[];
  onValueChange(value: any): void;
}

const PickerAndroid = ({ selectedValue, options, onValueChange }: Props) => {
  return (
    <BottomSheetScrollView style={styles.container} persistentScrollbar>
      <RadioButton.Group value={selectedValue} onValueChange={onValueChange}>
        {options.map(({ label, value }) => (
          <TouchableHighlight key={`pi-${value}`} onPress={() => onValueChange(value)}>
            <View style={styles.item}>
              <RadioButton value={value} color={Colors.primary} />
              <Text size={18} style={styles.text}>
                {label}
              </Text>
            </View>
          </TouchableHighlight>
        ))}
      </RadioButton.Group>
    </BottomSheetScrollView>
  );
};

export default PickerAndroid;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 48,
    backgroundColor: 'white',
  },
  text: {
    marginStart: 8,
  },
});
