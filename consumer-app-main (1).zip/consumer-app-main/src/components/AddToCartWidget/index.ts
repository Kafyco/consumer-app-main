import AddToCartWidget from './AddToCartWidget';
import { BottomSheetModalProvider, BottomSheetModal } from '@gorhom/bottom-sheet';

export default {
  Provider: BottomSheetModalProvider,
  Modal: AddToCartWidget,
};

export type ModalType = BottomSheetModal;
