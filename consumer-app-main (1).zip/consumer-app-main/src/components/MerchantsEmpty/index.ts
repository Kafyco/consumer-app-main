export { default } from './MerchantsEmpty';
