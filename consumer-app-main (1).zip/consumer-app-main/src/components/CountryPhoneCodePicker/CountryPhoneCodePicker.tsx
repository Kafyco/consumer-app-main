import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { CountryCode } from 'libphonenumber-js';
import CountryPicker from 'react-native-country-picker-modal';

import color from 'color';
import theme from 'constants/theme';

interface Props {
  defaultValue: CountryCode;
  onSelect(country: any): void;
  onOpen?(): void;
  onClose?(): void;
}

const CountryPhoneCodePicker = ({ defaultValue = 'QA', onSelect, ...rest }: Props) => {
  const [countryCode, setCountryCode] = React.useState<CountryCode>(defaultValue);
  return (
    <View style={styles.container}>
      <CountryPicker
        preferredCountries={['QA', 'AE', 'SA']}
        countryCode={countryCode}
        withFlag
        withCallingCode
        withCallingCodeButton
        withModal
        withFilter
        onSelect={(country: any) => {
          setCountryCode(country.cca2);
          onSelect?.(country);
        }}
        containerButtonStyle={{
          paddingTop: 8,
          paddingBottom: 8,
        }}
        {...rest}
      />
    </View>
  );
};

export default CountryPhoneCodePicker;

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    height: 64,
    paddingHorizontal: 12,
    backgroundColor: color(theme.colors.background).darken(0.06).rgb().string(),
  },
});
