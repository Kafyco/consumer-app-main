import * as React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';

import { Address as AddressType } from 'api/models';
import Colors from 'constants/Colors';
import getAddressLine from 'utils/getAddressLine';
import getAddressName from 'utils/getAddressName';

import Icon from 'components/Icon';
import Text from 'components/Text';

interface AddressProps {
  info: AddressType;
  withIcon?: boolean;
  padded?: boolean;
  style?: ViewStyle;
}

const Address = ({ info, padded, withIcon = true, style }: AddressProps) => {
  const { phoneNumber } = info;
  const addressLine = getAddressLine(info);

  return (
    <View style={[styles.container, style]}>
      <View style={styles.addressName}>
        {withIcon ? (
          <View style={styles.icon}>
            <Icon name="map-pin-line" size={16} color={Colors.primary} />
          </View>
        ) : null}
        <View>
          <Text size={16} numberOfLines={1}>
            {getAddressName(info)}
          </Text>
        </View>
      </View>
      <View style={[styles.addressDetails, padded && styles.padded]}>
        <Text size={14} color="secondary">
          {addressLine}
        </Text>
        <Text size={14} style={styles.phone}>
          {phoneNumber}
        </Text>
      </View>
    </View>
  );
};

export default Address;

const styles = StyleSheet.create({
  container: {},
  addressName: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 4,
  },
  icon: {
    marginEnd: 4,
  },
  addressDetails: {
    paddingStart: 0,
  },
  phone: {
    paddingTop: 8,
  },
  padded: {
    paddingStart: 20,
  },
});
