import * as React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { useTranslation } from 'react-i18next';
import { Text, Title } from 'components/Text';

interface EmptyBasketProps {
  style?: ViewStyle;
}
const EmptyBasket = ({ style }: EmptyBasketProps) => {
  const [t] = useTranslation();
  return (
    <View style={[styles.container, style]}>
      <View style={styles.inner}>
        <Title level={2} style={styles.text}>
          {t('empty-cart-title')}
        </Title>
        <Text color="secondary" style={styles.text}>
          {t('empty-cart-desc')}
        </Text>
      </View>
    </View>
  );
};

export default EmptyBasket;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inner: {
    maxWidth: 320,
  },
  text: {
    textAlign: 'center',
  },
});
