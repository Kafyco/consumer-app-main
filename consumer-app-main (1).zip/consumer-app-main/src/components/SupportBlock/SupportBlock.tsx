import * as React from 'react';
import { View, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import * as Linking from 'expo-linking';

import { SUPPORT_EMAIL, SUPPORT_PHONE_NUMBER, SUPPORT_PHONE_NUMBER_TEXT } from 'constants/Global';
import { Text } from 'components/Text';
import Sheet from 'components/Sheet';

interface SupportBlockProps {
  children: React.ReactElement;
  style?: StyleProp<ViewStyle>;
  emailSubject?: string;
}

const SupportBlock = ({ children, style, emailSubject }: SupportBlockProps) => {
  const handleEmailSupport = () => {
    Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=${emailSubject}`);
  };

  const handlePhoneSupport = () => {
    Linking.openURL(`tel:${SUPPORT_PHONE_NUMBER}`);
  };

  return (
    <Sheet style={[styles.container, style]}>
      {children}
      {SUPPORT_EMAIL && (
        <View style={styles.supportOption}>
          <Text color="primary" weight="bold" onPress={handleEmailSupport}>
            {SUPPORT_EMAIL}
          </Text>
        </View>
      )}
      {SUPPORT_PHONE_NUMBER_TEXT && (
        <View style={styles.supportOption}>
          <Text color="primary" weight="bold" onPress={handlePhoneSupport}>
            {SUPPORT_PHONE_NUMBER_TEXT}
          </Text>
        </View>
      )}
    </Sheet>
  );
};

export default SupportBlock;

const styles = StyleSheet.create({
  container: {
    paddingTop: 16,
    paddingBottom: 24,
  },
  supportOption: {
    marginTop: 8,
  },
});
