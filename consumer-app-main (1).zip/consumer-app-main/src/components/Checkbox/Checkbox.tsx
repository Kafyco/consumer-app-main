import * as React from 'react';
import { View, ViewStyle, StyleSheet, TouchableWithoutFeedback } from 'react-native';

import Colors from 'constants/Colors';
import Icon from 'components/Icon';

interface CheckboxProps {
  size?: number;
  checked?: boolean;
  style?: ViewStyle;
  onPress?(): void;
}

const Checkbox = ({ size = 24, checked, style, onPress }: CheckboxProps) => (
  <TouchableWithoutFeedback onPress={onPress}>
    <View
      style={[
        styles.idle,
        checked && styles.checked,
        { borderRadius: size / 2 },
        { width: size, height: size },
        style,
      ]}
    >
      {checked ? <Icon name="check" size={size * 0.75} color={Colors.white} /> : null}
    </View>
  </TouchableWithoutFeedback>
);

export default Checkbox;

const styles = StyleSheet.create({
  idle: {
    borderColor: '#ABABAB',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checked: {
    borderWidth: 0,
    backgroundColor: Colors.primary,
  },
});
