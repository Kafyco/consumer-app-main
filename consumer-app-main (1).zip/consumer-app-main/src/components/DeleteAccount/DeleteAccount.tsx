import * as React from 'react';
import { View } from 'react-native';
import { useTranslation } from 'react-i18next';

import useDispatch from 'hooks/useDispatch';
import { signOut, deleteAccount } from 'reducers/app';

import { Text } from 'components/Text';
import DialogConfirm from 'components/DialogConfirm';
import Checkbox from 'components/Checkbox';

interface Props {
  visible: boolean;
  onCancel(): void;
}

const DeleteAccount = ({ visible, onCancel }: Props) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const [checked, setChecked] = React.useState<boolean>(false);

  const handleConfirmDelete = async () => {
    await dispatch(deleteAccount());
    dispatch(signOut());
  };

  return (
    <DialogConfirm
      title={t('account-deletion')}
      visible={visible}
      disabled={!checked}
      onCancel={() => {
        setChecked(false);
        onCancel();
      }}
      onConfirm={handleConfirmDelete}
    >
      <View style={{ flexDirection: 'column' }}>
        <View>
          <Text>{t('account-deletion-description')}</Text>
        </View>
        <View style={{ flexDirection: 'row', marginTop: 16 }}>
          <Checkbox
            size={24}
            checked={checked}
            onPress={() => setChecked(!checked)}
            style={{ marginEnd: 8 }}
          />
          <Text>{t('account-deletion-confirmation')}</Text>
        </View>
      </View>
    </DialogConfirm>
  );
};

export default DeleteAccount;
