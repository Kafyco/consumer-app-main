export { default } from './DeleteAccount';
