import * as React from 'react';
import { View, StyleSheet, TouchableHighlight } from 'react-native';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

import Text from 'components/Text';
import useSelector from 'hooks/useSelector';
import Colors from 'constants/Colors';
import { MerchantRootParamList } from 'navigation/MerchantRoot';
import { selectBasketInfo, selectTotalBasketLines } from 'reducers/basket';

import BottomSheet from 'components/BottomSheet';

export const BASKET_WIDGET_HEIGHT = 72;

const BasketWidget = () => {
  const [t] = useTranslation();
  const navigation = useNavigation<NavigationProp<MerchantRootParamList>>();

  const basket = useSelector(selectBasketInfo);
  const totalBasketLines = useSelector(selectTotalBasketLines);

  const handleOnPress = () => {
    navigation.navigate('MerchantBasket');
  };

  // No basket, no widget
  if (!totalBasketLines || !basket) {
    return null;
  }

  return (
    <BottomSheet>
      <TouchableHighlight onPress={handleOnPress} style={styles.touchableHighlight}>
        <View style={styles.button}>
          <View style={styles.counterCell}>
            <View style={styles.counter}>
              <Text color="white" size={14} weight="bold">
                {totalBasketLines}
              </Text>
            </View>
          </View>
          <View style={styles.buttonTitle}>
            <Text color="white" size={16} weight="bold">
              {t('view-cart')}
            </Text>
          </View>
          <View style={styles.total}>
            <Text color="white" size={12}>
              {basket.currency}&nbsp;
              {parseFloat(basket.totalInclTaxExclDiscounts).toFixed(2)}
            </Text>
          </View>
        </View>
      </TouchableHighlight>
    </BottomSheet>
  );
};

export default BasketWidget;

const styles = StyleSheet.create({
  content: {
    padding: 12,
  },
  touchableHighlight: {
    borderRadius: 12,
  },
  button: {
    display: 'flex',
    flexDirection: 'row',
    height: 48,
    padding: 8,
    backgroundColor: Colors.primary,
    borderRadius: 12,
  },
  buttonTitle: {
    width: '33%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  counterCell: {
    width: '33%',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  counter: {
    flex: 1,
    minWidth: 32,
    height: 32,
    opacity: 0.8,
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 8,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  total: {
    width: '33%',
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
});
