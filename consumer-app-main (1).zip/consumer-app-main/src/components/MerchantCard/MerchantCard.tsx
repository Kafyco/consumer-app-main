import * as React from 'react';
import { View, Image, StyleSheet, ViewStyle, TouchableOpacity } from 'react-native';

import { Partner } from 'api/models';

import { Title, Text } from 'components/Text';
import DeliveryLabel from 'components/DeliveryLabel';
import NoImage from 'components/NoImage';

import getImageUrl from 'utils/getImageUrl';

export interface ShopCardProps {
  merchant: Partner;
  onPress?(): void;
}

const MerchantCard = ({ merchant, onPress }: ShopCardProps) => {
  const { id, name, categoriesNames, logoThumbnail, deliverySettings, status } = merchant;
  const logo = React.useMemo(() => getImageUrl(logoThumbnail, '80x80'), [id]);
  const categoriesString = React.useMemo(
    () => (categoriesNames ? categoriesNames.join(', ') : ''),
    [id],
  );
  const isActive = status === 'active';

  return (
    <TouchableOpacity onPress={onPress} style={styles.card}>
      <View style={styles.content}>
        <View>
          <Title level={4} numberOfLines={1}>
            {name}
          </Title>
          <Text color="secondary" size={14} numberOfLines={2} style={{ lineHeight: 18 }}>
            {categoriesString}
          </Text>
          {!isActive && (
            <Text size={14} color="danger">
              {status}
            </Text>
          )}
        </View>
        <View style={styles.contentBottom}>
          <DeliveryLabel delivery={deliverySettings} />
        </View>
      </View>
      <View style={styles.logoContainer}>
        {logo ? (
          <Image resizeMode="contain" source={{ uri: logo }} style={styles.logo} />
        ) : (
          <NoImage style={styles.logo} resizeMode="contain" />
        )}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    marginVertical: 4,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 8,
    paddingLeft: 20,
  },
  logoContainer: {
    width: 80,
    height: 80,
    marginStart: 8,
  },
  logo: {
    flex: 1,
    width: 80,
    height: 80,
    borderRadius: 12,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
  },
  contentBottom: {},
});

export default MerchantCard;
