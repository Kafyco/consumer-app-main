import { BottomSheetModalProvider, BottomSheetModal } from '@gorhom/bottom-sheet';

import Button from './Button';
import Modal from './Modal';

export default {
  Button,
  Modal,
  Provider: BottomSheetModalProvider,
};

export type ModalType = BottomSheetModal;
