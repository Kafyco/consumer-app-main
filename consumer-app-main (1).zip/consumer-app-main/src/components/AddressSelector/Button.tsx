import * as React from 'react';
import { View, StyleSheet, TouchableHighlight } from 'react-native';

import { Text } from 'components/Text';
import Icon from 'components/Icon';

interface AddressSelectorProps {
  label: string;
  onPress?(): void;
}

const AddressSelector = ({ label, onPress }: AddressSelectorProps) => (
  <TouchableHighlight onPress={onPress} style={styles.wrap}>
    <View style={styles.container}>
      <View style={styles.value}>
        <Text size={14} weight="medium" numberOfLines={1} ellipsizeMode="tail">
          {label || ' '}
        </Text>
      </View>
      <View style={styles.trigger}>
        <Icon name="caret-down" size={16} />
      </View>
    </View>
  </TouchableHighlight>
);

export default AddressSelector;

const styles = StyleSheet.create({
  wrap: {
    borderRadius: 8,
  },
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#D7DEDE',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  value: {
    flexShrink: 1,
  },
  trigger: {
    paddingStart: 12,
  },
});
