import * as React from 'react';
import { View, StyleSheet, TouchableWithoutFeedback } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheetModal, BottomSheetBackdrop, BottomSheetFlatList } from '@gorhom/bottom-sheet';
import { useTranslation } from 'react-i18next';

import { Address as AddressType } from 'api/models';
import Colors from 'constants/Colors';

import LoadingScreen from 'components/LoadingScreen';
import Address from 'components/Address';
import { Title } from 'components/Text';
import Checkbox from 'components/Checkbox';
import Button from 'components/Button';

type SideActionType = {
  label: string;
  onPress(): void;
};

interface ModalProps {
  isLoading: boolean;
  addresses: AddressType[];
  selectedId?: string | number;
  selectedFirst?: boolean;
  closeOnChange?: boolean;
  sideAction?: SideActionType;
  onChange?(item: AddressType): void;
  onDismiss?(): void;
}

const Modal = React.forwardRef<BottomSheetModal, ModalProps>(
  (
    {
      addresses,
      isLoading,
      selectedId,
      selectedFirst,
      sideAction,
      closeOnChange = true,
      onChange,
      onDismiss,
    },
    ref,
  ) => {
    const [t] = useTranslation();
    const insets = useSafeAreaInsets();
    const modalRef = React.useRef<BottomSheetModal | null>();
    const data = React.useMemo(
      () => (selectedFirst ? addresses.sort((a) => (a.id === selectedId ? -1 : 0)) : addresses),
      [addresses, selectedId],
    );

    const handleItemPress = (item: AddressType) => {
      closeOnChange && modalRef.current?.dismiss();
      onChange?.(item);
    };

    const handleSideActionPress = () => {
      modalRef.current?.dismiss();
      sideAction?.onPress();
    };

    return (
      <BottomSheetModal
        ref={(node) => {
          modalRef.current = node;
          if (typeof ref === 'function') {
            ref(node);
          } else if (ref) {
            ref.current = node;
          }
        }}
        snapPoints={[380 + insets.bottom]}
        style={styles.container}
        onDismiss={onDismiss}
        backdropComponent={(props) => (
          <BottomSheetBackdrop {...props} disappearsOnIndex={-1} appearsOnIndex={0} />
        )}
      >
        <View style={[styles.inner, { marginBottom: insets.bottom }]}>
          <View style={styles.title}>
            <Title level={2}>{t('delivery-to')}</Title>
            {sideAction && (
              <View>
                <Button mode="text" compact onPress={handleSideActionPress}>
                  {sideAction.label}
                </Button>
              </View>
            )}
          </View>
          {isLoading ? (
            <LoadingScreen />
          ) : (
            <BottomSheetFlatList
              data={data}
              keyExtractor={(item) => String(item.id)}
              renderItem={({ item, index }) => (
                <TouchableWithoutFeedback onPress={() => handleItemPress(item)}>
                  <View style={[styles.item, !!index && styles.itemDivider]}>
                    <Address info={item} withIcon={false} style={styles.itemContent} />
                    <View style={styles.checkboxWrap}>
                      <Checkbox checked={item.id === selectedId} />
                    </View>
                  </View>
                </TouchableWithoutFeedback>
              )}
              extraData={selectedId}
            />
          )}
        </View>
      </BottomSheetModal>
    );
  },
);

export default Modal;

const styles = StyleSheet.create({
  container: {
    borderTopStartRadius: 20,
    borderTopEndRadius: 20,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.34,
    shadowRadius: 6.27,

    elevation: 10,
  },
  inner: {
    flex: 1,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  title: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingStart: 16,
    marginEnd: -8,
  },
  scrollView: {
    flex: 1,
  },
  item: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingStart: 16,
    paddingVertical: 16,
    backgroundColor: Colors.white,
  },
  itemDivider: {
    borderTopWidth: 1,
    borderTopColor: Colors.light,
  },
  itemContent: {
    flexShrink: 1,
  },
  checkboxWrap: {
    flexShrink: 0,
    width: 24,
    marginStart: 24,
  },
});
