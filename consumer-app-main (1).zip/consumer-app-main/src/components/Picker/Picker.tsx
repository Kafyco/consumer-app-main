// Wrapper around react-native-picker-select
// @see https://github.com/lawnstarter/react-native-picker-select#readme
import * as React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from 'react-native-paper';
import color from 'color';
import { ActivityIndicator } from 'react-native-paper';

import Text from 'components/Text';
import Icon from 'components/Icon';
import RNPickerSelect from './RNPickerSelect';

const getItemLabelByValue = (items: any[], value: any) => {
  const item = items.find((item) => item.value === value);
  return item?.inputLabel || item?.label;
};

type PickerItem = {
  label: string;
  value: any;
  inputLabel?: string;
  key?: string | number;
  color?: string;
};

interface PickerProps {
  items: PickerItem[];
  label: string;
  placeholder?: string;
  value?: string | number;
  error?: boolean;
  disabled?: boolean;
  loading?: boolean;
  onValueChange?(value: any, index: number): void;
  rnPickerStyle?: any;
}

const Picker = ({
  label,
  placeholder,
  items,
  value,
  error,
  disabled,
  loading,
  onValueChange,
  rnPickerStyle,
  ...props
}: PickerProps) => {
  const [isSelected, setIsSelected] = React.useState(!!value);
  const [labelText, setLabelText] = React.useState(
    value ? getItemLabelByValue(items, value) : label,
  );

  const theme = useTheme();
  const { colors, fonts } = theme;

  // Themed styles
  const containerStyle: ViewStyle = {
    backgroundColor: theme.dark
      ? color(colors.background).lighten(0.24).rgb().string()
      : color(colors.background).darken(0.06).rgb().string(),
    borderTopLeftRadius: theme.roundness,
    borderTopRightRadius: theme.roundness,
    borderBottomWidth: disabled && !error ? 0 : 1,
    borderColor: error ? colors.error : colors.disabled,
  };
  const labelStyle = {
    ...fonts.regular,
    fontSize: 16,
    color: (() => {
      if (disabled) {
        return colors.disabled;
      }
      if (error) {
        return colors.error;
      }
      if (isSelected) {
        return color.text;
      }
      return colors.placeholder;
    })(),
  };
  const placeholderProp = {
    label: placeholder || label,
    value: null,
    color: colors.disabled,
  };
  const compoundRnStyles = React.useMemo(
    () => ({ ...rnPickerDefaultStyles, ...rnPickerStyle }),
    [rnPickerStyle],
  );

  const handleValueChange = (val: any, index: number) => {
    setLabelText(index ? getItemLabelByValue(items, val) : label);
    // RNPicker adds placeholder on first position of items list, so index `0` means that nothing
    // was selected
    setIsSelected(!!index);

    onValueChange?.(val, index);
  };

  return (
    <RNPickerSelect
      onValueChange={handleValueChange}
      placeholder={placeholderProp}
      items={items}
      value={value}
      disabled={disabled}
      style={compoundRnStyles}
      {...props}
    >
      <View style={[styles.container, containerStyle]}>
        <View style={styles.label}>
          <Text style={labelStyle} numberOfLines={1}>
            {labelText}
          </Text>
        </View>
        <View style={styles.icon}>
          {loading ? (
            <ActivityIndicator color={colors.text} size="small" />
          ) : (
            <Icon name="caret-down" size={24} />
          )}
        </View>
      </View>
    </RNPickerSelect>
  );
};

export default Picker;

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    minHeight: 64,
    paddingHorizontal: 12,
  },
  label: {
    paddingRight: 24,
  },
  icon: {
    justifyContent: 'center',
    position: 'absolute',
    right: 12,
    top: 0,
    bottom: 0,
    width: 24,
  },
});

const rnPickerDefaultStyles = StyleSheet.create({
  done: {
    color: '#007aff',
    fontWeight: '600',
    fontSize: 17,
    paddingTop: 1,
    paddingRight: 11,
  },
  doneDepressed: {
    fontSize: 17,
  },
});
