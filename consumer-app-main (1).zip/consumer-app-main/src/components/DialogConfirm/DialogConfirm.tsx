import * as React from 'react';
import { Dialog, Portal } from 'react-native-paper';
import { useTranslation } from 'react-i18next';

import Button from 'components/Button';
import Text from 'components/Text';

interface DialogConfirmProps {
  children: React.ReactNode;
  visible: boolean;
  disabled?: boolean;
  loading?: boolean;
  title?: string;
  onCancel(): void;
  onConfirm(): void;
}

const DialogConfirm = ({
  children,
  title,
  visible,
  disabled,
  loading,
  onCancel,
  onConfirm,
}: DialogConfirmProps) => {
  const [t] = useTranslation();

  return (
    <Portal>
      <Dialog visible={visible} onDismiss={onCancel}>
        <Dialog.Title>{title || t('confirm')}</Dialog.Title>
        <Dialog.Content>
          <Text>{children}</Text>
        </Dialog.Content>
        <Dialog.Actions style={{ paddingVertical: 16 }}>
          <Button uppercase onPress={onCancel}>
            {t('cancel')}
          </Button>
          <Button uppercase onPress={onConfirm} loading={loading} disabled={disabled}>
            {t('confirm')}
          </Button>
        </Dialog.Actions>
      </Dialog>
    </Portal>
  );
};

export default DialogConfirm;
