export { default } from './DialogConfirm';
