import { createIconSetFromIcoMoon } from '@expo/vector-icons';

const Icon = createIconSetFromIcoMoon(
  require('../../assets/fonts/Phosphor.json'),
  'phosphor',
  'Phosphor.ttf',
);

export default Icon;

export type IconType = typeof Icon;
