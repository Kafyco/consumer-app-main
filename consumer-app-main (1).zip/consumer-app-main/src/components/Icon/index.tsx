export { default, IconType } from './Icon';
