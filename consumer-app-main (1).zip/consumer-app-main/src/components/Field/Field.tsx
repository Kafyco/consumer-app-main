import * as React from 'react';
import { View, StyleProp, ViewStyle, TextInputProps } from 'react-native';
import { TextInput, HelperText } from 'react-native-paper';
import { useField, useFormikContext } from 'formik';

import Picker from 'components/Picker';

interface FieldProps extends TextInputProps {
  name: string;
  label: string;
  placeholder?: string;
  type?: 'text' | 'select' | 'checkbox' | 'radio';
  style?: StyleProp<ViewStyle>;
  loading?: boolean;
  disabled?: boolean;
  multiline?: boolean;
  numberOfLines?: number;
  rightIcon?: React.ReactElement;
  // For Select type
  items?: any[];
  onChange?(value: any): void;
}

const Field = ({
  name,
  label,
  type,
  loading,
  disabled,
  rightIcon,
  items = [],
  style,
  onChange,
  ...inputProps
}: FieldProps) => {
  const [field, meta, helpers] = useField(name);
  const { submitCount } = useFormikContext();
  const handleChange = field.onChange(name);
  const handleBlur = field.onBlur(name);

  const Component =
    type === 'select' ? (
      <Picker
        label={label}
        value={field.value}
        error={!!(meta.error && meta.touched)}
        disabled={disabled}
        loading={loading}
        onValueChange={(value) => {
          onChange?.(value);
          helpers.setValue(value);
          helpers.setTouched(true);
        }}
        items={items}
        {...inputProps}
      />
    ) : (
      <TextInput
        label={label}
        value={field.value}
        error={!!(meta.error && (meta.touched || submitCount))}
        disabled={disabled}
        onChangeText={(value) => {
          onChange?.(value);
          handleChange(value);
        }}
        onBlur={handleBlur}
        right={loading ? <TextInput.Icon name="loading" /> : rightIcon}
        {...inputProps}
      />
    );

  return (
    <View style={[inputRowStyle, style]}>
      {Component}
      <HelperText type="error" visible={!!(meta.error && (meta.touched || submitCount))}>
        {meta.error}
      </HelperText>
    </View>
  );
};

Field.Icon = TextInput.Icon;

export default Field;

const inputRowStyle: ViewStyle = {
  // marginBottom: 8,
};
