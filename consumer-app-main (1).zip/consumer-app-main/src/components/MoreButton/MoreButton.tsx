import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Trans } from 'react-i18next';

import Icon from 'components/Icon';
import Text, { TextColorType } from 'components/Text';
import Colors from 'constants/Colors';

export interface MoreButtonProps {
  label?: string | React.ReactNode;
  tintColor?: TextColorType;
  onPress(): void;
}

const MoreButton = ({ label, tintColor = 'primary', onPress }: MoreButtonProps) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.container}>
        <View>
          <Text size={14} color={tintColor}>
            {label || <Trans i18nKey="see-all">See All</Trans>}
          </Text>
        </View>
        <View style={styles.icon}>
          <Icon name="caret-right-bold" size={16} color={Colors[tintColor]} />
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default MoreButton;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginStart: 4,
  },
});
