import * as React from 'react';
import { View, TouchableHighlight, StyleSheet } from 'react-native';

import Icon from 'components/Icon';

interface ButtonCloseProps {
  onPress?(): void;
}

const ButtonClose = ({ onPress }: ButtonCloseProps) => (
  <View>
    <TouchableHighlight onPress={onPress} style={[styles.roundness, { alignItems: 'center' }]}>
      <View style={[styles.button, styles.roundness]}>
        <Icon name="x" size={16} />
      </View>
    </TouchableHighlight>
  </View>
);

export default ButtonClose;

const styles = StyleSheet.create({
  roundness: {
    borderRadius: 16,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 32,
    height: 32,
    backgroundColor: '#f0f0f0',
  },
});
