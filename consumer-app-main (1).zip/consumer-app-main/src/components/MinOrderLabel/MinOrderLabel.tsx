import * as React from 'react';
import { View } from 'react-native';
import { useTranslation } from 'react-i18next';

import { Text, TextProps } from 'components/Text';
import { DeliverySettings } from 'api/models';

export interface MinOrderLabelProps extends TextProps {
  delivery: DeliverySettings;
}

const MinOrderLabel = ({ delivery, size = 14, ...props }: MinOrderLabelProps) => {
  const [t] = useTranslation();
  const { minOrderAmount, currency = 'QAR' } = delivery || {};
  const amount = React.useMemo(() => {
    const value = parseFloat(minOrderAmount);
    const ceil = Math.ceil(value);
    return ceil === value ? ceil : value;
  }, [minOrderAmount]);

  return (
    <Text size={size} numberOfLines={1} {...props}>
      {t('min-order-amount', { count: amount, currency })}
    </Text>
  );
};

export default MinOrderLabel;
