export { default } from './MinOrderLabel';
