export { default } from './OrderConfirmed';
