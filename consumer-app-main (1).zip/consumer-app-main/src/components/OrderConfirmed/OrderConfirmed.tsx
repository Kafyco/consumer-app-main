import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import LottieView from 'lottie-react-native';

import useSelector from 'hooks/useSelector';
import { Order as OrderType } from 'api/models';
import { selectCurrentUser } from 'reducers/app';
import { priceFunctionFactory } from 'utils/price';
import { paymentMethodFromOrder } from 'utils/paymentMethods';
import { CARD_PAYMENT_CODES } from 'constants/Payments';

import { Text, Title } from 'components/Text';
import Sheet from 'components/Sheet';
import Address from 'components/Address';
import OrderSummary, { SummaryLinesType } from 'components/OrderSummary';
import PaymentCard from 'components/PaymentCard';
import SupportBlock from 'components/SupportBlock';
import PaymentMethod from 'components/PaymentMethod';

const OrderConfirmed = ({ order }: { order: OrderType }) => {
  const [t] = useTranslation();
  const { shippingAddress } = order;
  const currentUser = useSelector(selectCurrentUser);
  const paymentMethod = paymentMethodFromOrder(order);
  const price = React.useCallback(priceFunctionFactory(order.currency), [order]);

  const summary = React.useMemo(() => {
    const result: SummaryLinesType[] = [
      {
        label: t('subtotal'),
        sum: price(order.basketTotalBeforeDiscountsInclTax),
      },
      {
        label: t('delivery-fee'),
        sum: price(order.shippingInclTax),
      },
    ];
    const discount: number = order.basketTotalInclTax - order.basketTotalBeforeDiscountsInclTax;

    if (discount) {
      result.push({
        label: t('total-discount'),
        bold: true,
        color: 'danger',
        sum: price(discount),
      });
    }

    return result.concat([
      {
        divider: true,
        label: (
          <>
            {t('total')}&nbsp;
            <Text size={14} color="secondary" weight="regular">
              ({t('incl-tax')})
            </Text>
          </>
        ),
        sum: price(order.totalInclTax),
        bold: true,
      },
      {
        label: t('total-vat'),
        sum: price(order.totalTax),
      },
    ]);
  }, [order]);

  return (
    <>
      <View style={styles.thanks}>
        <Title level={2}>{t('thanks-for-order')} 🤗</Title>
      </View>

      <Sheet style={styles.confirmation}>
        <View>
          <LottieView
            source={require('assets/lottie/animation-success.json')}
            autoPlay
            loop={false}
            style={styles.animation}
          />
        </View>
        <View style={styles.confirmationTitle}>
          <Title level={1}>{t('order-placed')}</Title>
          <Text color="secondary" align="center">
            {t('order-no')}&nbsp;
            <Text color="regular" weight="bold">
              {order.number}
            </Text>
          </Text>
        </View>
        <View style={styles.confirmationDescr}>
          <Text align="center">{t('confirmation-description')}</Text>
          <Text align="center" weight="bold">
            {currentUser?.email}
          </Text>
        </View>
      </Sheet>

      <Sheet title={t('delivery-to')} style={styles.section}>
        <Address info={shippingAddress} padded />
      </Sheet>

      <Sheet title={t('payment')} style={styles.section}>
        <View>
          {CARD_PAYMENT_CODES.includes(paymentMethod.code) && paymentMethod.info ? (
            <PaymentCard info={paymentMethod.info} />
          ) : (
            <PaymentMethod code={paymentMethod.code} withDescription={false} />
          )}
        </View>
      </Sheet>

      <Sheet title={t('order-summary')} style={styles.section}>
        <OrderSummary lines={summary} />
        <Text size={14} color="secondary" style={styles.invoiceDescr}>
          {t('invoice-later')}
        </Text>
      </Sheet>

      <SupportBlock style={styles.section} emailSubject={`Order ${order.number}`}>
        <Text size={16}>{t('order-support')}</Text>
      </SupportBlock>
    </>
  );
};

export default OrderConfirmed;

const styles = StyleSheet.create({
  confirmation: {
    paddingTop: 0,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  thanks: {
    marginVertical: 16,
    alignItems: 'center',
  },
  animation: {
    width: 250,
    height: 250,
  },
  confirmationTitle: {
    marginTop: -24,
  },
  confirmationDescr: {
    marginVertical: 24,
  },
  section: {
    paddingTop: 12,
    paddingBottom: 16,
    paddingHorizontal: 24,
    marginBottom: 8,
  },
  invoiceDescr: {
    marginTop: 16,
    marginBottom: 8,
  },
});
