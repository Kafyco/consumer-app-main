import * as React from 'react';
import { View, StyleSheet, TextInput } from 'react-native';
import { useTranslation } from 'react-i18next';
import { unwrapResult } from '@reduxjs/toolkit';

import useDispatch from 'hooks/useDispatch';
import { Basket as BasketType, VoucherDiscount } from 'api/models';
import { applyVoucher, removeVoucher, fetchMerchantBasket } from 'reducers/basket';
import { useMerchant } from 'utils/merchantContext';
import useIsMounted from 'hooks/useIsMounted';

import { Text } from 'components/Text';
import Button from 'components/Button';

interface Props {
  basket: BasketType;
}

const CouponBlock = ({ basket }: Props) => {
  const { merchantId } = useMerchant();
  const { voucherDiscounts } = basket;
  const isCouponApplied = Boolean(voucherDiscounts?.length);
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const isMounted = useIsMounted();
  const [fieldValue, setFieldValue] = React.useState<string>('');
  const [fieldError, setFieldError] = React.useState<boolean>(false);
  const [applying, setApplying] = React.useState(false);
  const [removing, setRemoving] = React.useState(false);

  const handleApplyVoucher = async () => {
    setApplying(true);
    setFieldError(false);
    try {
      const action = await dispatch(applyVoucher(fieldValue));
      unwrapResult(action);
      setFieldError(false);
    } catch (_) {
      setFieldError(true);
    } finally {
      setApplying(false);
    }
  };
  const handleRemoveVoucher = async (id: string | number) => {
    setRemoving(true);
    await dispatch(removeVoucher(id));
    await dispatch(fetchMerchantBasket(merchantId));
    isMounted() && setRemoving(false);
  };

  const renderCoupon = ({ voucher }: VoucherDiscount) => (
    <View key={voucher.id} style={styles.voucher}>
      <View>
        <Text size={14}>{voucher.name}</Text>
        <Text size={12} color="secondary">
          {voucher.code}
        </Text>
      </View>
      <Button micro uppercase loading={removing} onPress={() => handleRemoveVoucher(voucher.id)}>
        {t('remove')}
      </Button>
    </View>
  );

  return (
    <View style={styles.container}>
      {isCouponApplied ? (
        voucherDiscounts.map(renderCoupon)
      ) : (
        <>
          <View style={styles.wrap}>
            <TextInput
              placeholder={t('coupon-textfield-placeholder')}
              placeholderTextColor="#919191"
              style={styles.input}
              clearButtonMode="while-editing"
              autoCorrect={false}
              onChangeText={(value) => setFieldValue(value)}
            />
            <Button micro uppercase loading={applying} onPress={handleApplyVoucher}>
              {t('apply')}
            </Button>
          </View>
          {fieldError && (
            <Text color="danger" size={14} style={styles.error}>
              {t('coupon-invalid')}
            </Text>
          )}
        </>
      )}
    </View>
  );
};

export default CouponBlock;

const styles = StyleSheet.create({
  container: {
    marginBottom: 8,
  },

  wrap: {
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.09)',
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'lato-regular',
    height: 48,
    paddingHorizontal: 16,
  },
  voucher: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  error: {
    marginTop: 4,
  },
});
