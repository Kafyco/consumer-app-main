import * as React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { useTranslation } from 'react-i18next';

import Colors from 'constants/Colors';
import Text from 'components/Text';
import Icon from 'components/Icon';

interface PaymentCardProps {
  code: string;
  style?: ViewStyle;
  withDescription?: boolean;
}

const PaymentMethod = ({ code, style, withDescription = true }: PaymentCardProps) => {
  const [t] = useTranslation();
  const paymentsInfo = {
    cod: {
      icon: 'money',
      title: t('payment-method.cod-title'),
      description: t('payment-method.cod-description'),
    },
    codc: {
      icon: 'credit-card',
      title: t('payment-method.codc-title'),
      description: t('payment-method.codc-description'),
    },
    default: {
      icon: 'money',
      title: code,
    },
  };
  const { icon, title, description } = paymentsInfo[code] ?? paymentsInfo['default'];

  return (
    <View style={[styles.container, style]}>
      <View style={styles.row}>
        <Icon name={icon} size={24} style={styles.icon} color={Colors.primary} />
        <Text size={14}>{title}</Text>
      </View>
      {withDescription && description && (
        <Text size={14} color="secondary">
          {description}
        </Text>
      )}
    </View>
  );
};

export default PaymentMethod;

const styles = StyleSheet.create({
  container: {},
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginEnd: 8,
  },
});
