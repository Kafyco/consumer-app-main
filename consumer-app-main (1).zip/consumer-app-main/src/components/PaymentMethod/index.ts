export { default } from './PaymentMethod';
