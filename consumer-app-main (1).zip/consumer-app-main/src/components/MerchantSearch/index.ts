export { default } from './MerchantSearch';
