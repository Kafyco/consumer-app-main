import React from 'react';
import { View, StyleSheet } from 'react-native';

import Layout from 'constants/Layout';
import SearchInput from 'components/SearchInput';

export const CATEGORY_SEARCH_HEIGHT = 40;

export interface MerchantSearchProps {
  placeholder: string;
  onSearchBegin?(): void;
}

const MerchantSearch = ({ placeholder, onSearchBegin }: MerchantSearchProps) => {
  return (
    <View style={[styles.container]}>
      <SearchInput placeholder={placeholder} onFocus={onSearchBegin} />
    </View>
  );
};

export default MerchantSearch;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Layout.screenPadding,
  },
});
