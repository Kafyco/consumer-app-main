import * as React from 'react';
import { View } from 'react-native';
import { Title } from 'components/Text';

interface SectionHeaderProps {
  title: string;
  index: number;
  onMeasure?(index: number, positionY: number): void;
}

const SectionHeader = ({ title, index, onMeasure }: SectionHeaderProps) => (
  <View
    style={{ paddingTop: 24 }}
    onLayout={(e) =>
      onMeasure &&
      e.currentTarget.measure(
        (fx: number, fy: number, w: number, h: number, px: number, py: number) => {
          onMeasure(index, py);
        },
      )
    }
  >
    <Title level={2}>{title}</Title>
  </View>
);

export default SectionHeader;
