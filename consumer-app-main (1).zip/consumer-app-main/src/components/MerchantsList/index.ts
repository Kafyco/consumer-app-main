export { default } from './MerchantsList';
