import * as React from 'react';
import {
  View,
  SectionList,
  SectionListProps,
  SectionListData,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated from 'react-native-reanimated';
import { useTranslation } from 'react-i18next';

import Layout from 'constants/Layout';
import { Partner as MerchantType } from 'api/models';
import MerchantCard from 'components/MerchantCard';
import EmptyScreen from 'components/EmptyScreen';

import SectionHeader from './SectionHeader';

interface MerchantsListProps extends SectionListProps<MerchantType> {
  sections: SectionListData<MerchantType>[];
  topPlaceholderHeight?: number;
  onMerchantPress?(item: MerchantType): void;
  onScroll?(event: NativeSyntheticEvent<NativeScrollEvent>): void;
  onCategoryMeasure?(index: number, positionY: number): void;
}

const AnimatedSectionList =
  Animated.createAnimatedComponent<SectionListProps<MerchantType>>(SectionList);

const MerchantsList = React.forwardRef<SectionList, MerchantsListProps>(
  (
    { sections, topPlaceholderHeight, onMerchantPress, onScroll, onCategoryMeasure, ...otherProps },
    ref,
  ) => {
    const [t] = useTranslation();
    const insets = useSafeAreaInsets();
    const containerStyles = {
      paddingHorizontal: Layout.screenPadding,
      paddingBottom: insets.bottom + 40,
      paddingTop: insets.top,
    };

    // Conditional properties to pass to SectionList
    const conditionalProps = React.useMemo(() => {
      let props: any = {};

      if (topPlaceholderHeight) {
        props.ListHeaderComponent = () => <View style={{ height: topPlaceholderHeight }} />;
      }

      return props;
    }, [topPlaceholderHeight]);

    return (
      <AnimatedSectionList
        ref={ref}
        sections={sections}
        keyExtractor={(item, index) => item.id + index}
        renderItem={({ item }) => (
          <MerchantCard merchant={item} onPress={() => onMerchantPress?.(item)} />
        )}
        renderSectionHeader={({ section: { index, title } }) => (
          <SectionHeader title={title} index={index} onMeasure={onCategoryMeasure} />
        )}
        ListEmptyComponent={() => (
          <EmptyScreen
            image={require('assets/images/Larry__Location.png')}
            title={t('merchants-list.empty-title')}
            text={t('merchants-list.empty-text')}
          />
        )}
        contentContainerStyle={containerStyles}
        stickySectionHeadersEnabled={false}
        showsVerticalScrollIndicator={false}
        scrollEventThrottle={8}
        onScroll={onScroll}
        {...conditionalProps}
        {...otherProps}
      />
    );
  },
);

export default MerchantsList;
