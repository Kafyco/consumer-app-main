import * as React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { useTranslation } from 'react-i18next';

import { Title, Text } from 'components/Text';
import Button from 'components/Button';

interface OrdersEmptyProps {
  title?: string;
  description?: string;
  buttonLabel?: string;
  onButtonPress?(): void;
}

const OrdersEmpty = ({ title, description, buttonLabel, onButtonPress }: OrdersEmptyProps) => {
  const [t] = useTranslation();

  return (
    <View style={styles.container}>
      <Image
        source={require('assets/images/Larry__Connection_Lost.png')}
        resizeMode="contain"
        style={styles.illustration}
      />
      <View style={styles.content}>
        <Title level={2} align="center">
          {title || t('empty-orders-title')}
        </Title>
        <Text align="center">{description || t('empty-orders-descr')}</Text>
        <Button mode="contained" onPress={onButtonPress} style={styles.button}>
          {buttonLabel || t('find-supplier')}
        </Button>
      </View>
    </View>
  );
};

export default OrdersEmpty;

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    alignContent: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  content: {
    justifyContent: 'center',
    alignItems: 'center',
    maxWidth: 360,
    paddingBottom: 100,
  },
  illustration: {
    width: 320,
    height: 320,
    marginBottom: 24,
  },
  button: {
    width: 200,
    marginTop: 24,
  },
});
