import * as React from 'react';
import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';

import { Order as OrderType } from 'api/models';
import Colors from 'constants/Colors';
import { getStatusColorName } from 'utils/order';
import getImageUrl from 'utils/getImageUrl';
import getAddressName from 'utils/getAddressName';

import Sheet from 'components/Sheet';
import { Text, Title } from 'components/Text';
import Icon from 'components/Icon';
import NoImage from 'components/NoImage';
import { priceFunctionFactory } from 'utils/price';

interface OrderCardProps {
  order: OrderType;
  onPress?(): void;
}

const OrderCard = ({ order, onPress }: OrderCardProps) => {
  const { number, partner, datePlaced, status, shippingAddress } = order;
  const [t] = useTranslation();
  const logo = React.useMemo(() => getImageUrl(partner.logoThumbnail, '80x80'), [order]);
  const price = React.useCallback(priceFunctionFactory(order.currency), [order]);
  const date = new Date(parseFloat(datePlaced) * 1000);
  const statusColor = React.useMemo(() => getStatusColorName(status), [order]);

  return (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress}>
      <Sheet style={styles.sheet}>
        <View style={styles.logoContainer}>
          {logo ? (
            <Image source={{ uri: logo }} resizeMode="contain" style={styles.logo} />
          ) : (
            <NoImage style={styles.logo} resizeMode="contain" />
          )}
        </View>
        <View style={styles.content}>
          <Title level={3} style={styles.title}>
            {partner.name}
          </Title>
          <View style={styles.line}>
            <Text size={14} color={statusColor}>
              {t(`order-status.${status}`)}
            </Text>
          </View>
          <View style={styles.line}>
            <Text size={14} color="secondary">
              {t('order-no')}
              <Text size={14} color="regular">
                {number}
              </Text>
            </Text>
          </View>
          <View style={styles.line}>
            <Text size={14} color="secondary">
              {t('order-total')}:{' '}
              <Text size={14} color="regular">
                {price(order.totalInclTax)}
              </Text>
            </Text>
          </View>
          <View style={styles.line}>
            <Text size={14} color="secondary">
              {t('order-placed')}:{' '}
              <Text size={14} color="regular">
                {dayjs(date).format('DD.MM.YYYY')}
              </Text>
            </Text>
          </View>
          <View style={styles.delivery}>
            <Text size={14} color="secondary">
              {t('delivery-to')}:{' '}
            </Text>
            <View style={styles.addressName}>
              <Text size={14}>{getAddressName(shippingAddress)}</Text>
            </View>
          </View>
        </View>
        <View style={styles.icon}>
          <Icon size={24} name="caret-right" color={Colors.light} />
        </View>
      </Sheet>
    </TouchableOpacity>
  );
};

export default OrderCard;

const styles = StyleSheet.create({
  sheet: {
    flexDirection: 'row',
    alignContent: 'stretch',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
  },
  logoContainer: {
    width: 40,
  },
  logo: {
    width: 40,
    height: 40,
    borderWidth: 1,
    borderColor: '#ebebeb',
    borderRadius: 20,
  },
  icon: {
    justifyContent: 'center',
  },
  content: {
    paddingStart: 16,
    flexGrow: 1,
  },
  title: {
    marginBottom: 4,
  },
  line: {
    marginBottom: 4,
  },
  delivery: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: -2,
  },
  addressName: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    backgroundColor: '#ebebeb',
    borderRadius: 8,
  },
});
