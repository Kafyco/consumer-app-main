import * as React from 'react';
import { StyleSheet, View, TextInput, TextInputProps } from 'react-native';
import Icon from 'components/Icon';
import { useTranslation, Trans } from 'react-i18next';

const SearchInput = React.forwardRef<TextInput, TextInputProps>(
  ({ style, placeholder, ...props }, inputRef) => {
    const [t] = useTranslation();
    return (
      <View style={styles.wrap}>
        <View style={styles.iconWrap}>
          <Icon name="magnifying-glass" size={24} style={styles.icon} />
        </View>
        <TextInput
          ref={inputRef}
          placeholder={placeholder ?? t('search')}
          placeholderTextColor="#919191"
          style={[styles.input, style]}
          returnKeyType="search"
          clearButtonMode="while-editing"
          autoCorrect={false}
          {...props}
        />
      </View>
    );
  },
);

export default SearchInput;

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'stretch',
    borderRadius: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.09)',
  },
  wrapFocused: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  wrapBlured: {
    backgroundColor: 'rgba(0, 0, 0, 0.09)',
  },
  iconWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    color: '#91918D',
    width: 40,
    height: 40,
  },
  icon: {
    color: '#91918D',
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'lato-regular',
  },
});
