import * as React from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trans } from 'react-i18next';

import Layout from 'constants/Layout';
import { Title, Text } from 'components/Text';

export interface ErrorScreenProps {
  title?: string;
  message?: string;
}

const ErrorScreen = ({ title, message }: ErrorScreenProps) => (
  <SafeAreaView>
    <View style={{ paddingHorizontal: Layout.screenPadding }}>
      <Title level={1}>{title ?? <Trans i18nKey="error.default-title">Ooops!</Trans>}</Title>
      <Text>{message ?? <Trans i18nKey="error.default-message">Something went wrong.</Trans>}</Text>
    </View>
  </SafeAreaView>
);

export default ErrorScreen;
