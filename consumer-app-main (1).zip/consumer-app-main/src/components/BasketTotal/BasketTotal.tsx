import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useNavigation, NavigationProp } from '@react-navigation/native';

import { Basket, ShippingMethod } from 'api/models';
import { priceFunctionFactory } from 'utils/price';
import { MerchantRootParamList } from 'navigation/MerchantRoot';
import { useMerchant } from 'utils/merchantContext';

import Text from 'components/Text';
import BottomSheet from 'components/BottomSheet';
import Button from 'components/Button';
import Icon from 'components/Icon';
import MinOrderLabel from 'components/MinOrderLabel';

export const BASKET_TOTAL_HEIGHT = 168;

interface BasketTotalProps {
  basket: Basket;
  shipping?: ShippingMethod;
}
const BasketTotal = ({ basket, shipping }: BasketTotalProps) => {
  const { merchant } = useMerchant();
  const [t] = useTranslation();
  const navigation = useNavigation<NavigationProp<MerchantRootParamList>>();
  const price = React.useCallback(priceFunctionFactory(basket.currency), [basket]);
  const minOrderAmount = Number(merchant?.deliverySettings?.minOrderAmount);
  const canPlaceOrder = basket.totalInclTax >= minOrderAmount;

  const handleOnPress = () => {
    navigation.navigate('MerchantCheckout');
  };

  const renderShipping = () => {
    if (shipping) {
      return (
        <Text size={14} weight="bold">
          {price(shipping.price.inclTax)}
        </Text>
      );
    }

    return <Icon name="spinner" size={16} />;
  };

  return (
    <BottomSheet positionStatic>
      <View style={styles.row}>
        <Text size={14} weight="bold">
          {t('total')}&nbsp;
          <Text size={14} color="secondary">
            ({t('incl-tax')})
          </Text>
        </Text>
        <Text size={14} weight="bold">
          {price(basket.totalInclTaxExclDiscounts)}
        </Text>
      </View>
      <View style={styles.row}>
        <Text size={14} weight="bold">
          {t('delivery-fee')}
        </Text>
        {renderShipping()}
      </View>
      {!canPlaceOrder && (
        <View style={styles.row}>
          <MinOrderLabel delivery={merchant?.deliverySettings} color="warning" weight="bold" />
          <Text size={14} color="warning" weight="bold">
            {t('add-more-to-place-order', { amount: price(minOrderAmount - basket.totalInclTax) })}
          </Text>
        </View>
      )}
      <View style={styles.checkout}>
        <Button disabled={!canPlaceOrder} mode="contained" onPress={handleOnPress}>
          {t('checkout')}
        </Button>
      </View>
    </BottomSheet>
  );
};

export default BasketTotal;

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 4,
  },
  checkout: {
    marginTop: 12,
  },
});
