export { default } from './NoImage';
