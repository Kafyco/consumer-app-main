import * as React from 'react';
import { Image, ImageProps } from 'react-native';

import Colors from 'constants/Colors';

export type NoImageProps = Omit<ImageProps, 'source'>;

const NoImage = ({ style, ...props }: NoImageProps) => {
  return (
    <Image
      source={require('assets/images/default/NoImage.png')}
      style={[style, { tintColor: Colors.primary }]}
      {...props}
    />
  );
};

export default NoImage;
