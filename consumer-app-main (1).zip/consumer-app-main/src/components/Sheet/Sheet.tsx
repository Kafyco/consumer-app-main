import * as React from 'react';
import { View, StyleSheet, ViewStyle, StyleProp } from 'react-native';

import Colors from 'constants/Colors';
import Button from 'components/Button';
import { Title } from 'components/Text';

type ActionType = {
  label: string;
  onPress(): void;
};

interface SheetProps {
  title?: string;
  action?: ActionType;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
}

const Sheet = ({ title, action, style, children }: SheetProps) => (
  <View style={[styles.defaultStyles, StyleSheet.flatten(style)]}>
    {title ? (
      <View style={styles.titleRow}>
        <Title level={3} style={styles.title}>
          {title}
        </Title>
        {action ? (
          <Button mode="text" compact onPress={action.onPress} labelStyle={{ fontSize: 14 }}>
            {action.label}
          </Button>
        ) : null}
      </View>
    ) : null}
    {children}
  </View>
);

export default Sheet;

const styles = StyleSheet.create({
  defaultStyles: {
    padding: 24,
    borderRadius: 20,
    backgroundColor: Colors.white,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginEnd: -12,
    marginBottom: 0,
  },
  title: {
    marginBottom: 12,
  },
});
