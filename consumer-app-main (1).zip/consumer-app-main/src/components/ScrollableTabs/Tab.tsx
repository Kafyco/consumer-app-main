import * as React from 'react';
import { TouchableOpacity, View, ViewStyle } from 'react-native';
import Text from 'components/Text';
import Colors from 'constants/Colors';

export interface TabProps {
  id?: number | string;
  title: string;
  active?: boolean;
  disabled?: boolean;
  onPress?(): void;
}

const Tab = ({ title, active, disabled, onPress }: TabProps) => {
  return (
    <TouchableOpacity disabled={disabled} onPress={onPress}>
      <View style={[tabStyle, active && activeTabStyle, disabled && disabledTabStyle]}>
        <Text size={16} color={active ? 'white' : 'primary'}>
          {title}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

export default Tab;

const tabStyle: ViewStyle = {
  paddingVertical: 4,
  paddingHorizontal: 12,
  backgroundColor: Colors.white,
  borderRadius: 8,
};

const activeTabStyle: ViewStyle = {
  backgroundColor: Colors.primary,
};

const disabledTabStyle: ViewStyle = {
  opacity: 0.5,
};
