import React, { MutableRefObject } from 'react';
import { FlatList, View, ViewStyle } from 'react-native';

import Layout from 'constants/Layout';
import Tab, { TabProps } from './Tab';

export const SCROLLABLE_TABS_HEIGHT = 48;

export interface ScrollableTabsProps {
  data: TabProps[];
  scrollOnPress?: boolean;
  onPress?(item: any, index: number): void;
}

const ScrollableTabs = React.forwardRef<FlatList<TabProps>, ScrollableTabsProps>(
  ({ data, scrollOnPress, onPress }, ref) => {
    const listRef = React.useRef<FlatList | null>(null);
    const handleOnPress = (item: TabProps, index: number) => {
      if (scrollOnPress) {
        listRef?.current?.scrollToIndex({
          index,
          viewOffset: Layout.screenPadding,
        });
      }

      onPress?.(item, index);
    };

    return (
      <FlatList
        ref={(node) => {
          listRef.current = node;
          if (typeof ref === 'function') {
            ref(node);
          } else if (ref) {
            ref.current = node;
          }
        }}
        horizontal
        data={data}
        renderItem={({ item, index }) => (
          <View style={itemStyle}>
            <Tab {...item} onPress={() => handleOnPress(item, index)} />
          </View>
        )}
        keyExtractor={(item) => item.title}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={containerStyles}
      />
    );
  },
);

const ITEMS_MARGIN = 4;

const itemStyle: ViewStyle = {
  marginHorizontal: ITEMS_MARGIN,
};

const containerStyles: ViewStyle = {
  paddingHorizontal: Layout.screenPadding - ITEMS_MARGIN,
  paddingVertical: 8,
};

export default ScrollableTabs;
