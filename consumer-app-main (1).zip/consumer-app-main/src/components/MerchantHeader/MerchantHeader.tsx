import React from 'react';
import { Image, StyleSheet, View } from 'react-native';
import Animated, { interpolate, Extrapolate, useAnimatedStyle } from 'react-native-reanimated';
import { EdgeInsets } from 'react-native-safe-area-context';

import ScreenHeader from 'components/ScreenHeader';
import Text, { Title } from 'components/Text';
import NoImage from 'components/NoImage';
import DeliveryLabel from 'components/DeliveryLabel';
import MinOrderLabel from 'components/MinOrderLabel';
import Favourite from 'components/Favourite';

import { SPRING_SIZE } from 'constants/Layout';
import { Partner } from 'api/models';
import getImageUrl from 'utils/getImageUrl';

// Consts
export const MERCHANT_HEADER_HEIGHT = 176;

export interface MerhcnatHeaderProps {
  merchant: Partner;
  scrollY: Animated.SharedValue<number>;
  insets: EdgeInsets;
  onFavouriteToggle?(): void;
}

const MerchantHeader = ({ merchant, scrollY, insets, onFavouriteToggle }: MerhcnatHeaderProps) => {
  const { id, name, logoThumbnail, deliverySettings } = merchant;
  const logo = React.useMemo(() => getImageUrl(logoThumbnail, '80x80'), [id]);
  const merchantHeight = MERCHANT_HEADER_HEIGHT + insets.top;

  // Animations
  const containerStyles = useAnimatedStyle(
    () => ({
      top: interpolate(scrollY.value, [0, merchantHeight], [0, -merchantHeight], Extrapolate.CLAMP),
      height: interpolate(
        scrollY.value,
        [-SPRING_SIZE, 0],
        [merchantHeight + SPRING_SIZE, merchantHeight],
        Extrapolate.CLAMP,
      ),
      paddingTop: insets.top,
    }),
    [scrollY],
  );
  const navigationStyles = useAnimatedStyle(
    () => ({
      top: interpolate(
        scrollY.value,
        [0, MERCHANT_HEADER_HEIGHT - 40],
        [0, MERCHANT_HEADER_HEIGHT - 40],
        Extrapolate.CLAMP,
      ),
      opacity: interpolate(
        scrollY.value,
        [0, MERCHANT_HEADER_HEIGHT / 2, MERCHANT_HEADER_HEIGHT - 40],
        [1, 1, 0],
        Extrapolate.CLAMP,
      ),
    }),
    [scrollY],
  );
  const infoStyles = useAnimatedStyle(
    () => ({
      opacity: interpolate(
        scrollY.value,
        [0, MERCHANT_HEADER_HEIGHT / 3, MERCHANT_HEADER_HEIGHT - 40],
        [1, 1, 0],
        Extrapolate.CLAMP,
      ),
    }),
    [scrollY],
  );

  return (
    <Animated.View style={[styles.container, containerStyles]}>
      <View style={[styles.content, { top: insets.top }]}>
        <Animated.View style={[styles.merchantInfo, infoStyles]}>
          {logo ? (
            <Image source={{ uri: logo }} style={styles.logo} />
          ) : (
            <NoImage style={styles.logo} />
          )}
          <View style={styles.titleContainer}>
            <Title
              level={1}
              align="center"
              style={styles.title}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.6}
            >
              {name}
            </Title>
          </View>
          <View style={styles.info}>
            <DeliveryLabel delivery={deliverySettings} inverted />
            <View>
              <Text size={14} color="white">
                &nbsp;•&nbsp;
              </Text>
            </View>
            <View>
              <MinOrderLabel delivery={deliverySettings} color="white" />
            </View>
          </View>
        </Animated.View>
      </View>
      <ScreenHeader
        tintColor="white"
        style={[styles.navigation, navigationStyles]}
        actions={<Favourite active={merchant.isFavourite} onPress={onFavouriteToggle} />}
      />
    </Animated.View>
  );
};

export default MerchantHeader;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  content: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    left: 0,
    top: 0,
  },
  navigation: {
    position: 'absolute',
    left: 0,
    top: 0,
    right: 0,
  },
  merchantInfo: {
    alignItems: 'center',
    position: 'absolute',
    left: '10%',
    top: '50%',
    width: '80%',
    height: 144,
    transform: [{ translateY: -72 }],
  },
  logo: {
    borderWidth: 4,
    borderColor: 'white',
    borderRadius: 36,
    height: 72,
    width: 72,
    marginBottom: 8,
    backgroundColor: '#e6e6e6',
  },
  titleContainer: {
    width: '100%',
  },
  title: {
    color: 'white',
    marginBottom: 4,
  },
  info: {
    flexDirection: 'row',
    flexWrap: 'nowrap',
    justifyContent: 'center',
    alignItems: 'center',
    maxWidth: '100%',
  },
});
