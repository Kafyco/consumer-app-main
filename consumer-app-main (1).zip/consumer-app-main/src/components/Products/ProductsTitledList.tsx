import * as React from 'react';
import {
  View,
  SectionList,
  SectionListData,
  SectionBase,
  StyleSheet,
  StyleProp,
  ViewStyle,
  SectionListProps,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import Animated from 'react-native-reanimated';
import { ActivityIndicator } from 'react-native-paper';

import { Product as ProductType } from 'api/models';
import useSelector from 'hooks/useSelector';
import { selectAllBasketLines, getProductsQty } from 'reducers/basket';

import { Title } from 'components/Text';
import Product from './Product';
import NoProducts from './NoProducts';

interface SectionProps extends SectionBase<ProductType> {
  title: string;
}

export type SectionListType = SectionListData<ProductType, SectionProps>;

export interface ProductsTitledListProps {
  title: string;
  items: ProductType[];
  isLoading?: boolean;
  emptyMessage?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  extraData?: any;
  onScroll?(event: NativeSyntheticEvent<NativeScrollEvent>): void;
  onLoadMore?(): void;
  onProductPress?(product: ProductType): void;
}

const AnimatedSectionList =
  Animated.createAnimatedComponent<SectionListProps<ProductType>>(SectionList);

const ProductsTitledList = React.forwardRef<SectionList, ProductsTitledListProps>(
  (
    {
      title,
      items,
      isLoading,
      emptyMessage,
      style,
      extraData,
      onScroll,
      onLoadMore,
      onProductPress,
    },
    ref,
  ) => {
    const basketLines = useSelector(selectAllBasketLines);
    const productsQty = React.useMemo(() => getProductsQty(basketLines), [basketLines]);
    const sections = React.useMemo(() => {
      if (items?.length) {
        return [
          {
            title,
            data: items,
          },
        ];
      }
      return [];
    }, [items]);

    const renderItem = ({ item }: { item: ProductType }) => (
      <View style={styles.item}>
        <Product
          item={item}
          basketQty={productsQty[item.id]}
          onPress={() => onProductPress?.(item)}
        />
      </View>
    );

    const renderSectionHeader = ({ section }) => (
      <View style={styles.title}>
        <Title level={2}>{section.title}</Title>
      </View>
    );

    const renderLoading = () => (
      <View style={styles.loading}>
        <ActivityIndicator />
      </View>
    );

    return (
      <AnimatedSectionList
        ref={ref}
        sections={sections}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        renderSectionHeader={renderSectionHeader}
        ListEmptyComponent={() =>
          isLoading ? null : (
            <View>
              {renderSectionHeader({ section: { title } })}
              <NoProducts emptyMessage={emptyMessage} />
            </View>
          )
        }
        ListFooterComponent={() => (isLoading ? renderLoading() : null)}
        contentContainerStyle={[styles.container, style]}
        onScroll={onScroll}
        onEndReached={onLoadMore}
        onEndReachedThreshold={5}
        scrollEventThrottle={8}
        showsVerticalScrollIndicator={false}
        stickySectionHeadersEnabled={false}
        extraData={productsQty}
      />
    );
  },
);

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 12,
  },
  title: {
    marginTop: 24,
  },
  item: {
    marginVertical: 4,
  },
  loading: {
    paddingVertical: 32,
  },
});

export default ProductsTitledList;
