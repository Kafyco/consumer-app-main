import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';

import { Product as ProductType } from 'api/models';
import { getUnitsSymbol } from 'utils/uom';
import { priceAmount, priceWithCurrency } from 'utils/price';
import { Text } from 'components/Text';

interface Props {
  item: ProductType;
}

const ProductPrice = ({ item }: Props) => {
  const { attrs, currency, price, priceWas, unit } = item;
  const [t] = useTranslation();
  const unitsString = React.useMemo(() => getUnitsSymbol(unit), [item]);
  const itemPrice = attrs?.packageQty && price / attrs.packageQty;
  const itemPriceWas = attrs?.packageQty && priceWas / attrs.packageQty;

  if (priceWas) {
    return itemPrice ? (
      <View style={styles.container}>
        <View style={styles.price}>
          <Text color="danger" size={10} weight="bold">
            {currency?.toUpperCase()}
          </Text>
          <Text color="danger" size={14} weight="bold">
            &nbsp;{priceAmount(itemPrice)}
          </Text>
          <Text color="danger" size={12} style={styles.uom}>
            &nbsp;/each
          </Text>

          <Text color="secondary" size={12} strike style={styles.priceWas}>
            {priceWithCurrency(currency, itemPriceWas)}
          </Text>
        </View>
        <View style={styles.price}>
          <Text color="danger" size={12}>
            {priceWithCurrency(currency, price)}&nbsp;
            {unit ? t('per-unit', { unit: unitsString }) : t('per-each')}
          </Text>
        </View>
      </View>
    ) : (
      <View style={styles.container}>
        <View style={styles.price}>
          <Text color="danger" size={10} weight="bold">
            {currency?.toUpperCase()}
          </Text>
          <Text color="danger" size={14} weight="bold">
            &nbsp;{priceAmount(price)}
          </Text>
          <Text color="danger" size={12} style={styles.uom}>
            &nbsp;/{unitsString}
          </Text>

          <Text color="secondary" size={12} strike style={styles.priceWas}>
            {priceWithCurrency(currency, priceWas)}
          </Text>
        </View>
      </View>
    );
  }

  return itemPrice ? (
    <View style={styles.container}>
      <View style={styles.price}>
        <Text color="primary" size={10} weight="bold">
          {currency?.toUpperCase()}
        </Text>
        <Text color="primary" size={14} weight="bold">
          &nbsp;{priceAmount(itemPrice)}
        </Text>
        <Text color="primary" size={12} style={styles.uom}>
          &nbsp;/each
        </Text>
      </View>
      <View style={styles.price}>
        <Text color="primary" size={12}>
          {priceWithCurrency(currency, price)}&nbsp;
          {unit ? t('per-unit', { unit: unitsString }) : t('per-each')}
        </Text>
      </View>
    </View>
  ) : (
    <View style={styles.container}>
      <View style={styles.price}>
        <Text color="primary" size={10} weight="bold">
          {currency?.toUpperCase()}
        </Text>
        <Text color="primary" size={14} weight="bold">
          &nbsp;{priceAmount(price)}
        </Text>
        <Text color="primary" size={12} style={styles.uom}>
          &nbsp;/{unitsString}
        </Text>
      </View>
    </View>
  );
};

export default ProductPrice;

const styles = StyleSheet.create({
  container: {
    marginTop: 2,
  },
  price: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  uom: {
    opacity: 0.5,
  },
  priceWas: {
    marginStart: 8,
  },
});
