import React from 'react';
import { Trans } from 'react-i18next';
import { Title } from 'components/Text';

export interface NoProductsProps {
  emptyMessage?: React.ReactNode;
}

const NoProducts = ({ emptyMessage }: NoProductsProps) => (
  <Title level={4}>{emptyMessage ?? <Trans i18nKey="noproducts">No products found</Trans>}</Title>
);

export default NoProducts;
