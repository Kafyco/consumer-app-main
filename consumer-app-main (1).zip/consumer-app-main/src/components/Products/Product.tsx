import * as React from 'react';
import { View, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { useTranslation } from 'react-i18next';

import { Product as ProductType } from 'api/models';
import Colors from 'constants/Colors';
import getImageUrl from 'utils/getImageUrl';
import { getUnitsBareSymbol } from 'utils/uom';

import { Text, Title } from 'components/Text';
import NoImage from 'components/NoImage';
import Icon from 'components/Icon';
import ProductPrice from './ProductPrice';

export interface ProductProps {
  item: ProductType;
  basketQty?: string;
  onPress?(): void;
}

const Product = ({ item, basketQty, onPress }: ProductProps) => {
  const { id, title, primaryThumbnailImageUrl, attrs, displayQuantityMinimum } = item;
  const [t] = useTranslation();
  const primaryImageUrl = React.useMemo(() => getImageUrl(primaryThumbnailImageUrl, '88x88'), [id]);
  const unitsString = React.useMemo(() => getUnitsBareSymbol(item.unit), [item]);

  const renderItem = () => (
    <View style={styles.container}>
      <View style={styles.imageWrap}>
        {primaryImageUrl ? (
          <Image source={{ uri: primaryImageUrl }} style={styles.image} />
        ) : (
          <NoImage style={styles.image} />
        )}
        {attrs?.frozen ? (
          <View style={styles.imageIcon}>
            <Image source={require('assets/images/snowflake.png')} style={styles.iconsFrozen} />
          </View>
        ) : null}
      </View>
      <View style={styles.inner}>
        <View>
          <Title level={4} style={styles.title}>
            {title}
          </Title>
          {attrs?.countries?.length ? (
            <Text size={14} color="secondary">
              {attrs.countries.join(', ')}
            </Text>
          ) : attrs?.country ? (
            // TODO: cleanup
            <Text size={14} color="secondary">
              {attrs.country}
            </Text>
          ) : null}
        </View>

        <ProductPrice item={item} />
      </View>
      <View>
        <View style={[styles.button, basketQty ? styles.buttonAdded : null]}>
          <View style={styles.buttonSide} />
          <View style={styles.buttonCenter}>
            {basketQty ? (
              <Text color="primary" weight="bold">
                {basketQty} {unitsString}
              </Text>
            ) : (
              <Icon name="shopping-cart-simple-bold" size={20} color={Colors.primary} />
            )}
          </View>
          <View style={styles.buttonSide}>
            {parseFloat(displayQuantityMinimum) > 1 ? (
              <Text size={10} color="primary">
                {t('min')} {displayQuantityMinimum}
                {unitsString}
              </Text>
            ) : null}
          </View>
        </View>
      </View>
    </View>
  );

  return onPress ? (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress} style={styles.touchable}>
      {renderItem()}
    </TouchableOpacity>
  ) : (
    renderItem()
  );
};

const styles = StyleSheet.create({
  touchable: {
    borderRadius: 20,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'stretch',
    overflow: 'hidden',
    backgroundColor: '#fff',
    borderRadius: 20,
  },
  inner: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 8,
  },
  title: {
    lineHeight: 16,
  },
  pricesContainer: {
    marginTop: 2,
  },
  price: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  uom: {
    opacity: 0.5,
  },
  imageWrap: {
    width: 88,
    height: 88,
    position: 'relative',
  },
  image: {
    width: 88,
    height: 88,
    opacity: 0.8,
    resizeMode: 'contain',
  },
  imageIcon: {
    position: 'absolute',
    right: 4,
    bottom: 8,
    width: 24,
    height: 24,
  },
  iconsFrozen: {
    width: 24,
    height: 24,
  },
  button: {
    alignItems: 'center',
    alignContent: 'center',
    justifyContent: 'center',
    borderRadius: 16,
    width: 72,
    height: 80,
    margin: 8,
    backgroundColor: '#FBE6E8',
  },
  buttonAdded: {
    backgroundColor: '#F7CCD0',
  },
  buttonCenter: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  buttonSide: {
    justifyContent: 'center',
    opacity: 0.75,
    height: 24,
  },
});

export default Product;
