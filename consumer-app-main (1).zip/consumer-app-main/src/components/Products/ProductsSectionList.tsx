import * as React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import { Trans } from 'react-i18next';

import { Product as ProductType } from 'api/models';
import { ProductsSectionType } from 'reducers/productsSections';
import useSelector from 'hooks/useSelector';
import { selectAllBasketLines, getProductsQty } from 'reducers/basket';
import { MerchantRootParamList } from 'navigation/MerchantRoot';

import { Title, Text } from 'components/Text';
import MoreButton from 'components/MoreButton';

import Product from './Product';
import NoProducts from './NoProducts';

export type SectionType = {
  id: number | string;
  title: string;
  count: number;
  data: Array<ProductType>;
  merchantId: number | string;
};

export interface ProductsSectionListProps {
  sections: Array<ProductsSectionType>;
  emptyMessage?: React.ReactNode;
  onProductPress?(product: ProductType): void;
}

const ProductsSectionList = ({
  sections,
  emptyMessage,
  onProductPress,
}: ProductsSectionListProps) => {
  const navigation = useNavigation<NavigationProp<MerchantRootParamList>>();
  const basketLines = useSelector(selectAllBasketLines);
  const productsQty = React.useMemo(() => getProductsQty(basketLines), [basketLines]);

  if (!sections || !sections.length) {
    return <NoProducts emptyMessage={emptyMessage} />;
  }

  const onMore = (categoryId: string) => {
    navigation.navigate('MerchantCategory', { categoryId });
  };

  const childrens = React.useMemo<Array<React.ReactNode>>(
    () =>
      sections.reduce((res: any[], section: ProductsSectionType) => {
        const { data } = section;

        res.push(renderSectionTitle({ section, onMore }));

        if (data && data.length) {
          data.forEach((item) => {
            const basketQty = productsQty[item.id];
            res.push(
              renderItem({ section, item, basketQty, onPress: () => onProductPress?.(item) }),
            );
          });
          res.push(renderSectionFooter({ section, onMore }));
        } else {
          res.push(renderEmptySection({ section }));
        }

        return res;
      }, []),
    [sections, productsQty],
  );

  return <React.Fragment>{childrens}</React.Fragment>;
};

interface RenderSectionTitleFooterProps {
  section: ProductsSectionType;
  onMore?(categoryId: number | string): void;
}
const renderSectionTitle = ({ section: { id, title }, onMore }: RenderSectionTitleFooterProps) => (
  <View key={`s-${id}`} style={styles.sectionTitle}>
    <Title level={2}>{title}</Title>
    <MoreButton onPress={() => onMore?.(id)} />
  </View>
);

const renderSectionFooter = ({
  section: { id, count, data },
  onMore,
}: RenderSectionTitleFooterProps) => {
  const more = count - ((data && data.length) || 0);
  return more ? (
    <TouchableOpacity key={`f-${id}`} onPress={() => onMore?.(id)} style={styles.sectionFooter}>
      <Text color="secondary" size={14}>
        <Trans i18nKey="sectionMore" count={more}>
          and {{ count: more }} items more
        </Trans>
      </Text>
    </TouchableOpacity>
  ) : null;
};

interface RenderItemProps {
  section: ProductsSectionType;
  item: ProductType;
  basketQty: string;
  onPress?(): void;
}
const renderItem = ({ section, item, basketQty, onPress }: RenderItemProps) => (
  <View key={`p-${section.id}-${item.id}`} style={styles.listItem}>
    <Product item={item} basketQty={basketQty} onPress={onPress} />
  </View>
);

const renderEmptySection = ({ section }: { section: ProductsSectionType }) => (
  <View key={`p-empty-${section.id}`} style={styles.emptySection}>
    <Text size={14}>
      <Trans i18nKey="no-products-in-category">No products in this category</Trans>
    </Text>
  </View>
);

const styles = StyleSheet.create({
  sectionTitle: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  sectionFooter: {
    alignItems: 'center',
    paddingTop: 8,
    textAlign: 'center',
  },
  listItem: {
    marginVertical: 4,
  },
  emptySection: {
    marginVertical: 8,
    textAlign: 'center',
  },
});

export default ProductsSectionList;
