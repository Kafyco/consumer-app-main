import * as React from 'react';
import { View, StyleSheet, FlatList, FlatListProps, StyleProp, ViewStyle } from 'react-native';
import { ActivityIndicator } from 'react-native-paper';

import { Product as ProductType } from 'api/models';
import useSelector from 'hooks/useSelector';
import { selectAllBasketLines, getProductsQty } from 'reducers/basket';

import Product from './Product';
import NoProducts from './NoProducts';

export interface ProductsListProps {
  items: Array<ProductType>;
  emptyMessage?: React.ReactNode;
  ListEmptyComponent?: React.ComponentType<any> | React.ReactElement | null;
  ListHeaderComponent?: React.ComponentType<any> | React.ReactElement | null;
  style?: StyleProp<ViewStyle>;
  containerStyle?: StyleProp<ViewStyle>;
  isLoading?: boolean;
  onScroll?(): void;
  onProductPress?(product: ProductType): void;
}

const ProductsList = React.forwardRef<FlatList<ProductType>, ProductsListProps>(
  (
    {
      items,
      emptyMessage,
      ListEmptyComponent,
      ListHeaderComponent,
      style,
      containerStyle,
      isLoading,
      onScroll,
      onProductPress,
      ...props
    },
    ref,
  ) => {
    const basketLines = useSelector(selectAllBasketLines);
    const productsQty = React.useMemo(() => getProductsQty(basketLines), [basketLines]);

    const renderItem = ({ item }: { item: ProductType }) => (
      <View style={styles.item}>
        <Product
          item={item}
          basketQty={productsQty[item.id]}
          onPress={() => onProductPress?.(item)}
        />
      </View>
    );
    const renderLoading = () => (
      <View style={styles.loading}>
        <ActivityIndicator />
      </View>
    );
    const renderEmpty = () => {
      if (isLoading) {
        return null;
      }
      if (ListEmptyComponent) {
        return ListEmptyComponent;
      }
      return () => <NoProducts emptyMessage={emptyMessage} />;
    };

    return (
      <FlatList
        ref={ref}
        data={items}
        keyExtractor={(item) => `p-${item.id}`}
        renderItem={renderItem}
        ListEmptyComponent={renderEmpty()}
        ListHeaderComponent={ListHeaderComponent}
        ListFooterComponent={() => (isLoading ? renderLoading() : null)}
        onScroll={onScroll}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.container, containerStyle]}
        extraData={productsQty}
        {...props}
      />
    );
  },
);

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 12,
  },
  item: {
    marginVertical: 4,
  },
  loading: {
    paddingVertical: 32,
  },
});

export default ProductsList;
