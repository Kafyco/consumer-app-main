export { default } from './CoverImage';
