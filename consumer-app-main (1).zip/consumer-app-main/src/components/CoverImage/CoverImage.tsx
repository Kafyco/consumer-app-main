import * as React from 'react';
import { StyleSheet } from 'react-native';
import Animated, {
  interpolate,
  Extrapolate,
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { SPRING_SIZE } from 'constants/Layout';

const AnimatedGradient = Animated.createAnimatedComponent(LinearGradient);

export interface CoverImageProps {
  image: string;
  height?: number;
  scrollY: Animated.SharedValue<number>;
}

const CoverImage = ({ image, height = 120, scrollY }: CoverImageProps) => {
  const [loaded, setLoaded] = React.useState<boolean>(false);
  const containerStyles = useAnimatedStyle(
    () => ({
      top: interpolate(scrollY.value, [0, height], [0, -height], Extrapolate.CLAMP),
      height: interpolate(
        scrollY.value,
        [-SPRING_SIZE, 0],
        [height + SPRING_SIZE, height],
        Extrapolate.CLAMP,
      ),
    }),
    [scrollY],
  );

  const imageStyle = useAnimatedStyle(
    () => ({
      opacity: withTiming(loaded ? 1 : 0),
      height: interpolate(
        scrollY.value,
        [-SPRING_SIZE, 0],
        [height + SPRING_SIZE, height],
        Extrapolate.CLAMP,
      ),
    }),
    [scrollY, loaded],
  );

  return (
    <Animated.View style={[styles.container, containerStyles]}>
      {image ? (
        <Animated.Image
          onLoad={() => setLoaded(true)}
          source={{ uri: image }}
          style={[styles.image, imageStyle]}
        />
      ) : null}
      <AnimatedGradient
        colors={['rgba(0,0,0,0.15)', 'rgba(0,0,0,0.6)']}
        style={StyleSheet.absoluteFill}
      />
    </Animated.View>
  );
};

export default CoverImage;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    backgroundColor: '#4e4e4e',
  },
  image: {
    width: '100%',
    resizeMode: 'cover',
  },
});
