export const getSectionsTabs = (sections: any, activeTabIndex?: number) => {
  return sections.map(({ title }: any, index: number) => ({
    title,
    active: index === activeTabIndex,
  }));
};

export const findActiveTab = (scrollY: number, list: number[]) => {
  let index = 0;

  list.find((positionY, i) => {
    if (positionY <= scrollY) {
      index = i;
    }
    return positionY > scrollY;
  });

  return index;
};
