import * as React from 'react';
import { View, StyleSheet, FlatList } from 'react-native';
import { useTranslation } from 'react-i18next';
import Animated, {
  useAnimatedStyle,
  useDerivedValue,
  useAnimatedReaction,
  Extrapolate,
  runOnJS,
  interpolate,
} from 'react-native-reanimated';
import { debounce } from 'lodash';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Colors from 'constants/Colors';
import Layout from 'constants/Layout';

import Text from 'components/Text';
import ScrollableTabs, { SCROLLABLE_TABS_HEIGHT } from 'components/ScrollableTabs';

import TopBar from './TopBar';
import { getSectionsTabs, findActiveTab } from './utils';

export const TOPBAR_HEIGHT = 48;
export const SUBTITLE_HEIGHT = 38;
export const HOME_HEADER_COLLAPSED_HEIGHT = TOPBAR_HEIGHT + SCROLLABLE_TABS_HEIGHT;
export const HOME_HEADER_HEIGHT = TOPBAR_HEIGHT + SUBTITLE_HEIGHT + SCROLLABLE_TABS_HEIGHT;
export const COLLAPSIN_STARTS_AT = 0;

interface HomePageHeaderProps {
  scrollY: Animated.SharedValue<number>;
  sections: any;
  orders?: any;
  listBreakpoints: number[];
  onCategoryTabPress?(item: any, index: number): void;
  onAddressPress?(): void;
}

const HomePageHeader = ({
  scrollY,
  sections,
  orders,
  listBreakpoints,
  onCategoryTabPress,
  onAddressPress,
}: HomePageHeaderProps) => {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const tabsRef = React.useRef<FlatList | null>(null);
  const [activeTabIndex, setActiveTabIndex] = React.useState<number>(0);
  const tabs = React.useMemo(
    () => getSectionsTabs(sections, activeTabIndex),
    [sections, activeTabIndex],
  );

  // Animation

  const isSticked = useDerivedValue(
    () => scrollY.value >= HOME_HEADER_HEIGHT - HOME_HEADER_COLLAPSED_HEIGHT,
    [scrollY.value],
  );
  const containerAnimatedStyle = useAnimatedStyle(() => {
    if (isSticked.value) {
      return {
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
      };
    }
    return {
      shadowRadius: 0,
      shadowOpacity: 0,
      elevation: 0,
    };
  });
  const subtitleAnimatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      scrollY.value,
      [COLLAPSIN_STARTS_AT, COLLAPSIN_STARTS_AT + 16],
      [1, 0],
      Extrapolate.CLAMP,
    ),
    height: interpolate(
      scrollY.value,
      [COLLAPSIN_STARTS_AT, COLLAPSIN_STARTS_AT + SUBTITLE_HEIGHT],
      [SUBTITLE_HEIGHT, 0],
      Extrapolate.CLAMP,
    ),
  }));

  // Sync tabs with list scroll position.

  const setActiveTab = React.useCallback(
    debounce(
      (index: number) => {
        setActiveTabIndex(index);
        tabsRef?.current?.scrollToIndex({
          index,
          viewOffset: Layout.screenPadding,
        });
      },
      75,
      { leading: false, trailing: true },
    ),
    [],
  );

  const trackScrollPosition = (y: number) => {
    const scrollY = y + HOME_HEADER_COLLAPSED_HEIGHT + insets.top;
    const scrolledToIndex = findActiveTab(scrollY, listBreakpoints);

    if (scrolledToIndex !== activeTabIndex) {
      setActiveTab(scrolledToIndex);
    }
  };

  useAnimatedReaction(
    () => scrollY.value,
    (y) => runOnJS(trackScrollPosition)(y),
    [scrollY, activeTabIndex],
  );

  return (
    <Animated.View style={[styles.container, containerAnimatedStyle, { paddingTop: insets.top }]}>
      <TopBar onAddressPress={onAddressPress} />

      {false ? (
        <View style={{ width: 112, height: 112, backgroundColor: '#fff', marginBottom: 16 }}>
          <Text>My orders</Text>
        </View>
      ) : null}

      <Animated.View style={[styles.subCategories, subtitleAnimatedStyle]}>
        <Text size={14}>{t('suppliers-categories')}</Text>
      </Animated.View>
      <Animated.View style={[styles.tabs]}>
        <ScrollableTabs ref={tabsRef} data={tabs} onPress={onCategoryTabPress} />
      </Animated.View>
    </Animated.View>
  );
};

export default HomePageHeader;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 0,
    shadowOpacity: 0,
    elevation: 0,
  },
  subCategories: {
    height: SUBTITLE_HEIGHT,
    justifyContent: 'flex-end',
    paddingHorizontal: Layout.screenPadding,
    overflow: 'hidden',
  },
  tabs: {},
});
