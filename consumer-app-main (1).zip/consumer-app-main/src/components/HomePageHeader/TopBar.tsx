import * as React from 'react';
import { View, StyleSheet, TouchableOpacity, useWindowDimensions } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useNavigation, NavigationProp } from '@react-navigation/native';

import useSelector from 'hooks/useSelector';
import { selectCurrentAddress } from 'reducers/app';
import { MainNavigationParamList } from 'navigation/MainNavigator';

import Text from 'components/Text';
import Icon from 'components/Icon';
import Container from 'components/Container';
import AddressSelector from 'components/AddressSelector';

interface TopBarProps {
  onAddressPress?(): void;
}

const TopBar = ({ onAddressPress }: TopBarProps) => {
  const [t] = useTranslation();
  const navigation = useNavigation<NavigationProp<MainNavigationParamList>>();
  const currentAddress = useSelector(selectCurrentAddress);
  const windowWidth = useWindowDimensions().width;

  const handleAccountPress = () => {
    navigation.navigate('AccountHome');
  };
  const handleNavigateToFavourite = () => {
    navigation.navigate('MyMerchants');
  };
  const handleSearch = () => {
    navigation.navigate('Search', {});
  };

  return (
    <View style={styles.wrap}>
      <Container style={styles.topbar}>
        {windowWidth > 360 && (
          <View style={styles.topbarAside}>
            <Text size={12} weight="medium" color="secondary">
              {t('delivery-to')}
            </Text>
          </View>
        )}
        <View style={styles.addressesWrap}>
          <AddressSelector.Button label={currentAddress?.title || ''} onPress={onAddressPress} />
        </View>
        <View style={[styles.topbarAside, styles.actions]}>
          <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonRight]}
            onPress={handleSearch}
          >
            <Icon name="magnifying-glass-bold" size={24} />
          </TouchableOpacity>
          {/* <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonRight]}
            onPress={handleNavigateToFavourite}
          >
            <Icon name="heart-bold" size={24} />
          </TouchableOpacity> */}
          <TouchableOpacity
            style={[styles.actionButton, styles.actionButtonRight]}
            onPress={handleAccountPress}
          >
            <Icon name="user-bold" size={24} />
          </TouchableOpacity>
        </View>
      </Container>
    </View>
  );
};

export default TopBar;

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    maxWidth: '100%',
  },
  topbar: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'stretch',
    alignItems: 'center',
    paddingTop: 8,
    maxWidth: '100%',
  },
  addressesWrap: {
    flex: 1,
    flexGrow: 1,
  },
  topbarAside: {
    flexDirection: 'row',
    flexShrink: 0,
    width: 80,
  },
  actions: {
    justifyContent: 'flex-end',
  },
  actionButton: {
    padding: 4,
    opacity: 0.6,
  },
  actionButtonLeft: {
    marginEnd: 4,
  },
  actionButtonRight: {
    marginStart: 4,
  },
});
