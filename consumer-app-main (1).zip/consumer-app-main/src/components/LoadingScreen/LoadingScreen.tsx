import * as React from 'react';
import { ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ActivityIndicator } from 'react-native-paper';

const LoadingScreen = ({ style }: { style?: ViewStyle }) => (
  <SafeAreaView
    style={[
      {
        flex: 1,
        justifyContent: 'center',
      },
      style,
    ]}
  >
    <ActivityIndicator />
  </SafeAreaView>
);

export default LoadingScreen;
