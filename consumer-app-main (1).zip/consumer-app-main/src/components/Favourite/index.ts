export { default } from './Favourite';
