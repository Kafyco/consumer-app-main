import * as React from 'react';
import { TouchableWithoutFeedback, StyleSheet } from 'react-native';
import Animated, { withSpring, useAnimatedStyle, useSharedValue } from 'react-native-reanimated';

import Icon from 'components/Icon';

interface FavouriteProps {
  active?: boolean;
  onPress?(): void;
}

const Favourite = ({ active = false, onPress }: FavouriteProps) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: withSpring(scale.value) }],
  }));

  const handlePressIn = () => {
    scale.value = 1.2;
  };
  const handlePressOut = () => {
    scale.value = 1;
  };

  return (
    <TouchableWithoutFeedback
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <Animated.View style={[styles.button, animatedStyle]}>
        <Icon name={active ? 'heart-fill' : 'heart-bold'} size={24} color="white" />
      </Animated.View>
    </TouchableWithoutFeedback>
  );
};

export default Favourite;

const styles = StyleSheet.create({
  button: {
    paddingHorizontal: 4,
  },
});
