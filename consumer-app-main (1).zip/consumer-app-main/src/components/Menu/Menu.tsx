import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import Colors from 'constants/Colors';
import MenuItem from './MenuItem';

type MenuItemType = {
  title: string;
  route?: string;
  action?(): void;
};

interface MenuProps {
  items: Array<MenuItemType>;
}

const Menu = ({ items }: MenuProps) => {
  const navigation = useNavigation();
  const handlePress = ({ route, action }: MenuItemType) => {
    if (action) {
      action();
    } else if (route) {
      navigation.navigate(route);
    }
  };

  return (
    <View style={styles.container}>
      {items.map((item, index) => (
        <MenuItem
          key={item.title}
          title={item.title}
          onPress={() => handlePress(item)}
          isFirst={index === 0}
        />
      ))}
    </View>
  );
};

export default Menu;

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    overflow: 'hidden',
  },
});
