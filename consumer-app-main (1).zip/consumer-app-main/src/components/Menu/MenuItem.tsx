import * as React from 'react';
import { View, TouchableHighlight, StyleSheet } from 'react-native';

import Colors from 'constants/Colors';

import Text from 'components/Text';
import Icon from 'components/Icon';

interface MenuItemProps {
  title: string;
  onPress?(): void;
  isFirst: boolean;
}

const MenuItem = ({ title, onPress, isFirst }: MenuItemProps) => (
  <TouchableHighlight activeOpacity={0.95} onPress={onPress}>
    <View style={styles.menuItem}>
      <View style={[styles.menuItemInner, isFirst ? undefined : styles.menuItemBorder]}>
        <View>
          <Text weight="medium">{title}</Text>
        </View>
        <View>
          <Icon size={16} name="caret-right" />
        </View>
      </View>
    </View>
  </TouchableHighlight>
);

export default MenuItem;

const styles = StyleSheet.create({
  menuItem: {
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
  },
  menuItemInner: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
  menuItemBorder: {
    borderColor: Colors.light,
    borderTopWidth: 1,
  },
});
