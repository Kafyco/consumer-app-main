import * as React from 'react';
import { View, Image, StyleSheet, ViewStyle } from 'react-native';

import { Text, Title } from 'components/Text';
import Button from 'components/Button';

interface EmptyScreenProps {
  image?: any;
  title?: string;
  text: string;
  actionText?: string;
  onActionPress?(): void;
  style?: ViewStyle;
  styleContent?: ViewStyle;
}

const EmptyScreen = ({
  image,
  title,
  text,
  actionText,
  onActionPress,
  style,
  styleContent,
}: EmptyScreenProps) => (
  <View style={[styles.container, style]}>
    {image ? <Image source={image} resizeMode="contain" style={styles.illustration} /> : null}

    <View style={[styles.content, styleContent]}>
      {title ? (
        <Title level={2} align="center">
          {title}
        </Title>
      ) : null}

      <Text align="center">{text}</Text>

      {actionText ? (
        <Button mode="contained" onPress={onActionPress} style={styles.button}>
          {actionText}
        </Button>
      ) : null}
    </View>
  </View>
);

export default EmptyScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    alignContent: 'center',
    justifyContent: 'center',
  },
  illustration: {
    width: 320,
    height: 320,
    marginBottom: 24,
  },
  content: {
    justifyContent: 'center',
    width: 320,
    paddingBottom: 80,
  },
  button: {
    marginTop: 40,
  },
});
