import * as React from 'react';
import { View, ViewStyle } from 'react-native';
import Colors from 'constants/Colors';

const Divider = ({ style }: { style?: ViewStyle }) => <View style={[defaultStyles, style]} />;

export default Divider;

const defaultStyles: ViewStyle = {
  height: 1,
  backgroundColor: Colors.light,
  marginVertical: 16,
};
