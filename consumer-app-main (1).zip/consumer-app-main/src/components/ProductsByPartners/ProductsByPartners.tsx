import * as React from 'react';
import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  SectionList,
  DefaultSectionT,
  SectionListProps,
} from 'react-native';
import { ActivityIndicator } from 'react-native-paper';
import { Trans } from 'react-i18next';

import { Product as ProductType } from 'api/models';
import { Text, Title } from 'components/Text';
import { Product } from 'components/Products';
import MoreButton from 'components/MoreButton';
import getImageUrl from 'utils/getImageUrl';

interface Props extends SectionListProps<ProductType> {
  isLoading: boolean;
  onProductPress?(item: ProductType, section: DefaultSectionT): void;
  onMerchantPress?(id: number | string): void;
  onShowMore?(id: number | string): void;
}

const ProductsByPartners = ({
  sections,
  isLoading,
  onMerchantPress,
  onProductPress,
  onShowMore,
}: Props) => {
  const renderSectionHeader = React.useCallback(({ section: { id, title, logoThumbnail } }) => {
    const logo = getImageUrl(logoThumbnail, '80x80');

    return (
      <View key={`s-${id}`} style={styles.sectionHeader}>
        <TouchableOpacity onPress={() => onMerchantPress?.(id)} style={styles.merchant}>
          {logo ? <Image resizeMode="contain" source={{ uri: logo }} style={styles.logo} /> : null}
          <View style={styles.flex}>
            <Title level={2} numberOfLines={1} style={styles.merchantName}>
              {title}
            </Title>
          </View>
        </TouchableOpacity>
        <View>
          <MoreButton onPress={() => onShowMore?.(id)} />
        </View>
      </View>
    );
  }, []);
  const renderSectionFooter = React.useCallback(({ section: { id, total, data } }) => {
    const visibleCount = data?.length ?? 0;
    const more = total - visibleCount;

    return more ? (
      <TouchableOpacity
        key={`f-${id}`}
        onPress={() => onShowMore?.(id)}
        style={styles.sectionFooter}
      >
        <Text color="secondary" size={14}>
          <Trans i18nKey="sectionMore" count={more}>
            and {{ count: more }} items more
          </Trans>
        </Text>
      </TouchableOpacity>
    ) : null;
  }, []);
  const renderItem = React.useCallback(
    ({ item, section }) => (
      <View style={styles.listItem}>
        <Product item={item} onPress={() => onProductPress?.(item, section)} />
      </View>
    ),
    [],
  );
  const renderLoading = React.useCallback(
    () => (
      <View style={styles.loading}>
        <ActivityIndicator />
      </View>
    ),
    [],
  );

  return (
    <SectionList
      sections={sections}
      keyExtractor={(item, index) => String(item.id) + String(index)}
      renderItem={renderItem}
      renderSectionHeader={renderSectionHeader}
      renderSectionFooter={renderSectionFooter}
      ListFooterComponent={() => (isLoading ? renderLoading() : null)}
      contentContainerStyle={styles.container}
      stickySectionHeadersEnabled={false}
    />
  );
};

export default ProductsByPartners;

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  container: {
    paddingHorizontal: 12,
  },
  listItem: {
    marginVertical: 4,
  },
  loading: {
    paddingVertical: 32,
  },
  logo: {
    width: 40,
    height: 40,
    borderWidth: 1,
    borderColor: '#ebebeb',
    borderRadius: 20,
    marginEnd: 8,
  },
  merchant: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  merchantName: {
    marginBottom: 0,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 24,
    marginBottom: 4,
  },
  sectionFooter: {
    alignItems: 'center',
    marginTop: 8,
  },
});
