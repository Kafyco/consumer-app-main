export { default } from './ProductsByPartners';
