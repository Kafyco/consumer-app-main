import * as React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { useTranslation } from 'react-i18next';
import * as Linking from 'expo-linking';

import { SUPPORT_EMAIL } from 'constants/Global';
import { Text, Title } from 'components/Text';

const InitializationError = () => {
  const [t] = useTranslation();

  const handleSupportEmailClick = () => {
    Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=Payment Card Attachement Issue`);
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('assets/images/Larry__Fix.png')}
        resizeMode="contain"
        style={styles.illustration}
      />
      <View style={styles.content}>
        <Title level={2} align="center">
          {t('stripe-web.error-init-title')}
        </Title>
        <Text align="center">{t('stripe-web.error-init-message')}</Text>
        <Text align="center" color="primary" weight="bold" onPress={handleSupportEmailClick}>
          {SUPPORT_EMAIL}
        </Text>
      </View>
    </View>
  );
};

export default InitializationError;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    alignContent: 'center',
    justifyContent: 'center',
  },
  content: {
    justifyContent: 'center',
    alignItems: 'center',
    maxWidth: 320,
    paddingBottom: 100,
  },
  illustration: {
    width: 320,
    height: 320,
    marginBottom: 24,
  },
});
