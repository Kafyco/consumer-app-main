import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { Alert } from 'react-native';
import WebView from 'react-native-webview';
import * as Sentry from 'sentry-expo';

import Colors from 'constants/Colors';
import { getPaymentSetupUrl } from 'api/index';
import useIsMounted from 'hooks/useIsMounted';

import LoadingScreen from 'components/LoadingScreen';

import InitializationError from './InitializationError';

interface StripeAttachWebProps {
  onSuccess?(): void;
  onFail?(errorCode: string): void;
}

const StripeAttachWeb = ({ onSuccess, onFail }: StripeAttachWebProps) => {
  const [t] = useTranslation();
  const isMounted = useIsMounted();
  const [initError, setInitError] = React.useState<boolean>(false);
  const [url, setUrl] = React.useState<string>();

  const handleSuccess = async () => {
    Alert.alert(t('stripe-web.success-title'), t('stripe-web.success-message'));
    onSuccess?.();
  };

  const handleFail = (payload: any) => {
    const { errorCode } = payload;

    if (errorCode === 'stripe_error') {
      // Stripe returns with error.
      Alert.alert(t('stripe-web.error-stripe-title'), t('stripe-web.error-stripe-message'));
    } else if (
      [
        'config_corrupted',
        'get_public_key_error',
        'create_setup_intent_error',
        'complete_setup_intent_error',
      ].includes(errorCode)
    ) {
      // Problem on our side.
      const err = new Error(payload.message);
      err.name = `[StripeError][${errorCode}]`;
      Sentry.Native.captureException(err);

      console.warn(payload);
      setInitError(true);
    } else {
      // Unknown error
      const err = new Error(payload.message);
      err.name = `[StripeError][${errorCode}]`;
      Sentry.Native.captureException(err);

      console.warn(payload);
      Alert.alert(t('stripe-web.error-stripe-title'), t('stripe-web.error-stripe-message'));
    }

    onFail?.(errorCode);
  };

  React.useEffect(() => {
    const intialize = async () => {
      try {
        const results = await getPaymentSetupUrl();

        if (isMounted() && results?.data?.pageUrl) {
          setUrl(results.data.pageUrl);
        } else {
          throw new Error('Unexpected Format');
        }
      } catch (err) {
        Sentry.Native.captureException(err);
        if (isMounted()) {
          console.error(err);
          setInitError(true);
        }
      }
    };

    intialize();
  }, []);

  if (initError) {
    return <InitializationError />;
  }

  return url ? (
    <WebView
      source={{ uri: url }}
      onMessage={(event) => {
        const json = event.nativeEvent.data;
        const data = JSON.parse(json);

        if (data?.type === 'success') {
          handleSuccess();
        } else if (data?.type === 'error') {
          handleFail(data?.payload);
        }
      }}
      onHttpError={(syntheticEvent) => {
        const { nativeEvent } = syntheticEvent;

        const err = new Error(String(nativeEvent.statusCode));
        err.name = '[StripeError][HTTP_ERROR]';
        Sentry.Native.captureException(err);

        console.error(
          'Card attachement WebView received error status code: ',
          nativeEvent.statusCode,
        );

        setInitError(true);
      }}
      style={{
        backgroundColor: Colors.background,
      }}
    />
  ) : (
    <LoadingScreen />
  );
};

export default StripeAttachWeb;
