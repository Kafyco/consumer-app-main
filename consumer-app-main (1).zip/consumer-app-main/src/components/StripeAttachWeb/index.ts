export { default } from './StripeAttachWeb';
