import * as React from 'react';
import { FlatList } from 'react-native';

import Layout from 'constants/Layout';
import Item from './Item';

interface AddressSuggestionProps {
  items: any;
  onItemPress?(item: any): void;
}

const AddressSuggestion = ({ items, onItemPress }: AddressSuggestionProps) => (
  <FlatList
    data={items}
    renderItem={({ item }) => <Item item={item} onPress={() => onItemPress?.(item)} />}
    keyExtractor={(item) => item?.place_id}
    style={{ flex: 1 }}
    keyboardShouldPersistTaps="handled"
    contentContainerStyle={{
      paddingHorizontal: Layout.screenPadding,
    }}
  />
);

export default AddressSuggestion;
