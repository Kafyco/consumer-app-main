import * as React from 'react';
import { View, TouchableHighlight, StyleSheet } from 'react-native';

import Colors from 'constants/Colors';
import Text from 'components/Text';

interface ItemProps {
  item: any;
  onPress?(): void;
}

const Item = ({ item, onPress }: ItemProps) => (
  <TouchableHighlight onPress={onPress}>
    <View style={styles.container}>
      <Text>{item.structured_formatting.main_text}</Text>
      <Text size={14} color="secondary">
        {item.structured_formatting.secondary_text}
      </Text>
    </View>
  </TouchableHighlight>
);

export default Item;

const styles = StyleSheet.create({
  container: {
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light,
    backgroundColor: Colors.background,
  },
});
