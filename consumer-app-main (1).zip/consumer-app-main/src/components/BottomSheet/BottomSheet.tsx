import * as React from 'react';
import { View, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import Layout from 'constants/Layout';
import Colors from 'constants/Colors';

interface BottomSheetProps {
  children?: React.ReactNode;
  positionStatic?: boolean;
  style?: StyleProp<ViewStyle>;
}
const BottomSheet = ({ children, positionStatic, style }: BottomSheetProps) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.container,
        positionStatic ? styles.statics : styles.absolute,
        { paddingBottom: insets.bottom },
        style,
      ]}
    >
      <View style={styles.inner}>{children}</View>
    </View>
  );
};

export default BottomSheet;

const styles = StyleSheet.create({
  absolute: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  container: {
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: '#e6e6e6',
  },
  statics: {},
  inner: {
    padding: Layout.screenPadding,
  },
});
