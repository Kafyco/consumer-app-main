export { default } from './Text';
export { default as Text, TextColorType, TextWeightType, TextProps } from './Text';
export { default as Title } from './Title';
