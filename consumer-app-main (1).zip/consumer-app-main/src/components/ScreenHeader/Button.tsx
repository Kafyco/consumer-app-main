import React from 'react';
import { StyleSheet, Platform, I18nManager } from 'react-native';
import Colors from 'constants/Colors';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Icon from 'components/Icon';
import Text from 'components/Text';

export interface ButtonProps {
  label?: string;
  icon?: string;
  labelVisible?: boolean;
  tintColor?: string;
  onPress(): void;
}

const Button = ({
  label,
  icon,
  labelVisible = true,
  onPress,
  tintColor = Colors.primary,
}: ButtonProps) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.container}>
      {icon ? (
        <Icon
          name={icon}
          size={20}
          style={[
            styles.icon,
            !!labelVisible && styles.iconWithLabel,
            !!tintColor && { color: tintColor },
          ]}
        />
      ) : null}
      {label && labelVisible ? (
        <Text
          size={16}
          weight="medium"
          numberOfLines={1}
          color="primary"
          style={[!!tintColor && { color: tintColor }]}
        >
          {label}
        </Text>
      ) : null}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  icon: {
    marginStart: -2,
    transform: [{ scaleX: I18nManager.isRTL ? -1 : 1 }],
  },
  iconWithLabel: {
    marginRight: 4,
  },
});

export default Button;
