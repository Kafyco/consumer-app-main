import * as React from 'react';
import { StyleSheet, View, StyleProp, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import Animated from 'react-native-reanimated';

import { Title } from 'components/Text';
import Layout from 'constants/Layout';
import Button from './Button';

export const SCREEN_HEADER_HEIGHT = 94;
export const SCREEN_HEADER_SMALL_HEIGHT = 40;

export interface ScreenHeaderProps {
  headerTitle?: string;
  headerBackTitle?: string;
  headerBackTitleVisible?: boolean;
  tintColor?: string;
  actions?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

const ScreenHeader = ({
  headerTitle,
  headerBackTitle,
  headerBackTitleVisible = true,
  tintColor,
  actions,
  style,
}: ScreenHeaderProps) => {
  const [t] = useTranslation();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const backLabelMemo = React.useMemo(() => headerBackTitle || t('back'), [headerBackTitle]);
  const handleBackButtonPress = () => {
    navigation.goBack();
  };

  return (
    <Animated.View style={[styles.container, { paddingTop: insets.top }, style]}>
      <View style={styles.actionsRow}>
        <View style={styles.actionsStart}>
          <Button
            icon="caret-left-bold"
            label={backLabelMemo}
            labelVisible={headerBackTitleVisible}
            tintColor={tintColor}
            onPress={handleBackButtonPress}
          />
        </View>
        {actions ? <View style={styles.actionsEnd}>{actions}</View> : null}
      </View>
      {headerTitle ? (
        <View style={styles.title}>
          <Title level={1}>{headerTitle}</Title>
        </View>
      ) : null}
    </Animated.View>
  );
};

export default ScreenHeader;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Layout.screenPadding,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  actionsStart: {},
  actionsEnd: {},
  title: {
    paddingBottom: 8,
  },
});
