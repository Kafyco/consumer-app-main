import * as React from 'react';
import { View, Image, StyleSheet, ViewStyle } from 'react-native';
import { useTranslation } from 'react-i18next';

import { Bankcard } from 'api/models';
import Text from 'components/Text';
import { getCardNumber, getExpDate, isExpired } from 'utils/paymentMethods';

interface PaymentCardProps {
  info: Bankcard;
  style?: ViewStyle;
}

const PaymentCard = ({ info: { name, number, expiryDate }, style }: PaymentCardProps) => {
  const [t] = useTranslation();

  return (
    <View style={[styles.container, style]}>
      <View style={styles.row}>
        {['visa', 'mastercard'].includes(name) && (
          <Image
            source={
              name === 'visa'
                ? require('assets/images/visa.png')
                : require('assets/images/mastercard.png')
            }
            resizeMode="contain"
            style={styles.icon}
          />
        )}
        <Text size={14}>
          {t('payment-method.card-ending-in')} {getCardNumber(number)}
        </Text>
      </View>
      {expiryDate ? (
        <Text size={14} color={isExpired(expiryDate) ? 'danger' : 'secondary'}>
          Exp. {getExpDate(expiryDate)}
        </Text>
      ) : null}
    </View>
  );
};

export default PaymentCard;

const styles = StyleSheet.create({
  container: {},
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    width: 32,
    height: 16,
    marginEnd: 8,
  },
});
