import * as React from 'react';
import { View, StyleSheet } from 'react-native';

import { TextColorType } from 'components/Text';
import Colors from 'constants/Colors';
import SummaryRow from './SummaryRow';

export type SummaryLinesType = {
  label: React.ReactNode;
  sum: React.ReactNode;
  color?: TextColorType;
  bold?: boolean;
  divider?: boolean;
};

interface SummaryProps {
  lines: SummaryLinesType[];
}

const Summary = ({ lines }: SummaryProps) => (
  <View>
    {lines.map(({ divider, label, sum, bold, color }, i) => (
      <React.Fragment key={i}>
        {divider ? <View style={styles.divider} /> : null}
        <SummaryRow sum={sum} bold={bold} color={color}>
          {label}
        </SummaryRow>
      </React.Fragment>
    ))}
  </View>
);

export default Summary;

const styles = StyleSheet.create({
  divider: {
    height: 1,
    backgroundColor: Colors.light,
    marginTop: 4,
    marginBottom: 8,
  },
});
