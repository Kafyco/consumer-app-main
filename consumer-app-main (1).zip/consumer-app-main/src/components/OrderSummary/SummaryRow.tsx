import * as React from 'react';
import { View, ViewStyle } from 'react-native';

import Text, { TextColorType } from 'components/Text';

interface SummaryRowProps {
  children: React.ReactNode;
  sum: React.ReactNode;
  bold?: boolean;
  color?: TextColorType;
}

const SummaryRow = ({ sum, children, bold, color }: SummaryRowProps) => (
  <View style={stylesRow}>
    <View>
      <Text size={14} weight={bold ? 'bold' : 'regular'} color={color}>
        {children}
      </Text>
    </View>
    <View>
      {typeof sum === 'string' ? (
        <Text size={14} weight={bold ? 'bold' : 'regular'} color={color}>
          {sum}
        </Text>
      ) : (
        sum
      )}
    </View>
  </View>
);

export default SummaryRow;

const stylesRow: ViewStyle = {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginBottom: 4,
};
