import * as React from 'react';
import { View, ScrollView, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Formik, FormikProps } from 'formik';
import { CountryCode } from 'libphonenumber-js';
import * as Yup from 'yup';
import * as Sentry from 'sentry-expo';

import { Address as AddressType } from 'api/models';
import { ERROR_FORM_VALIDATION } from 'api/constants';
import {
  getLocalPhoneNumber,
  getCountryCodeFromNumber,
  getFullNumber,
  validatePhoneNumber,
} from 'utils/phoneNumber';

import Container from 'components/Container';
import Sheet from 'components/Sheet';
import Field from 'components/Field';
import BottomSheet from 'components/BottomSheet';
import BottomButton from 'components/BottomButton';
import CountryPhoneCodePicker, { CountryModalProvider } from 'components/CountryPhoneCodePicker';

const DEFAULT_COUNTRY_CODE = 'QA';

const defaultInitialData = {
  addressName: '',
  line1: '',
  line2: '',
  line3: '',
  line4: '',
  phoneNumber: '',
};

const prepareInitialValues = (address: any = {}, defaults = {}): AddressType => {
  const { phoneNumber } = address;
  const values = Object.assign({}, defaults, address);

  if (phoneNumber) {
    values.phoneNumber = getLocalPhoneNumber(phoneNumber);
  }

  return values;
};

interface AddressFormProps {
  address?: AddressType;
  onSubmit?(values: any): void;
  onEditLocation?(values: any): void;
}

const AddressForm = ({ address, onSubmit, onEditLocation }: AddressFormProps) => {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const formikRef = React.useRef<FormikProps<AddressType> | null>(null);

  const initialValues = React.useMemo(
    () => prepareInitialValues(address, defaultInitialData),
    [address],
  );

  const initialCountryCode = React.useMemo<CountryCode>(() => {
    if (address?.phoneNumber) {
      return getCountryCodeFromNumber(address.phoneNumber) || DEFAULT_COUNTRY_CODE;
    }
    return DEFAULT_COUNTRY_CODE;
  }, [address]);

  const [countryCode, setCountryCode] = React.useState<CountryCode>(initialCountryCode);

  const validationSchema = Yup.object().shape({
    addressName: Yup.string()
      .nullable()
      .min(2, t('validation.min', { field: t('address.nickname'), count: 2 })),
    line1: Yup.string()
      .min(2, t('validation.min', { field: t('address.shop-name'), count: 2 }))
      .required(t('validation.required')),
    line2: Yup.string()
      .min(2, t('validation.min', { field: t('address.address'), count: 2 }))
      .required(t('validation.required')),
    line3: Yup.string().required(t('validation.required')),
    phoneNumber: Yup.string()
      .test('is-phone-number', t('validation.phone-format'), (value) =>
        validatePhoneNumber(value, countryCode),
      )
      .required(t('validation.required')),
  });

  const prepareValues = (values: any) => {
    const prepared = Object.assign({}, values);

    if (prepared.phoneNumber) {
      prepared.phoneNumber = getFullNumber(prepared.phoneNumber, countryCode);
    }

    return prepared;
  };

  // In case if address is changed (through URL for instance), formik requires manual update of the values.
  React.useEffect(() => {
    if (address) {
      formikRef.current?.setValues(initialValues);
    }
  }, [address]);

  return (
    <CountryModalProvider>
      <Formik<AddressType>
        innerRef={(ref) => (formikRef.current = ref)}
        initialValues={initialValues}
        validationSchema={validationSchema}
        validateOnChange={false}
        validateOnMount={true}
        onSubmit={async (values, actions) => {
          try {
            const preparedValues = prepareValues(values);
            await onSubmit?.(preparedValues);
          } catch (err: any) {
            if (err.code === ERROR_FORM_VALIDATION) {
              actions.setErrors(err.data);
            }
            Sentry.Native.captureException(err);
          }
        }}
      >
        {({ handleSubmit, isValid, isSubmitting, values }) => (
          <>
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{ flex: 1, zIndex: 1, marginBottom: insets.bottom }}
            >
              <ScrollView keyboardDismissMode="interactive" keyboardShouldPersistTaps="handled">
                <Container style={styles.container}>
                  <Sheet>
                    <Field
                      name="line3"
                      label={t('address.delivery-location')}
                      disabled={true}
                      numberOfLines={1}
                      rightIcon={
                        <Field.Icon
                          name="pencil-outline"
                          onPress={() => onEditLocation?.(values)}
                        />
                      }
                    />
                    <Field name="line1" label={t('address.shop-name')} />
                    <Field name="line2" label={t('address.address-details')} />
                    <View style={styles.phoneRow}>
                      <View style={styles.phonePrefix}>
                        <CountryPhoneCodePicker
                          defaultValue={countryCode}
                          onSelect={(country: any) => {
                            setCountryCode(country.cca2);
                          }}
                        />
                      </View>
                      <View style={styles.phoneField}>
                        <Field
                          name="phoneNumber"
                          label={t('address.phone-number')}
                          keyboardType="phone-pad"
                          maxLength={10}
                        />
                      </View>
                    </View>
                    <Field name="addressName" label={t('address.nickname')} />
                    <Field name="notes" label={t('address.notes')} multiline={true} />
                  </Sheet>
                </Container>
              </ScrollView>
              <BottomButton
                positionStatic
                label={address?.id ? t('update-address') : t('save-new-address')}
                onPress={handleSubmit}
                disabled={!isValid}
                loading={isSubmitting}
                style={{ paddingBottom: 0 }}
              />
            </KeyboardAvoidingView>
            <BottomSheet style={{ zIndex: 0 }} />
          </>
        )}
      </Formik>
    </CountryModalProvider>
  );
};

export default AddressForm;

const styles = StyleSheet.create({
  container: {
    paddingBottom: 40,
  },
  phoneRow: {
    flexDirection: 'row',
    overflow: 'hidden',
  },
  phonePrefix: {
    paddingRight: 16,
    width: 120,
  },
  phoneField: {
    flexGrow: 1,
  },
});
