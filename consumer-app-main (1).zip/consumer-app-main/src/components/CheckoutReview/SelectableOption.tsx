import * as React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';

import Checkbox from 'components/Checkbox';

interface SelectableOptionProps {
  children: React.ReactNode;
  checked: boolean;
  onPress?(): void;
}
const SelectableOption = ({ onPress, children, checked }: SelectableOptionProps) => (
  <TouchableOpacity onPress={onPress}>
    <View style={styles.option}>
      {children}
      <Checkbox size={24} checked={checked} style={styles.checkbox} onPress={onPress} />
    </View>
  </TouchableOpacity>
);

export default SelectableOption;

const styles = StyleSheet.create({
  checkbox: {
    marginStart: 4,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
});
