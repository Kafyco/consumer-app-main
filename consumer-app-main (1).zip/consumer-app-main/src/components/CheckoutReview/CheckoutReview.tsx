import * as React from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import { ActivityIndicator } from 'react-native-paper';

import {
  Basket as BasketType,
  ShippingMethod,
  Address as AddressType,
  CheckoutPayment,
  OfferDiscount,
} from 'api/models';
import { GroupedPaymentMethod } from 'utils/paymentMethods';
import { priceFunctionFactory } from 'utils/price';

import Container from 'components/Container';
import Address from 'components/Address';
import Sheet from 'components/Sheet';
import Text from 'components/Text';
import OrderSummary, { SummaryLinesType } from 'components/OrderSummary';
import CouponBlock from 'components/CouponBlock';

import PaymentMethodSelector from './PaymentMethodSelector';

interface CheckoutReviewProps {
  basket: BasketType;
  shippingMethod?: ShippingMethod;
  paymentMethods?: GroupedPaymentMethod[];
  address?: AddressType;
  selectedPaymentMethod?: CheckoutPayment;
  onPaymentMethodChange?(method: string, cardId?: string | number): void;
  onAddNewPaymentMethod?(code: string): void;
}

const CheckoutReview = ({
  basket,
  shippingMethod,
  paymentMethods,
  selectedPaymentMethod,
  onPaymentMethodChange,
  onAddNewPaymentMethod,
  address,
}: CheckoutReviewProps) => {
  const [t] = useTranslation();
  const price = React.useCallback(priceFunctionFactory(basket.currency), [basket]);

  // Fulfill summary
  const summary = React.useMemo(() => {
    if (!basket || !shippingMethod) {
      return [];
    }

    const result: SummaryLinesType[] = [
      {
        label: t('subtotal'),
        sum: price(basket.totalInclTaxExclDiscounts),
      },
      {
        label: t('delivery-fee'),
        sum: price(shippingMethod.price.inclTax),
      },
    ];

    const discount: number = basket.totalInclTax - basket.totalInclTaxExclDiscounts;

    if (discount) {
      result.push({
        label: t('total-discount'),
        bold: true,
        color: 'danger',
        sum: price(discount),
      });
    }

    return result.concat([
      {
        divider: true,
        label: (
          <>
            {t('total')}&nbsp;
            <Text size={14} color="secondary" weight="regular">
              ({t('incl-tax')})
            </Text>
          </>
        ),
        sum: price(parseFloat(basket.totalInclTax) + parseFloat(shippingMethod.price.inclTax)),
        bold: true,
      },
      {
        label: t('estimated-vat'),
        sum: price(parseFloat(basket.totalTax) + parseFloat(shippingMethod.price.tax)),
      },
    ]);
  }, [basket, shippingMethod]);

  return (
    <ScrollView style={styles.flex}>
      <Container>
        <Sheet
          title={t('delivery-to')}
          // action={{ label: t('change-address'), onPress: () => {} }}
          style={styles.section}
        >
          {address ? <Address info={address} padded /> : <ActivityIndicator />}
        </Sheet>

        <Sheet
          title={t('payment')}
          // TODO: activate with new payment gateway
          // action={{ label: t('add-new'), onPress: () => onAddNewPaymentMethod?.('stripe') }}
          style={styles.section}
        >
          {paymentMethods ? (
            <PaymentMethodSelector
              groupedMethods={paymentMethods}
              selected={selectedPaymentMethod}
              onChange={onPaymentMethodChange}
              onAddNew={onAddNewPaymentMethod}
            />
          ) : (
            <ActivityIndicator />
          )}
        </Sheet>

        <Sheet title={t('order-summary')} style={styles.section}>
          {shippingMethod ? <OrderSummary lines={summary} /> : <ActivityIndicator />}
        </Sheet>

        <Sheet title={t('coupon-block-title')} style={styles.section}>
          <CouponBlock basket={basket} />
        </Sheet>
      </Container>
    </ScrollView>
  );
};

export default CheckoutReview;

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  section: {
    paddingTop: 12,
    paddingBottom: 16,
    paddingHorizontal: 24,
    marginBottom: 8,
  },
});
