import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';

import { CARD_PAYMENT_CODES } from 'constants/Payments';
import { CheckoutPayment } from 'api/models';
import { GroupedPaymentMethod } from 'utils/paymentMethods';

import Button from 'components/Button';
import Divider from 'components/Divider';
import PaymentCard from 'components/PaymentCard';
import PaymentMethod from 'components/PaymentMethod';

import SelectableOption from './SelectableOption';
import { buildSections } from './utils';

interface PaymentMethodsSelectorProps {
  groupedMethods: GroupedPaymentMethod[];
  selected?: CheckoutPayment;
  onChange?(method: string, cardId?: string | number): void;
  onAddNew?(code: string): void;
}
const PaymentMethodSelector = ({
  groupedMethods,
  selected,
  onChange,
  onAddNew,
}: PaymentMethodsSelectorProps) => {
  const [t] = useTranslation();
  const sections = React.useMemo(() => buildSections(groupedMethods), [groupedMethods]);

  const renderMethod = ({ code, options }: GroupedPaymentMethod) => {
    // Card payment options
    if (CARD_PAYMENT_CODES.includes(code)) {
      // Propose to attach a new card if no even one.
      if (!options?.length) {
        // TODO: activate with new payment gateway
        return (
          null && (
            <View key={code} style={styles.sectionAdd}>
              <Button mode="contained" onPress={() => onAddNew?.(code)}>
                {t('attach-new-card')}
              </Button>
            </View>
          )
        );
      }

      return options.map((option) => (
        <SelectableOption
          key={option.id}
          checked={selected?.method === code && selected?.cardId === option.id}
          onPress={() => onChange?.(code, option.id)}
        >
          <PaymentCard info={option} />
        </SelectableOption>
      ));
    }

    return (
      <SelectableOption
        key={code}
        checked={selected?.method === code}
        onPress={() => onChange?.(code)}
      >
        <PaymentMethod code={code} />
      </SelectableOption>
    );
  };

  return (
    <View>
      {sections.map(({ methods }, i) => (
        <View key={`g-${i}`}>
          {/* {i > 0 && <Divider style={styles.divider} />} */}
          {methods.map(renderMethod)}
        </View>
      ))}
    </View>
  );
};

export default PaymentMethodSelector;

const styles = StyleSheet.create({
  sectionAdd: {
    marginVertical: 8,
  },
  divider: {
    marginVertical: 8,
  },
});
