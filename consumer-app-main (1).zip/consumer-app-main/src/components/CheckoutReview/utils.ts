import { GroupedPaymentMethod } from 'utils/paymentMethods';

const PAYMENT_METHODS_SECTIONS = [
  {
    methods: ['stripe'],
  },
  {
    methods: ['cod', 'codc'],
  },
];

export type PaymentsSection = {
  methods: GroupedPaymentMethod[];
};

export const buildSections = (groupedPaymentMethods: GroupedPaymentMethod[]): PaymentsSection[] => {
  const hash = groupedPaymentMethods.reduce((res, method) => {
    res[method.code] = method;
    return res;
  }, {});

  return PAYMENT_METHODS_SECTIONS.reduce<PaymentsSection[]>((results, section) => {
    const { methods } = section;
    const exists = methods.some((m) => hash[m]);

    if (exists) {
      const fulfilledMethods = methods.reduce<GroupedPaymentMethod[]>((r, m) => {
        if (hash[m]) {
          r.push(hash[m]);
        }
        return r;
      }, []);

      results.push({
        ...section,
        methods: fulfilledMethods,
      });
    }

    return results;
  }, []);
};
