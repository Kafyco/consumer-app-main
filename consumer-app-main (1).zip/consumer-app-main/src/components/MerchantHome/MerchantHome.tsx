import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import { ActivityIndicator } from 'react-native-paper';
import Animated, { useAnimatedReaction, runOnJS } from 'react-native-reanimated';

import { Partner, Product as ProductType } from 'api/models';
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';

import Text from 'components/Text';
import Container from 'components/Container';
import Categories from 'components/Categories';
import { ProductsSectionList } from 'components/Products';
import { selectRootCategories, selectCategoriesLoading } from 'reducers/categories';
import {
  clearProductsSections,
  configureProductsSections,
  fetchMoreSections,
  selectAllSections,
  selectProductsLoading,
} from 'reducers/productsSections';
import { selectBasketFetchStatus } from 'reducers/basket';

export interface MerchantHomeProps {
  merchant: Partner;
  orders?: [];
  isCloseToBottom: Animated.SharedValue<boolean>;
  onProductPress?(product: ProductType): void;
}

const MerchantHome = ({
  merchant: { id: merchantId },
  orders,
  isCloseToBottom,
  onProductPress,
}: MerchantHomeProps) => {
  const [t] = useTranslation();
  const dispatch = useDispatch();

  // Categories are loading in MerchantRoot
  const categories = useSelector(selectRootCategories);
  const isCategoriesLoading = useSelector(selectCategoriesLoading);
  const basketFetchStatus = useSelector(selectBasketFetchStatus);

  // Product section once categories are known
  const productsSections = useSelector(selectAllSections);
  const productsSectionsLoading = useSelector(selectProductsLoading);

  // useAnimatedReaction below take care to call this function only once.
  const handleLoadMore = () => {
    if (!isCategoriesLoading && categories.length) {
      dispatch(fetchMoreSections(5));
    }
  };

  useAnimatedReaction(
    () => isCloseToBottom.value,
    (next, prev) => {
      if (next && next !== prev) {
        runOnJS(handleLoadMore)();
      }
    },
  );

  React.useEffect(() => {
    // When we know categories, we can fetch first products section
    if (!isCategoriesLoading) {
      // If merchant has any category fetch first product section
      if (categories.length) {
        dispatch(configureProductsSections({ merchantId, categories }));
        dispatch(fetchMoreSections(3));
      }
    }
    return () => {
      // Clear products
      dispatch(clearProductsSections());
    };
  }, [isCategoriesLoading, merchantId]);

  if (isCategoriesLoading || basketFetchStatus !== 'fulfilled') {
    return (
      <Container>
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      </Container>
    );
  }

  const isAny = orders?.length || categories?.length || productsSections?.length;

  if (!isAny) {
    return (
      <Container style={styles.emptyMessage}>
        <Text>{t('noproducts')}</Text>
      </Container>
    );
  }

  return (
    <Container>
      {/* Re-order */}

      {/* Categories */}
      {categories?.length ? (
        <View>
          <Text size={14} style={styles.categoriesHeader}>
            {t('categories')}
          </Text>
          <Categories items={categories} />
        </View>
      ) : null}

      {/* Products */}
      {productsSections?.length ? (
        <ProductsSectionList sections={productsSections} onProductPress={onProductPress} />
      ) : null}
      {productsSectionsLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : null}
    </Container>
  );
};

export default MerchantHome;

const styles = StyleSheet.create({
  categoriesHeader: {
    paddingVertical: 8,
  },
  emptyMessage: {
    textAlign: 'center',
    paddingVertical: 32,
  },
  loading: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    marginTop: 32,
    marginBottom: 32,
  },
});
