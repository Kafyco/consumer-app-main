export { default } from './MerchantHome';
