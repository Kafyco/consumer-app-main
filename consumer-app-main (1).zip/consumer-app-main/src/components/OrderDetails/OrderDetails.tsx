import * as React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import * as WebBrowser from 'expo-web-browser';

import { getStatusColorName } from 'utils/order';
import getImageUrl from 'utils/getImageUrl';
import { priceFunctionFactory } from 'utils/price';
import { paymentMethodFromOrder } from 'utils/paymentMethods';
import { Order as OrderType, OrderLine } from 'api/models';
import { CARD_PAYMENT_CODES } from 'constants/Payments';

import { Text, Title } from 'components/Text';
import Sheet from 'components/Sheet';
import Address from 'components/Address';
import OrderSummary, { SummaryLinesType } from 'components/OrderSummary';
import Button from 'components/Button';
import NoImage from 'components/NoImage';
import OrderPipeline from 'components/OrderPipeline';
import { Product } from 'components/Products';
import PaymentCard from 'components/PaymentCard';
import PaymentMethod from 'components/PaymentMethod';
import SupportBlock from 'components/SupportBlock';

interface Props {
  order: OrderType;
  handleReorder(): void;
}

const OrderDetails = ({ order, handleReorder }: Props) => {
  const { shippingAddress, partner, status, allLines, currency, invoicesUrls } = order;
  const [t] = useTranslation();
  const logo = getImageUrl(partner.logoThumbnail, '80x80');
  const statusColor = getStatusColorName(status);
  const date = new Date(parseFloat(order.datePlaced) * 1000);
  const price = React.useCallback(priceFunctionFactory(currency), [order]);
  const paymentMethod = React.useMemo(() => paymentMethodFromOrder(order), [order]);

  const summary = React.useMemo(() => {
    const result: SummaryLinesType[] = [
      {
        label: t('subtotal'),
        sum: price(order.basketTotalBeforeDiscountsInclTax),
      },
      {
        label: t('delivery-fee'),
        sum: price(order.shippingInclTax),
      },
    ];
    const discount: number = order.basketTotalInclTax - order.basketTotalBeforeDiscountsInclTax;

    if (discount) {
      result.push({
        label: t('total-discount'),
        bold: true,
        color: 'danger',
        sum: price(discount),
      });
    }

    return result.concat([
      {
        divider: true,
        label: (
          <>
            {t('total')}&nbsp;
            <Text size={14} color="secondary" weight="regular">
              ({t('incl-tax')})
            </Text>
          </>
        ),
        sum: price(order.totalInclTax),
        bold: true,
      },
      {
        label: t('total-vat'),
        sum: price(order.totalTax),
      },
    ]);
  }, [order]);

  const productLines = React.useMemo(() => {
    return allLines.map((line: OrderLine) => {
      return {
        id: line.id,
        quantity: line.quantity,
        product: {
          ...line.product,
          price: line.linePriceBeforeDiscountsInclTax,
          currency,
        },
      };
    });
  }, [order]);

  const handleInvoiceDownload = async () => {
    const latestInvoice = invoicesUrls?.pop();

    if (latestInvoice) {
      await WebBrowser.openBrowserAsync(latestInvoice);
    }
  };

  return (
    <>
      <Sheet style={[styles.section, styles.general]}>
        <View style={styles.partner}>
          {logo ? (
            <Image source={{ uri: logo }} resizeMode="contain" style={styles.logo} />
          ) : (
            <NoImage style={styles.logo} resizeMode="contain" />
          )}
          <Title level={3} style={styles.partnerName}>
            {partner.name}
          </Title>
        </View>

        <View style={styles.status}>
          <OrderPipeline status={status} />
          <Text color={statusColor}>{t(`order-status.${status}`)}</Text>
        </View>

        <View style={styles.title}>
          <View>
            <Title level={4}>
              {t('order-no')}
              {order.number}
            </Title>
            <Text size={14} color="secondary">
              {t('order-placed')}:&nbsp;
              <Text size={14} color="regular">
                {dayjs(date).format('DD/MM/YYYY h:m A')}
              </Text>
            </Text>
            <Text size={14} color="secondary">
              {t('order-total')}:&nbsp;
              <Text size={14} color="regular">
                {price(order.totalInclTax)}
              </Text>
            </Text>
          </View>
        </View>

        {!invoicesUrls?.length && (
          <View style={styles.invoiceDescr}>
            <Text size={14} color="secondary">
              {t('invoice-later')}
            </Text>
          </View>
        )}
        <View style={styles.actions}>
          {!!order?.canReorder && (
            <Button icon="repeat" onPress={handleReorder}>
              {t('order-again')}
            </Button>
          )}
          <Button
            icon="download-simple"
            onPress={handleInvoiceDownload}
            disabled={!invoicesUrls?.length}
          >
            {t('invoice')}
          </Button>
        </View>
      </Sheet>

      <Sheet title={t('delivery')} style={styles.section}>
        <Address info={shippingAddress} padded />
      </Sheet>

      {paymentMethod ? (
        <Sheet title={t('payment')} style={styles.section}>
          <View>
            {CARD_PAYMENT_CODES.includes(paymentMethod.code) && paymentMethod.info ? (
              <PaymentCard info={paymentMethod.info} />
            ) : (
              <PaymentMethod code={paymentMethod.code} withDescription={false} />
            )}
          </View>
        </Sheet>
      ) : null}

      <Sheet title={t('order-summary')} style={styles.section}>
        <OrderSummary lines={summary} />
      </Sheet>

      <SupportBlock emailSubject={`Order ${order.number}`}>
        <Text size={16}>{t('order-support')}</Text>
      </SupportBlock>

      <View style={styles.products}>
        <Title level={2}>{t('products')}</Title>
        {productLines.map((line: OrderLine) => (
          <View key={line.id} style={styles.listItem}>
            <Product item={line.product} basketQty={line.quantity} />
          </View>
        ))}
      </View>
    </>
  );
};

export default OrderDetails;

const styles = StyleSheet.create({
  title: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    padding: 16,
    marginTop: 0,
    marginBottom: 0,
    marginStart: -8,
    marginEnd: -8,
  },
  section: {
    paddingTop: 12,
    paddingBottom: 16,
    paddingHorizontal: 24,
    marginBottom: 8,
  },
  general: {
    paddingTop: 16,
    paddingBottom: 16,
  },
  partner: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 40,
    height: 40,
    borderWidth: 1,
    borderColor: '#ebebeb',
    borderRadius: 20,
  },
  partnerName: {
    marginStart: 16,
    marginBottom: 0,
  },
  status: {
    marginTop: 16,
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'stretch',
    alignContent: 'stretch',
    marginTop: 8,
    marginStart: -8,
  },
  invoiceDescr: {
    flexDirection: 'row',
    marginTop: 16,
    marginBottom: 8,
  },
  products: {
    marginVertical: 16,
  },
  listItem: {
    marginVertical: 4,
  },
});
