export { default } from './AnimatedSplashScreen';
