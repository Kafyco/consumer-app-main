import { StyleSheet, Dimensions, ViewStyle } from 'react-native';

const { width, height } = Dimensions.get('screen');

export const _staticBackground = (logoOpacity: object, backgroundColor?: string) => [
  logoOpacity,
  StyleSheet.absoluteFill,
  { backgroundColor: backgroundColor || null },
];

export const _dynamicImageBackground = (
  imageScale: object,
  logoOpacity: object,
  backgroundColor?: string,
) => [
  imageScale,
  logoOpacity,
  {
    ...(StyleSheet.absoluteFill as object),
    width,
    height,
    top: 0,
    alignItems: 'center',
    justifyContent: 'center',
    tintColor: backgroundColor || null,
  },
];

export const _dynamicLogoStyle = (
  logoScale: object,
  logoOpacity: object,
  logoWidth?: number,
  logoHeight?: number,
) => [
  logoScale,
  logoOpacity,
  {
    width: logoWidth || 150,
    height: logoHeight || 150,
  },
];

export const _dynamicCustomComponentStyle = (
  logoScale: object,
  logoOpacity: object,
  logoWidth?: number,
  logoHeight?: number,
) => [
  logoScale,
  logoOpacity,
  {
    width: logoWidth || 150,
    height: logoHeight || 150,
    alignItems: 'center',
    justifyContent: 'center',
  },
];

export default StyleSheet.create({
  container: {
    flex: 1,
  },
  containerGlue: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
  },
  flex: {
    flex: 1,
  },
  logoStyle: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
