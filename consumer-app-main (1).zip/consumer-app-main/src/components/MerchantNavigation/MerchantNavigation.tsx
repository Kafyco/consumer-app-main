import React from 'react';
import { StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import { EdgeInsets } from 'react-native-safe-area-context';
import Animated, {
  useAnimatedStyle,
  useDerivedValue,
  interpolate,
  Extrapolate,
  withTiming,
} from 'react-native-reanimated';

import { MERCHANT_HEADER_HEIGHT } from 'components/MerchantHeader';
import MerchantSearch from 'components/MerchantSearch';
import ScreenHeader, { SCREEN_HEADER_SMALL_HEIGHT } from 'components/ScreenHeader';

import Colors from 'constants/Colors';
import { SPRING_SIZE } from 'constants/Layout';

export const SEARCH_PLACEHOLDER_HEIGHT = 64;

export interface MerchantNavigationProps {
  scrollY: Animated.SharedValue<number>;
  insets: EdgeInsets;
  onSearchBegin?(): void;
}

const MerchantNavigation = ({ scrollY, insets, onSearchBegin }: MerchantNavigationProps) => {
  const [t] = useTranslation();

  /* Animation */
  const isSticked = useDerivedValue(() => {
    return scrollY.value >= MERCHANT_HEADER_HEIGHT - SCREEN_HEADER_SMALL_HEIGHT + 16;
  }, [scrollY.value]);
  const animatedShadow = useAnimatedStyle(() => {
    if (isSticked.value) {
      return {
        shadowOpacity: withTiming(0.22),
        shadowRadius: withTiming(2.22),
        elevation: withTiming(3),
      };
    }
    return {
      shadowRadius: 0,
      shadowOpacity: 0,
      elevation: 0,
    };
  });
  const animatedShadow2 = useAnimatedStyle(() =>
    isSticked.value
      ? {
          elevation: withTiming(3),
        }
      : {
          elevation: 0,
        },
  );
  const searchStyles = useAnimatedStyle(
    () => ({
      top: interpolate(
        scrollY.value,
        [-SPRING_SIZE, MERCHANT_HEADER_HEIGHT - SCREEN_HEADER_SMALL_HEIGHT + 16],
        [
          MERCHANT_HEADER_HEIGHT + insets.top + SPRING_SIZE + 16,
          insets.top + SCREEN_HEADER_SMALL_HEIGHT,
        ],
        Extrapolate.CLAMP,
      ),
    }),
    [scrollY],
  );
  const navigaionStyles = useAnimatedStyle(() => {
    const animationDistance = MERCHANT_HEADER_HEIGHT / 3;
    const threshold = MERCHANT_HEADER_HEIGHT - SCREEN_HEADER_SMALL_HEIGHT - animationDistance;
    return {
      display: scrollY.value > threshold - 1 ? 'flex' : 'none',
      opacity: interpolate(
        scrollY.value,
        [threshold, threshold + animationDistance],
        [0, 1],
        Extrapolate.CLAMP,
      ),
    };
  }, [scrollY]);

  return (
    <>
      <Animated.View style={[styles.search, searchStyles, animatedShadow]}>
        <MerchantSearch placeholder={t('search-within-supplier')} onSearchBegin={onSearchBegin} />
      </Animated.View>
      <ScreenHeader style={[styles.navigtaion, navigaionStyles, animatedShadow2]} />
    </>
  );
};

export default MerchantNavigation;

const styles = StyleSheet.create({
  navigtaion: {
    zIndex: 10,
    position: 'absolute',
    left: 0,
    top: 0,
    right: 0,
    backgroundColor: Colors.background,
    display: 'none',
    opacity: 0,
  },
  search: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingBottom: 8,
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 0,
    shadowOpacity: 0,
    elevation: 0,
  },
});
