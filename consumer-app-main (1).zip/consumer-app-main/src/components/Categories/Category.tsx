import * as React from 'react';
import { StyleSheet, View, Image, TouchableOpacity } from 'react-native';

import { Title } from 'components/Text';
import { CategoryList as CategoryType } from 'api/models';
import getImageUrl from 'utils/getImageUrl';

export const TILE_HEIGHT = 64;

export interface CategoryProps {
  item: CategoryType;
  onPress?(): void;
}

const Category = ({ item: { id, name, imageThumbnail }, onPress }: CategoryProps) => {
  const image = getImageUrl(imageThumbnail, '72x72');

  return (
    <TouchableOpacity onPress={onPress} style={styles.container}>
      <View style={styles.inner}>
        <Title level={4} style={styles.title} numberOfLines={2}>
          {name}
        </Title>
      </View>
      {image ? (
        <View>
          <Image source={{ uri: image }} style={styles.image} />
        </View>
      ) : null}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    alignContent: 'stretch',
    borderRadius: 20,
    backgroundColor: '#fff',
    paddingStart: 16,
    paddingEnd: 4,
    paddingVertical: 8,
    height: TILE_HEIGHT,
    overflow: 'hidden',
  },
  inner: {
    flex: 1,
  },
  title: {
    lineHeight: 18,
  },
  image: {
    resizeMode: 'contain',
    borderRadius: 20,
    width: TILE_HEIGHT,
    height: TILE_HEIGHT,
  },
});

export default Category;
