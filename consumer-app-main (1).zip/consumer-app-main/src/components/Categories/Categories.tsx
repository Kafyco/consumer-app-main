import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { useNavigation, NavigationProp } from '@react-navigation/native';

import { CategoryList as CategoryType } from 'api/models';
import Category from './Category';
import { MerchantRootParamList } from 'navigation/MerchantRoot';

export interface CategoriesProps {
  items: Array<CategoryType>;
}

const Categories = ({ items }: CategoriesProps) => {
  const navigation = useNavigation<NavigationProp<MerchantRootParamList>>();
  const handleOnPress = (categoryId: string) => {
    navigation.navigate('MerchantCategory', {
      categoryId,
    });
  };

  return (
    <View style={styles.container}>
      {items.map((item: CategoryType) => (
        <View key={item.id} style={styles.item}>
          <Category item={item} onPress={() => handleOnPress(item.id)} />
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -4,
  },
  item: {
    width: '50%',
    paddingHorizontal: 4,
    marginVertical: 4,
  },
});

export default Categories;
