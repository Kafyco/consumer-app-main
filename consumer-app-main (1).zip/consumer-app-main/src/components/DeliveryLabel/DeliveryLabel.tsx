import React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import Text from 'components/Text';
import Colors from 'constants/Colors';
import { DeliverySettings } from 'api/models';
import { useTranslation } from 'react-i18next';

export interface DeliveryLabelProps {
  delivery: DeliverySettings;
  inverted?: boolean;
}

const DeliveryLabel = ({ delivery, inverted = false }: DeliveryLabelProps) => {
  const [t] = useTranslation();
  const textColor = inverted ? 'white' : 'regular';
  const tintColor = inverted ? Colors.white : Colors.primary;
  const { estimatedMinDays, estimatedMaxDays } = delivery || {};
  const deliveryLabel = React.useMemo(() => {
    if (!estimatedMaxDays) {
      return t('shipping-details.delivers');
    }
    if (estimatedMaxDays <= 1) {
      return t('shipping-details.tomorrow');
    }
    if (estimatedMinDays !== estimatedMaxDays) {
      return t('shipping-details.range', {
        count: estimatedMaxDays,
        min: estimatedMinDays,
      });
    }
    return t('shipping-details.days', { count: estimatedMaxDays });
  }, [estimatedMinDays, estimatedMaxDays]);

  return (
    <View style={styles.container}>
      <View>
        <Image
          source={require('assets/images/icons/Truck.png')}
          style={[styles.icon, { tintColor }]}
        />
      </View>
      <View style={styles.text}>
        <Text color={textColor} size={14}>
          {deliveryLabel}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'center',
  },
  icon: {
    width: 18,
    height: 13,
  },
  text: {
    paddingStart: 8,
  },
});

export default DeliveryLabel;
