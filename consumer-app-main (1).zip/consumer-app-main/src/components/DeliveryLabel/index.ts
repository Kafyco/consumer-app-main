export { default } from './DeliveryLabel';
