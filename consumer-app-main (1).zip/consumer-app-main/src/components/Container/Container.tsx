import * as React from 'react';
import { View, StyleSheet, ViewStyle, StyleProp } from 'react-native';
import Layout from 'constants/Layout';

export interface ContainerProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

const Container = ({ children, style }: ContainerProps) => {
  const styles = StyleSheet.flatten(style);
  return <View style={[defaultStyles, styles]}>{children}</View>;
};

export default Container;

const defaultStyles: ViewStyle = {
  flex: 1,
  alignSelf: 'stretch',
  paddingHorizontal: Layout.screenPadding,
};
