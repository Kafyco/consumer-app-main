import React from 'react';
import { View, SectionList, RefreshControl, SectionListData } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useSharedValue, useAnimatedScrollHandler } from 'react-native-reanimated';

import { Partner as MerchantType, Address as AddressType } from 'api/models';
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { fetchMerchants, selectAllMerchants, selectMerchantsStatus } from 'reducers/merchants';
import {
  selectAllAddresses,
  selectAddressById,
  selectAddressesStatus,
  setReturnTo as setAddressReturnTo,
} from 'reducers/addresses';
import { selectCurrentAddress, setCurrentAddress } from 'reducers/app';

import HomePageHeader, {
  HOME_HEADER_HEIGHT,
  HOME_HEADER_COLLAPSED_HEIGHT,
} from 'components/HomePageHeader';
import LoadingScreen from 'components/LoadingScreen';
import MerchantsList from 'components/MerchantsList';
import AddressSelector, { ModalType as AddressSelectorType } from 'components/AddressSelector';

type Props = StackScreenProps<MainNavigationParamList, 'Home'>;

const getSectionsList = (merchants: Array<MerchantType>) => {
  const hash = {};
  const sorting = [
    'Fruits & Vegetables',
    'Chicken & Poultry',
    'Meat',
    'Fish & Seafood',
    'Dry Items',
    'Frozen Items',
    'Bakery, Sweets, Snacks',
    'Dairy & Eggs',
    'Drinks',
    'Disposable',
    'Cleaning & Household',
  ];

  if (!merchants) {
    return [];
  }

  return merchants
    .reduce((res: any, merchant: MerchantType) => {
      const { categoriesNames } = merchant;
      categoriesNames &&
        categoriesNames.forEach((category: string) => {
          let categoryIndex = hash[category];
          if (categoryIndex === undefined) {
            categoryIndex = res.length;
            hash[category] = categoryIndex;
            res.push({
              index: categoryIndex,
              title: category,
              data: [],
            });
          }
          res[categoryIndex].data.push(merchant);
        });
      return res;
    }, [])
    .sort(
      (a: SectionListData<MerchantType>, b: SectionListData<MerchantType>) =>
        sorting.indexOf(a.title) > sorting.indexOf(b.title),
    )
    .map((section: SectionListData<MerchantType>, index: number) => ({ ...section, index }));
};

export default function HomeScreen({ navigation, route }: Props) {
  const { addressId } = route.params || {};
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const scrollY = useSharedValue(0);
  const dispatch = useDispatch();
  const merchants = useSelector(selectAllMerchants);
  const merchantsStatus = useSelector(selectMerchantsStatus);
  const addresses = useSelector(selectAllAddresses);
  const addressesStatus = useSelector(selectAddressesStatus);
  const currentAddress = useSelector(selectCurrentAddress);
  const currentAddressEntry = useSelector((state) =>
    currentAddress ? selectAddressById(state, currentAddress.id) : undefined,
  );
  const routeParamsAddress = useSelector((state) =>
    addressId ? selectAddressById(state, addressId) : undefined,
  );
  const sections = React.useMemo(() => getSectionsList(merchants), [merchants]);
  const listRef = React.useRef<SectionList>(null);
  const addressSelectorRef = React.useRef<AddressSelectorType>(null);
  const [listBreakpoints, setListBreakpoints] = React.useState<number[]>([]);
  const [refreshing, setRefreshing] = React.useState<boolean>(false);

  // Measurements

  const handleScroll = useAnimatedScrollHandler(({ contentOffset: { y } }) => {
    scrollY.value = y;
  });

  const handleScrollToTop = () => {
    scrollY.value = 0;
  };

  const handleMeasurements = (index: number, positionY: number) => {
    listBreakpoints[index] = positionY;
    setListBreakpoints(listBreakpoints);
  };

  // Handlers

  const scrollToSection = (item: any, index: number) => {
    listRef.current?.scrollToLocation({
      sectionIndex: index,
      itemIndex: 0,
      viewOffset: HOME_HEADER_COLLAPSED_HEIGHT + insets.top - 16,
    });
  };

  const handleMerchantPress = (partner: MerchantType) => {
    navigation.navigate('MerchantRoot', {
      merchantId: partner.id,
    });
  };

  const showAddressSelector = () => {
    addressSelectorRef.current?.present();
  };

  const handleAddressChange = (address: AddressType) => {
    if (!currentAddressEntry || address.id !== currentAddressEntry.id) {
      dispatch(setCurrentAddress(address));
      handleScrollToTop();
    }
  };

  const handleNewAddress = () => {
    dispatch(setAddressReturnTo({ name: 'Home' }));
    navigation.navigate('AddressLocation');
  };

  const handleRefresh = async () => {
    if (!refreshing) {
      setRefreshing(true);
      await dispatch(fetchMerchants({ address: currentAddressEntry?.id }));
      setRefreshing(false);
    }
  };

  // When addressId is passed as route param, change current address
  React.useEffect(() => {
    if (routeParamsAddress && routeParamsAddress.id !== currentAddress?.id) {
      handleAddressChange(routeParamsAddress);
    }
    // We are not passing `currentAddress` as dependency to avoid reload when current address is changed
  }, [routeParamsAddress]);

  // When current address is changed
  React.useEffect(() => {
    if (currentAddressEntry) {
      dispatch(fetchMerchants({ address: currentAddressEntry.id }));
    }
  }, [currentAddressEntry]);

  // Check if saved current address still exists.
  React.useEffect(() => {
    if (addressesStatus === 'fulfilled' && !currentAddressEntry) {
      // Must preserve at least one address.
      handleAddressChange(addresses[0]);
    }
  }, [addressesStatus, currentAddressEntry, addresses]);

  return (
    <AddressSelector.Provider>
      <View style={{ flex: 1 }}>
        {!merchants.length && merchantsStatus !== 'fulfilled' ? (
          <LoadingScreen />
        ) : (
          <MerchantsList
            ref={listRef}
            sections={sections}
            topPlaceholderHeight={HOME_HEADER_HEIGHT}
            onMerchantPress={handleMerchantPress}
            onScroll={handleScroll}
            onCategoryMeasure={handleMeasurements}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          />
        )}
        <HomePageHeader
          scrollY={scrollY}
          sections={sections}
          orders={{}}
          listBreakpoints={listBreakpoints}
          onCategoryTabPress={scrollToSection}
          onAddressPress={showAddressSelector}
        />
        <AddressSelector.Modal
          ref={addressSelectorRef}
          isLoading={addressesStatus !== 'fulfilled'}
          selectedId={currentAddress?.id}
          addresses={addresses}
          onChange={handleAddressChange}
          selectedFirst={true}
          sideAction={{
            label: t('add'),
            onPress: handleNewAddress,
          }}
        />
      </View>
    </AddressSelector.Provider>
  );
}
