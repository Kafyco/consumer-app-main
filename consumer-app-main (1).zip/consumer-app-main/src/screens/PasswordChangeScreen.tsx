import * as React from 'react';
import { View, StyleSheet, ScrollView, Alert, Platform, KeyboardAvoidingView } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';
import { Formik } from 'formik';
import * as Yup from 'yup';
import * as Sentry from 'sentry-expo';
import * as Analytics from 'utils/analytics';

import { PasswordChangeRequest } from 'api/models';
import { ERROR_FORM_VALIDATION } from 'api/constants';
import { changePassword as apiChangePassword } from 'api/index';

import ScreenHeader from 'components/ScreenHeader';
import Container from 'components/Container';
import Sheet from 'components/Sheet';
import Field from 'components/Field';
import Button from 'components/Button';

type Props = StackScreenProps<MainNavigationParamList, 'PasswordChange'>;

export default function PasswordChangeScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const [globalError, setGlobalError] = React.useState<string>();

  const initialValues = {
    oldPassword: '',
    newPassword1: '',
    newPassword2: '',
  };

  const validationSchema = Yup.object().shape({
    oldPassword: Yup.string()
      .min(9, t('validation.min', { field: t('auth.password'), count: 9 }))
      .required(t('validation.required')),
    newPassword1: Yup.string()
      .min(9, t('validation.min', { field: t('auth.password'), count: 9 }))
      .required(t('validation.required')),
    newPassword2: Yup.string()
      .min(9, t('validation.min', { field: t('auth.confirm-password'), count: 9 }))
      .oneOf([Yup.ref('newPassword1'), null], t('validation.passwords-match'))
      .required(t('validation.required')),
  });

  const onSubmit = async (values: any, actions: any) => {
    try {
      const validationResult = await actions.validateForm(values);
      const isValid = !Object.keys(validationResult).length;

      if (isValid) {
        const r = await apiChangePassword(values);

        Analytics.logEvent('PASSWORD_CHANGED');

        Alert.alert('Password successfully changed');
        navigation.goBack();
      } else {
        actions.setErrors(validationResult);
      }
      // do something
    } catch (err: any) {
      if (err?.code === ERROR_FORM_VALIDATION) {
        actions.setErrors(err.data);
      } else {
        Sentry.Native.captureException(err);
        setGlobalError(t('auth.unknown-error-login'));
      }
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.container}>
        <ScreenHeader headerTitle={t('change-password')} />
        <ScrollView>
          <Container>
            <Formik<PasswordChangeRequest>
              initialValues={initialValues}
              validationSchema={validationSchema}
              validateOnChange={true}
              validateOnMount={true}
              onSubmit={onSubmit}
            >
              {({ isSubmitting, handleSubmit, isValid }) => (
                <Sheet style={styles.sheet}>
                  <Field
                    name="oldPassword"
                    label={t('auth.password')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoCompleteType="password"
                    textContentType="password"
                    secureTextEntry
                  />
                  <Field
                    name="newPassword1"
                    label={t('auth.new-password')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoCompleteType="password"
                    textContentType="password"
                    secureTextEntry
                  />
                  <Field
                    name="newPassword2"
                    label={t('auth.confirm-password')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoCompleteType="password"
                    textContentType="password"
                    secureTextEntry
                  />
                  <Button
                    mode="contained"
                    disabled={!isValid}
                    loading={isSubmitting}
                    onPress={isSubmitting ? undefined : handleSubmit}
                  >
                    {t('change-password')}
                  </Button>
                </Sheet>
              )}
            </Formik>
          </Container>
        </ScrollView>
        <Snackbar
          visible={!!globalError}
          onDismiss={() => setGlobalError(undefined)}
          action={{
            label: t('ok'),
            onPress: () => setGlobalError(undefined),
          }}
        >
          {globalError}
        </Snackbar>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  sheet: {
    marginBottom: 32,
  },
});
