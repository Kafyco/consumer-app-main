import React from 'react';
import { ScrollView, View, StyleSheet, Platform, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { debounce } from 'lodash';

import { MerchantRootParamList } from 'navigation/MerchantRoot';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import { Product as ProductType } from 'api/models';
import Layout from 'constants/Layout';

import {
  selectAllResults,
  selectResultsLoading,
  selectHasMoreResults,
  fetchSearchResults,
  fetchMoreResults,
  clearSearchResults,
} from 'reducers/merchantSearch';
import { setStagedProduct, resetStagedProduct, selectTotalBasketLines } from 'reducers/basket';

import { ProductsFlatList } from 'components/Products';
import BasketWidget, { BASKET_WIDGET_HEIGHT } from 'components/BasketWidget';
import AddToCartWidget, { ModalType as AddToCartType } from 'components/AddToCartWidget';
import ScreenHeader from 'components/ScreenHeader';
import SearchInput from 'components/SearchInput';
import EmptyScreen from 'components/EmptyScreen';
import Text from 'components/Text';
import LoadingScreen from 'components/LoadingScreen';
import { useMerchant } from 'utils/merchantContext';

const PRODUCTS_PER_PAGE = 20;

type Props = StackScreenProps<MerchantRootParamList, 'MerchantSearch'>;

export default function CategoryScreen({ route }: Props) {
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const [t] = useTranslation();

  // Get categories from the store
  const { search: searchParam } = route.params;
  const { merchantId } = useMerchant();

  // Get products from the store
  const searchResults = useSelector(selectAllResults);
  const isLoading = useSelector(selectResultsLoading);
  const hasMoreResults = useSelector(selectHasMoreResults);
  const isBasketEmpty = !useSelector(selectTotalBasketLines);

  // Basket
  const addToCartRef = React.useRef<AddToCartType>(null);

  //
  const [search, setSearch] = React.useState(decodeURIComponent(searchParam || ''));
  const [latestSearch, setLatestSearch] = React.useState(decodeURIComponent(searchParam || ''));
  const paddingBottom = React.useMemo(
    () => (isBasketEmpty ? 0 : BASKET_WIDGET_HEIGHT) + insets.bottom + 24,
    [isBasketEmpty],
  );

  const handleLoadMore = () => {
    hasMoreResults && dispatch(fetchMoreResults({ count: PRODUCTS_PER_PAGE }));
  };

  const handleProductPress = (product: ProductType) => {
    dispatch(setStagedProduct(product));
    addToCartRef.current?.present();
  };

  const handleAddToBasketDismiss = () => {
    dispatch(resetStagedProduct());
  };

  const handleSearchChange = (value: string) => {
    setSearch(value);
    if (value) {
      handleSearch(value);
    } else {
      handleSearch.cancel();
      setLatestSearch('');
      dispatch(clearSearchResults());
    }
  };

  const handleSearch = React.useCallback(
    debounce(
      (value) => {
        if (value) {
          dispatch(fetchSearchResults({ merchantId, search: value }));
          setLatestSearch(value);
        } else {
          dispatch(clearSearchResults());
          setLatestSearch('');
        }
      },
      780,
      { trailing: true },
    ),
    [],
  );

  React.useEffect(() => {
    if (latestSearch) {
      dispatch(fetchSearchResults({ merchantId, search: latestSearch }));
    }

    return () => {
      handleSearch.cancel();
      dispatch(clearSearchResults());
    };
  }, []);

  const renderContent = () => {
    if (!latestSearch) {
      return (
        <ScrollView
          style={styles.container}
          contentContainerStyle={[styles.emptyStart, { paddingBottom }]}
          keyboardDismissMode="on-drag"
        >
          <Text size={14} color="secondary">
            {t('start-searching')}
          </Text>
        </ScrollView>
      );
    }

    if (isLoading && !searchResults.length) {
      return <LoadingScreen style={{ paddingBottom }} />;
    }

    if (searchResults.length) {
      return (
        <ProductsFlatList
          items={searchResults}
          onProductPress={handleProductPress}
          isLoading={isLoading}
          ListEmptyComponent={null}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={5}
          keyboardDismissMode="on-drag"
          containerStyle={{ paddingBottom }}
        />
      );
    }

    return (
      <ScrollView keyboardDismissMode="on-drag">
        <EmptyScreen
          // image={require('assets/images/Larry__Searching.png')}
          title={t('noproducts')}
          text={t('empty-search-desct', { search: latestSearch })}
          style={styles.empty}
        />
      </ScrollView>
    );
  };

  return (
    <AddToCartWidget.Provider>
      <KeyboardAvoidingView
        behavior={Platform.OS == 'ios' ? 'padding' : undefined}
        style={[styles.container, { position: 'relative' }]}
      >
        <View>
          <ScreenHeader headerTitle={t('search')} />
          <View style={styles.search}>
            <SearchInput
              value={search}
              onChangeText={handleSearchChange}
              placeholder={t('search-within-supplier')}
              autoFocus
            />
          </View>
        </View>
        <View style={styles.container}>{renderContent()}</View>
        <BasketWidget />
      </KeyboardAvoidingView>
      <AddToCartWidget.Modal ref={addToCartRef} onDismiss={handleAddToBasketDismiss} />
    </AddToCartWidget.Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  emptyStart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  empty: {
    paddingTop: 80,
  },
  search: {
    paddingHorizontal: Layout.screenPadding,
    paddingBottom: 8,
  },
});
