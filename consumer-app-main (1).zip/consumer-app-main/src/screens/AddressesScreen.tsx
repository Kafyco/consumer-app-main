import * as React from 'react';
import { View, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import {
  selectAddressesStatus,
  selectAllAddresses,
  fetchAddresses,
  deleteAddress,
} from 'reducers/addresses';
import Layout from 'constants/Layout';

import ScreenHeader, { Button as ScreenHeaderButton } from 'components/ScreenHeader';
import EmptyScreen from 'components/EmptyScreen';
import LoadingScreen from 'components/LoadingScreen';
import Sheet from 'components/Sheet';
import Address from 'components/Address';
import Text from 'components/Text';
import Button from 'components/Button';
import DialogConfirm from 'components/DialogConfirm';

type Props = StackScreenProps<MainNavigationParamList, 'Addresses'>;

export default function AddressesScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = React.useState(false);
  const [deletingId, setDeletingId] = React.useState<number | string | null>(null);
  const [deleteLoading, setDeleteLoading] = React.useState<boolean>(false);
  const addressesStatus = useSelector(selectAddressesStatus);
  const addressList = useSelector(selectAllAddresses);

  const handleAddNew = () => {
    navigation.navigate('AddressLocation');
  };

  const handleEditPress = (addressId: number | string) => {
    navigation.navigate({
      name: 'AddressForm',
      params: {
        addressId,
      },
    });
  };

  const handleDelete = (addressId: number | string) => {
    setDeletingId(addressId);
  };

  const handleConfirmDelete = async () => {
    if (deletingId) {
      setDeleteLoading(true);
      await dispatch(deleteAddress(deletingId));
      setDeleteLoading(false);
      setDeletingId(null);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await dispatch(fetchAddresses());
    setRefreshing(false);
  };

  React.useEffect(() => {
    if (addressesStatus === 'idle') {
      dispatch(fetchAddresses());
    }
  }, []);

  return (
    <View style={styles.container}>
      <ScreenHeader
        headerTitle={t('manage-addresses')}
        actions={
          addressList.length ? (
            <ScreenHeaderButton label={t('add-new')} onPress={handleAddNew} />
          ) : null
        }
      />

      {addressesStatus === 'fulfilled' || addressList.length ? (
        <FlatList
          data={addressList}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <Sheet key={item.id} style={styles.item}>
              <Address info={item} />
              <View style={styles.itemActions}>
                <Button
                  icon="pencil"
                  micro
                  compact
                  uppercase
                  onPress={() => handleEditPress(item.id)}
                  style={styles.action}
                >
                  {t('edit')}
                </Button>
                {addressList.length > 1 && (
                  <Button
                    icon="trash"
                    compact
                    micro
                    uppercase
                    onPress={() => handleDelete(item.id)}
                    style={styles.action}
                  >
                    {t('delete')}
                  </Button>
                )}
              </View>
            </Sheet>
          )}
          ListEmptyComponent={
            <EmptyScreen
              image={require('assets/images/Larry__Location.png')}
              text={t('empty-address-message')}
              actionText={t('add-new-address')}
              onActionPress={handleAddNew}
              style={{ paddingBottom: insets.bottom }}
            />
          }
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom }]}
          style={styles.container}
        />
      ) : (
        <LoadingScreen />
      )}
      <DialogConfirm
        loading={deleteLoading}
        visible={!!deletingId}
        onCancel={() => setDeletingId(null)}
        onConfirm={handleConfirmDelete}
      >
        <Text>{t('address-delete-confirm')}</Text>
      </DialogConfirm>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Layout.screenPadding,
    flexGrow: 1,
  },
  item: {
    marginBottom: 16,
    paddingStart: 24,
    paddingEnd: 40,
    paddingTop: 16,
    paddingBottom: 12,
  },
  itemActions: {
    flexDirection: 'row',
    marginTop: 8,
    marginLeft: -8,
  },
  action: {
    marginEnd: 4,
  },
});
