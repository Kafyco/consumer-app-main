import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScrollView, View } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';
import * as Linking from 'expo-linking';
import * as Sentry from 'sentry-expo';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import useIsMounted from 'hooks/useIsMounted';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { fetchOrderByNumber, selectOrderById, reorder } from 'reducers/orders';

import ScreenHeader, { Button as ScreenHeaderButton } from 'components/ScreenHeader';
import Container from 'components/Container';
import OrderDetails from 'components/OrderDetails';
import LoadingScreen from 'components/LoadingScreen';

type Props = StackScreenProps<MainNavigationParamList, 'OrderDetails'>;

export default function OrderDetailsScreen({ route, navigation }: Props) {
  const { orderNumber } = route.params;
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const isMounted = useIsMounted();
  const order = useSelector((state) => selectOrderById(state, orderNumber));

  const [isReorderLoading, setIsReorderLoading] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState<string>();

  const handleReorder = async () => {
    if (!isReorderLoading && order) {
      setIsReorderLoading(true);

      try {
        await dispatch(reorder(order));
        Linking.openURL(Linking.createURL(`merchant/${order.partner.id}/basket`));
      } catch (err) {
        Sentry.Native.captureException(err);
        isMounted() && setErrorMessage(t('error.reorder'));
      } finally {
        isMounted() && setIsReorderLoading(false);
      }
    }
  };

  const onDismissSnackBar = () => {
    setErrorMessage(undefined);
  };

  React.useEffect(() => {
    if (!order) {
      dispatch(fetchOrderByNumber(orderNumber));
    }
  }, [orderNumber]);

  return (
    <View style={{ flex: 1 }}>
      <ScreenHeader headerTitle={t('order-details')} />
      <ScrollView>
        <Container style={{ paddingBottom: insets.bottom }}>
          {order ? <OrderDetails order={order} handleReorder={handleReorder} /> : <LoadingScreen />}
        </Container>
      </ScrollView>
      <Snackbar
        visible={!!errorMessage}
        onDismiss={onDismissSnackBar}
        action={{
          label: t('ok'),
          onPress: onDismissSnackBar,
        }}
        style={{ marginBottom: insets.bottom }}
      >
        {errorMessage}
      </Snackbar>
    </View>
  );
}
