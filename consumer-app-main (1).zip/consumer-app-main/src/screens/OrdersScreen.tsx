import * as React from 'react';
import { View, StyleSheet, RefreshControl, FlatList } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActivityIndicator } from 'react-native-paper';

import Layout from 'constants/Layout';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import {
  fetchOrders,
  fetchMoreOrder,
  selectAllOrders,
  selectOrdersLoading,
  selectHasMoreProducts,
} from 'reducers/orders';

import ScreenHeader from 'components/ScreenHeader';
import OrderCard from 'components/OrderCard';
import LoadingScreen from 'components/LoadingScreen';
import OrdersEmpty from 'components/OrdersEmpty';

const ORDERS_PER_PAGE = 5;

type Props = StackScreenProps<MainNavigationParamList, 'Orders'>;

export default function OrdersScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const orders = useSelector(selectAllOrders);
  const isLoading = useSelector(selectOrdersLoading);
  const hasMore = useSelector(selectHasMoreProducts);
  const [refreshing, setRefreshing] = React.useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);

    try {
      await dispatch(fetchOrders({ limit: ORDERS_PER_PAGE }));
      setRefreshing(false);
    } catch (e) {
      setRefreshing(false);
    }
  };

  const handleLoadMore = async () => {
    if (hasMore && !isLoading) {
      dispatch(fetchMoreOrder({ limit: ORDERS_PER_PAGE }));
    }
  };

  const handleItemPress = (orderNumber: string | number) => {
    navigation.navigate('OrderDetails', { orderNumber });
  };

  const handleEmptyOrdersPress = () => {
    navigation.navigate('Home', {});
  };

  React.useEffect(() => {
    dispatch(fetchOrders({ limit: ORDERS_PER_PAGE }));
  }, []);

  return (
    <View style={styles.container}>
      <ScreenHeader headerTitle={t('my-orders')} />
      {isLoading && !orders.length ? (
        <LoadingScreen />
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item) => item.number}
          renderItem={({ item }) => (
            <View style={styles.item}>
              <OrderCard order={item} onPress={() => handleItemPress(item.number)} />
            </View>
          )}
          ListFooterComponent={() => (isLoading ? <ActivityIndicator /> : null)}
          ListEmptyComponent={<OrdersEmpty onButtonPress={handleEmptyOrdersPress} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={3}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom }]}
          style={styles.container}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Layout.screenPadding,
    flexGrow: 1,
  },
  item: {
    marginBottom: 8,
  },
});
