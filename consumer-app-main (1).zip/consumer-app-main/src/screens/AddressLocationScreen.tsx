import * as React from 'react';
import { useTranslation } from 'react-i18next';
import {
  View,
  StyleSheet,
  TouchableWithoutFeedback,
  Keyboard,
  Image,
  TextInput,
} from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import MapView, { PROVIDER_GOOGLE, Region } from 'react-native-maps';
import { Snackbar } from 'react-native-paper';
import Animated, { useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { debounce } from 'lodash';

import Colors from 'constants/Colors';
import randomString from 'utils/randomString';
import useUserLocation from 'hooks/useUserLocation';
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import {
  stageAddress,
  selectStagedAddress,
  clearStagedAddress,
  selectReturnTo,
  clearReturnTo,
} from 'reducers/addresses';
import * as googlemaps from 'api/googlemaps';
import { PlaceResult } from 'api/googlemaps/models';

import { MainNavigationParamList } from 'navigation/MainNavigator';
import ScreenHeader from 'components/ScreenHeader';
import Container from 'components/Container';
import SearchInput from 'components/SearchInput';
import AddressSuggestion from 'components/AddressSuggestion';
import BottomButton from 'components/BottomButton';
import PoweredByGoogle from 'components/PoweredByGoogle';

const latitudeDelta = 0.005;
const longitudeDelta = 0.005;

const initialRegion: Region = {
  latitudeDelta: 0.025,
  longitudeDelta: 0.025,
  latitude: 25.117002,
  longitude: 55.200594,
};

type Props = StackScreenProps<MainNavigationParamList, 'AddressForm'>;

export default function AddressLocationScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const userLocation = useUserLocation();
  const dispatch = useDispatch();
  const stagedAddress = useSelector(selectStagedAddress);
  const returnTo = useSelector(selectReturnTo);

  const [val, setVal] = React.useState<string>(stagedAddress?.line3 || '');
  const [suggestions, setSuggestion] = React.useState<object[] | null>();
  const [searchFocused, setSearchFocused] = React.useState<boolean>(false);
  const [errorMessage, setErrorMessage] = React.useState<string>();

  const searchInputRef = React.useRef<TextInput>(null);
  const mapViewRef = React.useRef<MapView | null>();
  const sessionToken = React.useRef<string>(randomString());
  const hasValidStagedLocationCoords = stagedAddress && stagedAddress.lat && stagedAddress.lon;

  // Avoid using states to reduce overflows and collisions with a MapView
  const initialMapRegion = React.useMemo(
    () =>
      hasValidStagedLocationCoords && stagedAddress
        ? {
            ...initialRegion,
            latitude: stagedAddress.lat,
            longitude: stagedAddress.lon,
          }
        : initialRegion,
    [stagedAddress],
  );
  const region = React.useRef<Region>(initialMapRegion);
  const place = React.useRef<PlaceResult>();

  const setRegion = (val: Region) => {
    region.current = val;
  };
  const setPlace = (val?: PlaceResult) => {
    place.current = val;
  };

  // ANIMATION

  const fadeAnimatedStyles = useAnimatedStyle(() => ({
    opacity: withTiming(searchFocused ? 1 : 0),
  }));
  const listAnimatedStyles = useAnimatedStyle(() => ({
    opacity: withTiming(suggestions?.length ? 1 : 0, { duration: 300 }),
  }));

  // HANDLERS

  // Map
  const handleMapReady = () => {
    mapViewRef.current?.animateToRegion(region.current);
  };
  const handleRegionChange = (nextRegion: Region) => {
    const placeLocation = place.current?.geometry?.location;
    const isNear = (num1: number, num2: number, accuracy = 500) =>
      Math.floor(num1 * accuracy) === Math.floor(num2 * accuracy);

    // If place was selected and user pan the map too far, reset place and search value
    if (
      !placeLocation ||
      (!isNear(nextRegion.latitude, placeLocation.lat) &&
        !isNear(nextRegion.longitude, placeLocation.lng))
    ) {
      setPlace(undefined);
      setVal('');
    }

    setRegion(nextRegion);
  };

  // Search
  const handleSearchFocus = () => {
    setSearchFocused(true);

    if (val) {
      handleSearch(val);
    }
  };
  const handleSearchBlur = () => setSearchFocused(false);

  const abortSearchRequest = React.useRef<Function>();
  const handleSearch = React.useCallback(
    debounce((input: string) => {
      // Abort previouse request if any
      abortSearchRequest.current?.();

      if (input?.length < 2) {
        setSuggestion(null);
        return;
      }

      const { abort, request } = googlemaps.autocomplete({
        input,
        sessionToken: sessionToken.current,
      });

      request
        .then((data: any) => setSuggestion(data))
        .catch(() => {
          setErrorMessage(t('error.google-maps-api'));
        })
        .finally(() => {
          abortSearchRequest.current = undefined;
        });

      abortSearchRequest.current = abort;
    }, 350),
    [],
  );

  const handleSearchTextChange = (val: string) => {
    setVal(val);
    handleSearch(val);
  };

  const abortPlaceDetails = React.useRef<Function>();
  const handleSuggestionPress = (item: any) => {
    setVal(item.description);
    setSuggestion(null);
    searchInputRef.current?.blur();

    abortPlaceDetails.current?.();

    const { abort, request } = googlemaps.placeDetails({
      placeId: item.place_id,
      sessionToken: sessionToken.current,
    });

    request
      .then((data) => {
        handleSetPlace(data);
        // Refresh token according to documentation
        sessionToken.current = randomString();
      })
      .catch(() => setErrorMessage(t('error.google-maps-api')))
      .finally(() => {
        abortPlaceDetails.current = undefined;
      });

    abortPlaceDetails.current = abort;
  };

  const handleSetPlace = (data: any) => {
    const { lat, lng } = data?.geometry?.location;
    const placeRegion = {
      latitude: lat,
      longitude: lng,
      latitudeDelta,
      longitudeDelta,
    };
    setPlace(data);
    mapViewRef.current?.animateToRegion(placeRegion);
  };

  const confirmLocation = (address: any) => {
    if (stagedAddress) {
      // Editing address
      const updatedAddress = Object.assign({}, stagedAddress, address, {
        line1: stagedAddress.line1 || address.line1,
      });
      dispatch(stageAddress(updatedAddress));
    } else {
      // New address
      dispatch(stageAddress(address));
    }

    navigation.navigate('AddressForm', {});
  };

  const abortGeocode = React.useRef<Function>();
  const handleConfirm = () => {
    // Take information from the palce object if exists
    if (place.current) {
      const { formatted_address, name, geometry, place_id } = place.current;

      confirmLocation({
        line1: name,
        line3: formatted_address,
        lat: geometry?.location?.lat,
        lon: geometry?.location?.lng,
        googleMapsPlaceId: place_id,
      });

      return;
    }

    if (!region.current) {
      console.error(
        "AddressLocation. Can't retreive coordinates from the MapView region. Region is not exists",
      );
      return;
    }

    const { latitude, longitude } = region.current;
    const { abort, request } = googlemaps.geocode({ latitude, longitude });

    abortGeocode.current = abort;
    request
      .then((data) => {
        const location = googlemaps.getGeocodePlace(data, [
          'subpremise',
          'premise',
          'street_address',
          'plus_code',
        ]);

        if (location) {
          //
          confirmLocation({
            line3: location?.formatted_address,
            lat: latitude,
            lon: longitude,
            googleMapsPlaceId: location?.place_id,
          });
        } else {
          throw new Error("Can't retreive address");
        }
      })
      .catch(() => setErrorMessage(t('error.google-maps-api')))
      .finally(() => {
        abortGeocode.current = undefined;
      });
  };

  // EFFECTS

  // Request users location and set map view
  React.useEffect(() => {
    if (userLocation && !hasValidStagedLocationCoords) {
      const { latitude, longitude } = userLocation.coords;
      const userLocationRegion = {
        latitude,
        longitude,
        latitudeDelta,
        longitudeDelta,
      };

      // Update region upfront, in case map is not initialixed yet.
      setRegion(userLocationRegion);
      mapViewRef.current?.animateToRegion(userLocationRegion);
    }
  }, [userLocation]);

  // Cancel any request on dismount.
  React.useEffect(
    () => () => {
      abortSearchRequest.current?.();
      abortPlaceDetails.current?.();
      abortGeocode.current?.();
      // If stagedAddress exists – it was set from other place, don't clear it
      // and let it happen in the place where it was set.
      !stagedAddress && dispatch(clearStagedAddress());
      // ReturnTo is set for new addresses. Clear on cancel
      returnTo && dispatch(clearReturnTo());
    },
    [],
  );

  return (
    <View style={styles.container}>
      <ScreenHeader headerTitle={t('delivery-location')} />
      <Container style={styles.searchWrap}>
        <SearchInput
          ref={searchInputRef}
          placeholder={t('search-address')}
          value={val}
          clearButtonMode={suggestions?.length ? 'always' : 'while-editing'}
          onChangeText={handleSearchTextChange}
          onFocus={handleSearchFocus}
          onBlur={handleSearchBlur}
        />
      </Container>
      <View style={styles.mapWrap}>
        <View style={styles.mapWrap}>
          <MapView
            ref={(mapView) => (mapViewRef.current = mapView)}
            initialRegion={initialRegion}
            provider={PROVIDER_GOOGLE}
            style={styles.map}
            showsUserLocation={true}
            rotateEnabled={false}
            toolbarEnabled={false}
            pitchEnabled={false}
            onRegionChangeComplete={handleRegionChange}
            onMapReady={handleMapReady}
          />
          <View style={styles.markerView}>
            <Image source={require('assets/images/pin.png')} style={styles.marker} />
          </View>
        </View>

        <BottomButton label={t('confirm-location')} positionStatic onPress={handleConfirm} />

        {searchFocused ? (
          <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <Animated.View style={[styles.fade, fadeAnimatedStyles]} />
          </TouchableWithoutFeedback>
        ) : null}
        {suggestions?.length ? (
          <Animated.View style={[styles.listContainer, listAnimatedStyles]}>
            <AddressSuggestion items={suggestions} onItemPress={handleSuggestionPress} />
            <PoweredByGoogle />
          </Animated.View>
        ) : null}
      </View>

      <Snackbar
        visible={!!errorMessage}
        onDismiss={() => setErrorMessage(undefined)}
        action={{
          label: t('ok'),
          onPress: () => setErrorMessage(undefined),
        }}
      >
        {errorMessage}
      </Snackbar>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchWrap: {
    flex: 0,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#d6d6d6',
  },
  scrollView: {
    paddingBottom: 24,
  },
  menuWrap: {
    marginBottom: 16,
  },
  mapWrap: {
    flex: 1,
    backgroundColor: 'grey',
  },
  map: {
    flex: 1,
  },
  markerView: {
    left: '50%',
    marginLeft: -24,
    marginTop: -48,
    position: 'absolute',
    top: '50%',
  },
  marker: {
    width: 48,
    height: 48,
    resizeMode: 'contain',
  },
  fade: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.3)',
    opacity: 0,
  },
  listContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: Colors.background,
    opacity: 0,
  },
});
