import * as React from 'react';
import { View } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { useSharedValue, useAnimatedScrollHandler } from 'react-native-reanimated';

import { Product as ProductType } from 'api/models';
import { MerchantRootParamList } from 'navigation/MerchantRoot';
import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import getImageUrl from 'utils/getImageUrl';
import { selectMerchantById, setFavourite } from 'reducers/merchants';
import { setStagedProduct, resetStagedProduct } from 'reducers/basket';

import LoadingScreen from 'components/LoadingScreen';
import MerchantHeader, { MERCHANT_HEADER_HEIGHT } from 'components/MerchantHeader';
import CoverImage from 'components/CoverImage';
import MerchantHome from 'components/MerchantHome';
import MerchantNavigation, { SEARCH_PLACEHOLDER_HEIGHT } from 'components/MerchantNavigation';
import BasketWidget, { BASKET_WIDGET_HEIGHT } from 'components/BasketWidget';
import AddToCartWidget, { ModalType as AddToCartType } from 'components/AddToCartWidget';
import { useMerchant } from 'utils/merchantContext';

type Props = StackScreenProps<MerchantRootParamList, 'MerchantHome'>;

export default function MerchantScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const scrollY = useSharedValue(0);
  const isCloseToBottom = useSharedValue(false);
  const dispatch = useDispatch();

  // Merchant is loading in MerchantRoot
  const { merchantId } = useMerchant();
  const merchant = useSelector((state) => selectMerchantById(state, merchantId));

  const addToCartRef = React.useRef<AddToCartType>(null);
  const headerHeight = MERCHANT_HEADER_HEIGHT + insets.top;

  const handleProductPress = (product: ProductType) => {
    dispatch(setStagedProduct(product));
    addToCartRef.current?.present();
  };

  const handleAddToBasketDismiss = () => {
    dispatch(resetStagedProduct());
  };

  const handleFavouriteToggle = () => {
    if (merchant) {
      dispatch(
        setFavourite({
          merchantId,
          isFavourite: !merchant.isFavourite,
        }),
      );
    }
  };

  /* Handlers */
  const handleScroll = useAnimatedScrollHandler(
    ({ layoutMeasurement, contentOffset, contentSize }) => {
      scrollY.value = contentOffset.y;

      isCloseToBottom.value =
        layoutMeasurement.height + contentOffset.y >= contentSize.height - 500;
    },
  );

  const handleSearchBegin = () => {
    navigation.navigate('MerchantSearch', {});
  };

  if (!merchant) {
    return <LoadingScreen />;
  }

  return (
    <AddToCartWidget.Provider>
      <View style={{ flex: 1 }}>
        <CoverImage
          image={getImageUrl(merchant.coverThumbnail, '480x280')}
          scrollY={scrollY}
          height={headerHeight}
        />

        <Animated.ScrollView
          onScroll={handleScroll}
          scrollEventThrottle={8}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingTop: SEARCH_PLACEHOLDER_HEIGHT + headerHeight,
            paddingBottom: BASKET_WIDGET_HEIGHT + insets.bottom + 24,
          }}
        >
          <MerchantHome
            isCloseToBottom={isCloseToBottom}
            merchant={merchant}
            onProductPress={handleProductPress}
          />
        </Animated.ScrollView>

        <MerchantHeader
          onFavouriteToggle={handleFavouriteToggle}
          {...{ merchant, scrollY, insets }}
        />
        <MerchantNavigation scrollY={scrollY} insets={insets} onSearchBegin={handleSearchBegin} />
        <BasketWidget />
      </View>
      <AddToCartWidget.Modal ref={addToCartRef} onDismiss={handleAddToBasketDismiss} />
    </AddToCartWidget.Provider>
  );
}
