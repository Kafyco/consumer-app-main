import * as React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import * as WebBrowser from 'expo-web-browser';

import useDispatch from 'hooks/useDispatch';
import { signOut } from 'reducers/app';

import ScreenHeader from 'components/ScreenHeader';
import Container from 'components/Container';
import Menu from 'components/Menu';
import Text from 'components/Text';

type Props = StackScreenProps<MainNavigationParamList, 'AccountHome'>;

export default function AccountScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();

  const openUrl = async (url: string) => {
    await WebBrowser.openBrowserAsync(url);
  };

  const myMenu = [
    {
      title: t('my-orders'),
      route: 'Orders',
    },
    {
      title: t('my-suppliers'),
      route: 'MyMerchants',
    },
  ];
  const accountMenu = [
    {
      title: t('account-details'),
      route: 'AccountDetails',
    },
    // TODO: activate with new payment gateway
    // {
    //   title: t('payment-methods'),
    //   route: 'PaymentMethods',
    // },
    {
      title: t('manage-addresses'),
      route: 'Addresses',
    },
    {
      title: t('change-password'),
      route: 'PasswordChange',
    },
  ];
  const linksMenu = [
    {
      title: t('about'),
      action: () => {
        openUrl('https://kafy.co/about');
      },
    },
    {
      title: t('log-out'),
      action: () => {
        dispatch(signOut());
      },
    },
  ];

  return (
    <View style={styles.container}>
      <ScreenHeader headerTitle={t('account')} />
      <ScrollView>
        <Container>
          <View style={styles.menuWrap}>
            <Menu items={myMenu} />
          </View>
          <View style={styles.menuWrap}>
            <Menu items={accountMenu} />
          </View>
          <View style={styles.menuWrap}>
            <Menu items={linksMenu} />
          </View>
          <View style={styles.terms}>
            <Text size={12} color="secondary">
              <Text
                size={12}
                color="secondary"
                onPress={() => {
                  openUrl('https://kafy.co/terms-and-conditions');
                }}
              >
                {t('terms-and-conditions')}
              </Text>
              &nbsp;&nbsp;|&nbsp;&nbsp;
              <Text
                size={12}
                color="secondary"
                onPress={() => {
                  openUrl('https://kafy.co/privacy-policy');
                }}
              >
                {t('privacy-policy')}
              </Text>
            </Text>
          </View>
        </Container>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  menuWrap: {
    marginBottom: 16,
  },
  terms: {
    flexDirection: 'row',
    paddingVertical: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
