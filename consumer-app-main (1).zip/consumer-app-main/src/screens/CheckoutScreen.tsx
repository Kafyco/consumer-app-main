import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { View } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';
import { unwrapResult } from '@reduxjs/toolkit';
import * as Sentry from 'sentry-expo';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { MerchantRootParamList } from 'navigation/MerchantRoot';

import { CheckoutPayment, Basket } from 'api/models';
import { selectBasketInfo, selectBasketFetchStatus, fetchMerchantBasket } from 'reducers/basket';
import { fetchAddressById, selectAddressById } from 'reducers/addresses';
import { fetchPaymentMethods, selectAllPaymentMethods } from 'reducers/paymentMethods';
import { setFavourite } from 'reducers/merchants';
import {
  setPaymentMethod,
  setHasOrders,
  selectCurrentAddress,
  selectPaymentMethod,
} from 'reducers/app';
import {
  prepareCheckout,
  checkout,
  setSelectedPaymentMethod,
  clear as clearCheckout,
  selectCheckoutData,
} from 'reducers/checkout';
import { populatePaymentMethods, paymentMethodExists } from 'utils/paymentMethods';

import LoadingScreen from 'components/LoadingScreen';
import EmptyScreen from 'components/EmptyScreen';
import ScreenHeader from 'components/ScreenHeader';
import BottomButton from 'components/BottomButton';
import CheckoutReview from 'components/CheckoutReview';
import { useMerchant } from 'utils/merchantContext';

type Props = StackScreenProps<MerchantRootParamList, 'MerchantCheckout'>;

export default function CheckoutScreen({ navigation }: Props) {
  const { merchantId, merchant } = useMerchant();
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();

  // Selectors
  const basket = useSelector(selectBasketInfo);
  const basketStatus = useSelector(selectBasketFetchStatus);
  const defaultPaymentMethod = useSelector(selectPaymentMethod);
  const usersPaymentMethods = useSelector(selectAllPaymentMethods);
  const currentAddress = useSelector(selectCurrentAddress);
  const address = useSelector(
    (state) => currentAddress && selectAddressById(state, currentAddress.id),
  );
  const {
    status: checkoutStatus,
    shippingMethod,
    paymentMethods,
    selectedPaymentMethod,
  } = useSelector(selectCheckoutData);

  const groupedPaymentMethods = React.useMemo(() => {
    if (paymentMethods && usersPaymentMethods) {
      return populatePaymentMethods(paymentMethods, usersPaymentMethods);
    }
  }, [usersPaymentMethods, paymentMethods]);

  //
  const [errorMessage, setErrorMessage] = React.useState<string>();
  const [isSubmitting, setIsSubmitting] = React.useState<boolean>(false);

  // Flags
  const isLoading = [
    basketStatus !== 'fulfilled',
    !['ready', 'error'].includes(checkoutStatus),
    !basket,
    !address,
  ].some(Boolean);

  const minOrderMet = basket && basket.totalInclTax >= merchant?.deliverySettings.minOrderAmount;
  const canOrder = [
    basket,
    currentAddress,
    shippingMethod,
    selectedPaymentMethod,
    minOrderMet,
  ].every(Boolean);

  // Handlers

  const onDismissSnackBar = () => {
    setErrorMessage(undefined);
  };

  const onSubmit = () => {
    if (isSubmitting) {
      return;
    }

    if (!canOrder) {
      const sentryError = new Error(
        JSON.stringify({
          basket: Boolean(basket),
          currentAddress: Boolean(currentAddress),
          shippingMethod: Boolean(shippingMethod),
          selectedPaymentMethod: Boolean(selectedPaymentMethod),
          minOrderMet: Boolean(minOrderMet),
        }),
      );
      sentryError.name = '[CHECKOUT][CANORDER]';
      Sentry.Native.captureException(sentryError);

      setErrorMessage(`😱 ${t('error.checkout')}`);
    }

    setIsSubmitting(true);

    dispatch(
      checkout({
        merchantId,
        basketId: basket?.id as number,
        userAddressId: currentAddress?.id as number,
        // Payment is guaranteed by `canOrder`
        payment: selectedPaymentMethod as CheckoutPayment,
        shippingMethodCode: shippingMethod?.code,
      }),
    )
      .then(unwrapResult)
      .then((order) => {
        // Mark merchant as favourite.
        dispatch(setFavourite({ merchantId, isFavourite: true }));
        // Save latest used payment method.
        dispatch(setPaymentMethod(selectedPaymentMethod as CheckoutPayment));
        // Remember that user has orders.
        dispatch(setHasOrders(true));

        navigation.navigate('CheckoutOrderConfirmed', { orderNumber: order.number });
      })
      .catch((err) => {
        const sentryError = new Error(JSON.stringify(err));
        sentryError.name = '[CHECKOUT][FAILED]';
        Sentry.Native.captureException(sentryError);

        console.warn(err);
        setErrorMessage(`😱 ${t('error.checkout')}`);
      })
      .finally(() => {
        setIsSubmitting(false);
      });
  };

  const onAddNew = (method: string) => {
    navigation.navigate('MerchantCheckoutAddCard');
  };

  // Effects

  React.useEffect(() => {
    if (!basket) {
      if (basketStatus === 'idle') {
        // Basket must be fetched within MerchantNavigator, so this case shouldn't happen.
        dispatch(fetchMerchantBasket(merchantId));
      }

      if (basketStatus === 'fulfilled') {
        // Again, this case never should happen.
        console.warn(
          `No information about the basket of the merchant with id=${merchantId} on checkout page. Sent back to merchants home page.`,
        );
        navigation.navigate('MerchantHome');
      }
    }
  }, [basket]);

  // Fetch all required information.
  React.useEffect(() => {
    if (currentAddress) {
      dispatch(fetchPaymentMethods());
      dispatch(prepareCheckout({ merchantId, addressId: currentAddress.id }));
    }
  }, [merchantId, currentAddress]);

  // Receive full information about delivery address if we still don't have it.
  React.useEffect(() => {
    if (!address && currentAddress) {
      dispatch(fetchAddressById(currentAddress.id));
    }
  }, [currentAddress, address]);

  // Pre-select payment method.
  React.useEffect(() => {
    if (!isLoading && !selectedPaymentMethod && groupedPaymentMethods) {
      if (
        defaultPaymentMethod &&
        paymentMethodExists(groupedPaymentMethods, defaultPaymentMethod)
      ) {
        dispatch(setSelectedPaymentMethod(defaultPaymentMethod));
      } else if (usersPaymentMethods?.length) {
        const { sourceTypeCode, id } = usersPaymentMethods[0];
        dispatch(
          setSelectedPaymentMethod({
            method: sourceTypeCode,
            cardId: id,
          }),
        );
      }
    }
  }, [isLoading, defaultPaymentMethod]);

  React.useEffect(
    () => () => {
      dispatch(clearCheckout());
    },
    [],
  );

  const renderContent = () => {
    if (isLoading) {
      return <LoadingScreen />;
    }

    if (!shippingMethod) {
      return (
        <EmptyScreen
          image={require('assets/images/boy-waiting-with-cat.png')}
          text={t('checkout-app.error.cant-deliver')}
        />
      );
    }

    return (
      <CheckoutReview
        // Basket is guaranteed by `!isLoading`
        basket={basket as Basket}
        shippingMethod={shippingMethod}
        paymentMethods={groupedPaymentMethods}
        selectedPaymentMethod={selectedPaymentMethod}
        onPaymentMethodChange={(method, cardId) => {
          dispatch(setSelectedPaymentMethod({ method, cardId }));
        }}
        onAddNewPaymentMethod={onAddNew}
        address={address}
      />
    );
  };

  return (
    <View style={{ flex: 1 }}>
      <ScreenHeader headerTitle={t('review-order')} headerBackTitle={t('back-to-cart')} />
      {renderContent()}
      <BottomButton
        icon="lock"
        label={t('place-order')}
        disabled={!canOrder}
        loading={isSubmitting}
        onPress={onSubmit}
        positionStatic
      />
      <Snackbar
        visible={!!errorMessage}
        onDismiss={onDismissSnackBar}
        action={{
          label: t('ok'),
          onPress: onDismissSnackBar,
        }}
        style={{ marginBottom: insets.bottom }}
      >
        {errorMessage}
      </Snackbar>
    </View>
  );
}
