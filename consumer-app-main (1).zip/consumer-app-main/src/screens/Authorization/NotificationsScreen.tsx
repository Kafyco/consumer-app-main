import * as React from 'react';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { selectNotificationsStatus, setNotificationsStatus } from 'reducers/app';
import { registerExpoPushToken } from 'utils/expoPushToken';

import EmptyScreen from 'components/EmptyScreen';

type Props = StackScreenProps<MainNavigationParamList, 'Notifications'>;

export default function NotificationsScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const notificationsStatus = useSelector(selectNotificationsStatus);

  const moveNext = () => {
    navigation.navigate('Registration');
  };

  const promtPushNotificationsPermission = async () => {
    if (Device.isDevice) {
      const { status } = await Notifications.requestPermissionsAsync();

      // Update status in the app state. It will trigger effect below and register user for notificaitons.
      dispatch(setNotificationsStatus(status));
    } else {
      console.warn('Must use physical device for Push Notifications');
      moveNext();
    }
  };

  React.useEffect(() => {
    if (notificationsStatus) {
      // Permision resolved, assign token to the current user and move to the next screen.
      if (notificationsStatus === 'granted') {
        registerExpoPushToken();
      }
      moveNext();
    }
  }, [notificationsStatus]);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <EmptyScreen
        image={require('assets/images/Larry__Notification.png')}
        title={t('onboarding.notifications-title')}
        text={t('onboarding.notifications-description')}
        actionText={t('onboarding.notifications-btn')}
        onActionPress={promtPushNotificationsPermission}
      />
    </SafeAreaView>
  );
}
