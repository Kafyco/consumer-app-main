import * as React from 'react';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';

import useDispatch from 'hooks/useDispatch';
import { setReturnTo } from 'reducers/addresses';
import EmptyScreen from 'components/EmptyScreen';

type Props = StackScreenProps<MainNavigationParamList, 'OnboardingAddress'>;

export default function AddressScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();

  const handleAddNew = () => {
    dispatch(setReturnTo({ name: 'OnboardingAddress' }));
    navigation.navigate('AddressLocation');
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <EmptyScreen
        image={require('assets/images/Larry__Location.png')}
        title={t('onboarding.address-title')}
        text={t('onboarding.address-description')}
        actionText={t('onboarding.address-btn')}
        onActionPress={handleAddNew}
      />
    </SafeAreaView>
  );
}
