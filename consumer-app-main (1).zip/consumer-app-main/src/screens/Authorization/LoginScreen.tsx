import * as React from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TextInput, Snackbar } from 'react-native-paper';
import { unwrapResult } from '@reduxjs/toolkit';
import { Formik } from 'formik';
import * as Yup from 'yup';
import * as Sentry from 'sentry-expo';

import { LoginJson as LoginType } from 'api/models';
import { ERROR_FORM_VALIDATION } from 'api/constants';
import useDispatch from 'hooks/useDispatch';
import { signIn } from 'reducers/app';

import { Text, Title } from 'components/Text';
import Field from 'components/Field';
import Button from 'components/Button';
import Sheet from 'components/Sheet';

type Props = StackScreenProps<MainNavigationParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const [globalError, setGlobalError] = React.useState<string>();
  const [formError, setFormError] = React.useState(false);
  const [secureTextEntry, setSecureTextEntry] = React.useState(true);

  const initialValues = { login: undefined, password: undefined };
  const validationSchema = Yup.object().shape({
    login: Yup.string().email(t('validation.email')).required(t('validation.required')),
    password: Yup.string().required(t('validation.required')),
  });

  const onSubmit = async (values: any, actions: any) => {
    try {
      const validationResult = await actions.validateForm(values);
      const isValid = !Object.keys(validationResult).length;

      if (isValid) {
        const dispatchAction = await dispatch(signIn(values));
        await unwrapResult(dispatchAction);
      } else {
        actions.setErrors(validationResult);
      }
      // do something
    } catch (err: any) {
      if (err?.code === ERROR_FORM_VALIDATION) {
        setFormError(true);
      } else {
        Sentry.Native.captureException(err);
        setGlobalError(t('auth.unknown-error-login'));
      }
    }
  };

  return (
    <SafeAreaView style={styles.flex}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={styles.main}>
            <ScrollView
              style={styles.scrollView}
              contentContainerStyle={styles.container}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.wrapper}>
                <View style={styles.title}>
                  <Title>{t('auth.sign-in-title')} 👋</Title>
                </View>
                <Formik<LoginType>
                  initialValues={initialValues}
                  validationSchema={validationSchema}
                  validateOnChange={true}
                  validateOnMount={true}
                  onSubmit={onSubmit}
                >
                  {({ handleSubmit, isSubmitting }) => (
                    <>
                      <Sheet>
                        {formError && (
                          <Text color="danger" style={styles.error}>
                            {t('auth.sign-in-error')}
                          </Text>
                        )}
                        <Field
                          name="login"
                          label={t('auth.login')}
                          keyboardType="email-address"
                          autoCapitalize="none"
                          autoCorrect={false}
                          autoCompleteType="email"
                          textContentType="emailAddress"
                        />
                        <Field
                          name="password"
                          label={t('auth.password')}
                          secureTextEntry={secureTextEntry}
                          autoCapitalize="none"
                          autoCorrect={false}
                          autoCompleteType="password"
                          textContentType="password"
                          rightIcon={
                            <TextInput.Icon
                              name={secureTextEntry ? 'eye' : 'eye-off'}
                              onPress={() => {
                                setSecureTextEntry(!secureTextEntry);
                              }}
                            />
                          }
                        />
                        <Button
                          mode="contained"
                          loading={isSubmitting}
                          onPress={isSubmitting ? undefined : handleSubmit}
                        >
                          {t('auth.sign-in-button')}
                        </Button>
                      </Sheet>
                      <View style={styles.createButton}>
                        <Text size={14} align="center">
                          {t('auth.promote-registration')}
                        </Text>
                        <Button onPress={() => navigation.navigate('Registration')}>
                          {t('auth.request-account')}
                        </Button>
                      </View>
                    </>
                  )}
                </Formik>
                <View />
              </View>
            </ScrollView>
          </View>
        </TouchableWithoutFeedback>
        <Snackbar
          visible={!!globalError}
          onDismiss={() => setGlobalError(undefined)}
          action={{
            label: t('ok'),
            onPress: () => setGlobalError(undefined),
          }}
        >
          {globalError}
        </Snackbar>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  main: {
    flex: 1,
    justifyContent: 'center',
  },
  wrapper: {
    width: '100%',
    maxWidth: 320,
  },
  scrollView: {
    flexGrow: 0,
  },
  container: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 10,
  },
  title: {
    marginBottom: 32,
  },
  createButton: {
    marginTop: 32,
    marginBottom: 48,
  },
  error: {
    marginBottom: 16,
  },
});
