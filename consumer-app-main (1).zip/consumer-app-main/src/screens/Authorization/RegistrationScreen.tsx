import * as React from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  TouchableWithoutFeedback,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';
import { unwrapResult } from '@reduxjs/toolkit';
import LottieView from 'lottie-react-native';
import { Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import * as Sentry from 'sentry-expo';
import * as Analytics from 'utils/analytics';
import { CountryCode } from 'libphonenumber-js';

import { validatePhoneNumber, getFullNumber } from 'utils/phoneNumber';
import { CreateLeadJson as CreateLeadType } from 'api/models';
import { ERROR_FORM_VALIDATION } from 'api/constants';
import useDispatch from 'hooks/useDispatch';
import { register } from 'reducers/app';

import { Text, Title } from 'components/Text';
import Sheet from 'components/Sheet';
import Field from 'components/Field';
import Button from 'components/Button';
import CountryPhoneCodePicker, { CountryModalProvider } from 'components/CountryPhoneCodePicker';

type Props = StackScreenProps<MainNavigationParamList, 'Registration'>;

export default function RegistrationScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const [globalError, setGlobalError] = React.useState<string>();
  const [complete, setComplete] = React.useState<boolean>(false);
  const [countryCode, setCountryCode] = React.useState<CountryCode>('QA');

  const initialValues = {
    firstName: '',
    lastName: '',
    company: '',
    phone: '',
    email: '',
    password1: '',
    password2: '',
  };

  const validationSchema = Yup.object().shape({
    phone: Yup.string()
      .test('is-phone-number', t('validation.phone-format'), (value) =>
        validatePhoneNumber(value, countryCode),
      )
      .required(t('validation.required')),
    company: Yup.string().min(2).required(t('validation.required')),
    firstName: Yup.string().min(2).required(t('validation.required')),
    lastName: Yup.string().min(2),
    email: Yup.string().email().required(t('validation.required')),
    password1: Yup.string()
      .min(9, t('validation.min', { field: t('auth.password'), count: 9 }))
      .required(t('validation.required')),
    password2: Yup.string()
      .min(9, t('validation.min', { field: t('auth.confirm-password'), count: 9 }))
      .oneOf([Yup.ref('password1'), null], t('validation.passwords-match'))
      .required(t('validation.required')),
  });

  const prepareValues = (values: any) => {
    const prepared = Object.assign({}, values);

    if (prepared.phone) {
      prepared.phone = getFullNumber(prepared.phone, countryCode);
    }

    return prepared as CreateLeadType;
  };

  const onSubmit = async (values: any, actions: any) => {
    try {
      const validationResult = await actions.validateForm(values);
      const isValid = !Object.keys(validationResult).length;

      if (isValid) {
        Analytics.logEvent('REGISTRATION_REQUESTS');

        const preparedData = prepareValues(values);
        const dispatchAction = await dispatch(register(preparedData));
        await unwrapResult(dispatchAction);

        setComplete(true);

        Analytics.logEvent('REGISTRATION_REQUESTS_SUCCESS');
      } else {
        actions.setErrors(validationResult);
      }
      // do something
    } catch (err: any) {
      if (err?.code === ERROR_FORM_VALIDATION) {
        actions.setErrors(err.data);
      } else {
        Sentry.Native.captureException(err);
        setGlobalError(t('auth.unknown-error-login'));
      }
    }
  };

  const renderComplete = () => (
    <Sheet>
      <View style={styles.complete}>
        <LottieView
          source={require('assets/lottie/registration-success.json')}
          autoPlay
          loop={false}
          style={styles.animation}
        />
      </View>
      <View style={styles.completeText}>
        <Title level={2} align="center">
          {t('auth.request-success-title')}
        </Title>
        <Text align="center" style={{ marginBottom: 24 }}>
          {t('auth.request-success-text')}
        </Text>

        <Text color="secondary">{t('auth.have-confirmed')}</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text color="primary" weight="bold">
            {t('auth.login-button')}
          </Text>
        </TouchableOpacity>
      </View>
    </Sheet>
  );

  const renderForm = ({ isSubmitting, handleSubmit }: FormikProps<CreateLeadType>) => (
    <Sheet style={styles.wrapper}>
      <Text weight="bold" style={styles.subheader}>
        {t('auth.new-account-details')}
      </Text>
      <View style={styles.phoneRow}>
        <View style={styles.phonePrefix}>
          <CountryPhoneCodePicker
            defaultValue={countryCode}
            onSelect={(country: any) => {
              setCountryCode(country.cca2);
            }}
          />
        </View>
        <View style={styles.phoneField}>
          <Field name="phone" label={t('phone-number')} keyboardType="phone-pad" maxLength={10} />
        </View>
      </View>
      <Field name="company" label={t('company')} autoCorrect={false} />
      <Field
        name="firstName"
        label={t('firstName')}
        autoCorrect={false}
        textContentType="givenName"
      />
      <Field
        name="lastName"
        label={t('lastName')}
        autoCorrect={false}
        textContentType="familyName"
      />

      <Text weight="bold" style={styles.subheader}>
        {t('auth.create-an-account')}
      </Text>
      <Field name="email" label={t('email')} autoCorrect={false} />
      <Field
        name="password1"
        label={t('auth.password')}
        autoCapitalize="none"
        autoCorrect={false}
        autoCompleteType="password"
        textContentType="password"
        secureTextEntry
      />
      <Field
        name="password2"
        label={t('auth.confirm-password')}
        autoCapitalize="none"
        autoCorrect={false}
        autoCompleteType="password"
        textContentType="password"
        secureTextEntry
      />
      <Button
        mode="contained"
        loading={isSubmitting}
        onPress={isSubmitting ? undefined : handleSubmit}
      >
        {t('auth.create-an-account')}
      </Button>
    </Sheet>
  );

  return (
    <SafeAreaView style={styles.flex}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            {complete ? (
              renderComplete()
            ) : (
              <CountryModalProvider>
                <View style={styles.wrapper}>
                  <View style={styles.title}>
                    <Title>{t('auth.get-started')}</Title>
                    <View style={styles.loginText}>
                      <Text>{t('auth.promote-login')} </Text>
                      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                        <Text color="primary" weight="bold">
                          {t('auth.login-button')}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
                <Formik<CreateLeadType>
                  initialValues={initialValues}
                  validationSchema={validationSchema}
                  validateOnChange={true}
                  validateOnMount={true}
                  onSubmit={onSubmit}
                >
                  {renderForm}
                </Formik>
              </CountryModalProvider>
            )}
          </TouchableWithoutFeedback>
        </ScrollView>
      </KeyboardAvoidingView>
      <Snackbar
        visible={!!globalError}
        onDismiss={() => setGlobalError(undefined)}
        action={{
          label: t('ok'),
          onPress: () => setGlobalError(undefined),
        }}
      >
        {globalError}
      </Snackbar>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  main: {
    flex: 1,
    justifyContent: 'center',
  },
  scrollView: {},
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 48,
  },
  wrapper: {
    width: '100%',
  },
  title: {
    marginBottom: 32,
  },
  loginText: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  error: {
    marginBottom: 16,
  },
  phoneRow: {
    flexDirection: 'row',
    overflow: 'hidden',
  },
  phonePrefix: {
    paddingRight: 16,
    width: 120,
  },
  phoneField: {
    flexGrow: 1,
  },
  hint: {
    marginTop: 16,
  },
  complete: {
    alignItems: 'center',
  },
  animation: {
    width: 250,
    height: 250,
  },
  completeText: {
    alignItems: 'center',
  },
  subheader: {
    marginBottom: 8,
  },
});
