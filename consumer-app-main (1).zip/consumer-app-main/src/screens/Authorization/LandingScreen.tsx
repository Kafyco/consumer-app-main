import * as React from 'react';
import { View, StyleSheet, ImageBackground } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';

import useSelector from 'hooks/useSelector';
import { selectNotificationsStatus } from 'reducers/app';
import { landingBackground } from 'constants/Resources';

import Container from 'components/Container';
import Logo from 'components/SplashLogo';
import Text from 'components/Text';
import Button from 'components/Button';

type Props = StackScreenProps<MainNavigationParamList, 'Landing'>;

export default function LandingScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const notificationsStatus = useSelector(selectNotificationsStatus);

  const handleGetStarted = () =>
    notificationsStatus
      ? navigation.navigate('Registration')
      : navigation.navigate('Notifications');

  return (
    <View style={styles.back}>
      <ImageBackground source={{ uri: landingBackground }} resizeMode="cover" style={styles.cover}>
        <SafeAreaView style={styles.safeArea}>
          <Container style={styles.container}>
            <View style={styles.header}>
              <Logo width={80} height={80} />
            </View>
            <View style={styles.footer}>
              <Text align="center" color="white" size={24} style={styles.intro}>
                {t('auth.intro')}
              </Text>
              <Button mode="contained" color="white" onPress={handleGetStarted}>
                {t('auth.get-started')}
              </Button>
            </View>
          </Container>
        </SafeAreaView>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  cover: {
    flex: 1,
  },
  back: {
    flex: 1,
    backgroundColor: 'black',
  },
  safeArea: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.1)',
  },
  container: {
    justifyContent: 'space-between',
  },
  header: {
    paddingVertical: 32,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  intro: {
    paddingBottom: 32,
  },
  footer: {
    paddingBottom: 32,
  },
});
