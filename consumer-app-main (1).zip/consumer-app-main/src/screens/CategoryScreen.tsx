import React from 'react';
import { SectionList, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StackScreenProps } from '@react-navigation/stack';
import { useAnimatedScrollHandler, useSharedValue } from 'react-native-reanimated';
import { useTranslation } from 'react-i18next';

import { MerchantRootParamList } from 'navigation/MerchantRoot';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import { Product as ProductType } from 'api/models';

import {
  selectCategoryById,
  selectDecedentCategories,
  selectCategoriesCurrentMerchant,
  selectCategoriesLoading,
  fetchMerchantCategories,
} from 'reducers/categories';

import {
  selectAllProducts,
  selectProductsLoading,
  selectHasMoreProducts,
  fetchProducts,
  fetchMoreProducts,
} from 'reducers/products';
import { selectBasketFetchStatus, setStagedProduct, resetStagedProduct } from 'reducers/basket';
import { useMerchant } from 'utils/merchantContext';

import LoadingScreen from 'components/LoadingScreen';
import ErrorScreen from 'components/ErrorScreen';
import CategoryHeader, { CATEGORY_HEADER_HEIGHT } from 'components/CategoryHeader';
import { ProductsTitledList } from 'components/Products';
import BasketWidget, { BASKET_WIDGET_HEIGHT } from 'components/BasketWidget';
import AddToCartWidget, { ModalType as AddToCartType } from 'components/AddToCartWidget';

const PRODUCTS_PER_PAGE = 20;

type Props = StackScreenProps<MerchantRootParamList, 'MerchantCategory'>;

export default function CategoryScreen({ route, navigation }: Props) {
  const { categoryId, subCategoryId } = route.params;
  const { merchantId } = useMerchant();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const [t] = useTranslation();

  // Get categories from the store
  const category = useSelector((state) => selectCategoryById(state, categoryId));
  const isCategoriesLoading = useSelector(selectCategoriesLoading);
  const categoriesMerchantId = useSelector(selectCategoriesCurrentMerchant);
  const subCategories = useSelector((state) => selectDecedentCategories(state, categoryId));
  const currentCategory = useSelector((state) =>
    subCategoryId ? selectCategoryById(state, subCategoryId) : undefined,
  );

  // Get products from the store
  const products = useSelector(selectAllProducts);
  const isProductsLoading = useSelector(selectProductsLoading);
  const hasMoreProducts = useSelector(selectHasMoreProducts);

  // Basket
  const basketFetchStatus = useSelector(selectBasketFetchStatus);

  // Animation & Scroll Controll
  const scrollRef = React.useRef<SectionList>(null);
  const scrollY = useSharedValue(0);
  const handleScroll = useAnimatedScrollHandler(({ contentOffset: { y } }) => {
    scrollY.value = y;
  });

  //
  const addToCartRef = React.useRef<AddToCartType>(null);

  const handleTabPress = ({ id }: any) => {
    navigation.navigate('MerchantCategory', {
      categoryId,
      subCategoryId: id,
    });
  };

  const handleLoadMore = () => {
    if (hasMoreProducts && !isProductsLoading) {
      dispatch(fetchMoreProducts(PRODUCTS_PER_PAGE));
    }
  };

  const handleProductPress = (product: ProductType) => {
    dispatch(setStagedProduct(product));
    addToCartRef.current?.present();
  };

  const handleAddToBasketDismiss = () => {
    dispatch(resetStagedProduct());
  };

  const handleSearchBegin = () => {
    navigation.navigate('MerchantSearch', {});
  };

  // Load correct categories in case navigated to different marchant.
  React.useEffect(() => {
    if (String(categoriesMerchantId) !== String(merchantId)) {
      dispatch(fetchMerchantCategories(merchantId));
    }
  }, [merchantId]);

  // Load initial products for current category
  React.useEffect(() => {
    dispatch(
      fetchProducts({
        merchantId,
        categoryId: subCategoryId || categoryId,
        count: PRODUCTS_PER_PAGE,
      }),
    );
  }, [merchantId, categoryId, subCategoryId]);

  if (isCategoriesLoading || basketFetchStatus !== 'fulfilled') {
    return <LoadingScreen />;
  }

  if (!category) {
    return <ErrorScreen />;
  }

  return (
    <AddToCartWidget.Provider>
      <View style={{ flex: 1 }}>
        <ProductsTitledList
          ref={scrollRef}
          title={currentCategory?.name || t('all-products')}
          items={products}
          isLoading={isProductsLoading}
          onScroll={handleScroll}
          onLoadMore={handleLoadMore}
          onProductPress={handleProductPress}
          style={{
            paddingTop: CATEGORY_HEADER_HEIGHT + insets.top,
            paddingBottom: BASKET_WIDGET_HEIGHT + insets.bottom + 24,
          }}
        />
        <CategoryHeader
          scrollY={scrollY}
          category={category}
          subCategories={subCategories}
          currentCategoryId={subCategoryId}
          onTabPress={handleTabPress}
          onSearchBegin={handleSearchBegin}
        />
        <BasketWidget />
      </View>
      <AddToCartWidget.Modal ref={addToCartRef} onDismiss={handleAddToBasketDismiss} />
    </AddToCartWidget.Provider>
  );
}
