import * as React from 'react';
import { View, StyleSheet, ScrollView, RefreshControl, FlatList } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActivityIndicator } from 'react-native-paper';

import Layout from 'constants/Layout';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import {
  fetchMerchants,
  selectFavouriteMerchants,
  selectMerchantsStatus,
} from 'reducers/merchants';
import { selectCurrentAddress } from 'reducers/app';

import ScreenHeader from 'components/ScreenHeader';
import LoadingScreen from 'components/LoadingScreen';
import MerchantsEmpty from 'components/MerchantsEmpty';
import MerchantCard from 'components/MerchantCard';

type Props = StackScreenProps<MainNavigationParamList, 'Addresses'>;

export default function MyMerchantsScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const merchants = useSelector(selectFavouriteMerchants);
  const currentAddress = useSelector(selectCurrentAddress);
  const merchantState = useSelector(selectMerchantsStatus);
  const [refreshing, setRefreshing] = React.useState(false);

  const handleRefresh = () => {
    setRefreshing(true);
    dispatch(fetchMerchants({ address: currentAddress?.id || '' })).finally(() => {
      setRefreshing(false);
    });
  };

  const handleItemPress = (merchantId: string) => {
    navigation.navigate('MerchantRoot', {
      merchantId,
    });
  };

  const handleEmptyListPress = () => {
    navigation.navigate('Home', {});
  };

  React.useEffect(() => {
    if (!merchants.length) {
      dispatch(fetchMerchants({ address: currentAddress?.id || '' }));
    }
  }, []);

  return (
    <View style={styles.container}>
      <ScreenHeader headerTitle={t('my-suppliers')} />
      {merchantState !== 'fulfilled' && !merchants.length ? (
        <LoadingScreen />
      ) : (
        <FlatList
          data={merchants}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <MerchantCard merchant={item} onPress={() => handleItemPress(item.id)} />
          )}
          ListFooterComponent={() => (merchantState !== 'fulfilled' ? <ActivityIndicator /> : null)}
          ListEmptyComponent={<MerchantsEmpty onButtonPress={handleEmptyListPress} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom }]}
          style={styles.container}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Layout.screenPadding,
    flexGrow: 1,
  },
});
