import * as React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import * as Application from 'expo-application';
import * as Updates from 'expo-updates';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { selectCurrentUser, signOut } from 'reducers/app';

import ScreenHeader from 'components/ScreenHeader';
import Container from 'components/Container';
import Menu from 'components/Menu';
import Sheet from 'components/Sheet';
import { Text, Title } from 'components/Text';
import Button from 'components/Button';
import DeleteAccount from 'components/DeleteAccount';
import Colors from 'constants/Colors';

type Props = StackScreenProps<MainNavigationParamList, 'AccountDetails'>;

export default function AccountDetailsScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const currentUser = useSelector(selectCurrentUser);
  const [isDeleting, setIsDeleting] = React.useState<boolean>(false);

  return (
    <View style={styles.container}>
      <ScreenHeader headerTitle={t('account-details')} />
      <ScrollView>
        <Container>
          <Sheet>
            <View style={styles.item}>
              <Title level={3}>{t('company')}</Title>
              <Text>{currentUser?.company}</Text>
            </View>
            <View style={styles.item}>
              <Title level={3}>{t('email')}</Title>
              <Text>{currentUser?.email}</Text>
            </View>
            {!!currentUser?.phone && (
              <View style={styles.item}>
                <Title level={3}>{t('phone-number')}</Title>
                <Text>{currentUser?.phone}</Text>
              </View>
            )}
          </Sheet>

          <Text color="secondary" size={12} align="center" style={styles.version}>
            {Updates.updateId}
          </Text>
          <Text color="secondary" size={12} align="center">
            v{Application.nativeApplicationVersion}
          </Text>

          <View style={styles.logoutBlock}>
            <Text style={styles.logoutTitle}>{t('not-you')}</Text>
            <Menu
              items={[
                {
                  title: t('log-out'),
                  action: () => {
                    dispatch(signOut());
                  },
                },
              ]}
            />
            <Button
              mode="text"
              color={Colors.danger}
              style={{ paddingTop: 16 }}
              onPress={() => setIsDeleting(true)}
            >
              {t('delete-account')}
            </Button>
          </View>
        </Container>
      </ScrollView>
      <DeleteAccount visible={isDeleting} onCancel={() => setIsDeleting(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  item: {
    marginBottom: 16,
  },
  logoutBlock: {
    marginTop: 16,
  },
  logoutTitle: {
    marginBottom: 8,
  },
  version: {
    marginTop: 8,
  },
});
