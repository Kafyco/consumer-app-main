import React from 'react';
import { ScrollView, View, BackHandler } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import {
  fetchConfirmedOrder,
  selectConfirmedOrder,
  clear as clearCheckout,
} from 'reducers/checkout';

import Container from 'components/Container';
import OrderConfirmed from 'components/OrderConfirmed';
import BottomButton from 'components/BottomButton';
import LoadingScreen from 'components/LoadingScreen';

type Props = StackScreenProps<MainNavigationParamList, 'CheckoutOrderConfirmed'>;

export default function CheckoutOrderConfirmatedScreen({ route, navigation }: Props) {
  const { orderNumber } = route.params;
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const order = useSelector((state) => selectConfirmedOrder(state, orderNumber));

  const handleButtonPress = () => {
    navigation.navigate('Home', {});
  };

  React.useEffect(() => {
    if (!order) {
      dispatch(fetchConfirmedOrder(orderNumber));
    }
  }, [orderNumber]);

  React.useEffect(
    () => () => {
      dispatch(clearCheckout());
    },
    [],
  );

  useFocusEffect(
    React.useCallback(() => {
      const onBackPress = () => true;
      BackHandler.addEventListener('hardwareBackPress', onBackPress);

      return () => BackHandler.removeEventListener('hardwareBackPress', onBackPress);
    }, []),
  );

  return (
    <View style={{ flex: 1 }}>
      <ScrollView>
        <Container style={{ paddingTop: insets.top, paddingBottom: 16 }}>
          {order ? <OrderConfirmed order={order} /> : <LoadingScreen />}
        </Container>
      </ScrollView>
      <BottomButton label={t('continue-shopping')} onPress={handleButtonPress} positionStatic />
    </View>
  );
}
