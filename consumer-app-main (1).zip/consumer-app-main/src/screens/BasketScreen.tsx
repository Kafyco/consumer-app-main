import React from 'react';
import { View } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { Snackbar } from 'react-native-paper';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import { MerchantRootParamList } from 'navigation/MerchantRoot';
import { Product as ProductType } from 'api/models';
import { getMerchantShippingMethods } from 'api/index';

import {
  selectBasketInfo,
  selectAllBasketLines,
  setStagedProduct,
  resetStagedProduct,
  selectBasketFetchStatus,
} from 'reducers/basket';
import { selectCurrentAddress } from 'reducers/app';

import { ProductsFlatList } from 'components/Products';
import ScreenHeader, { Button as ScreenHeaderButton } from 'components/ScreenHeader';
import AddToCartWidget, { ModalType as AddToCartType } from 'components/AddToCartWidget';
import BasketTotal from 'components/BasketTotal';
import EmptyBasket from 'components/EmptyBasket';
import { useMerchant } from 'utils/merchantContext';

type Props = StackScreenProps<MerchantRootParamList, 'MerchantBasket'>;

export default function BasketScreen({ navigation }: Props) {
  const { merchantId } = useMerchant();
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const basket = useSelector(selectBasketInfo);
  const basketStatus = useSelector(selectBasketFetchStatus);
  const basketLines = useSelector(selectAllBasketLines);
  const currentAddress = useSelector(selectCurrentAddress);
  const [shipping, setShipping] = React.useState();
  const [errorMessage, setErrorMessage] = React.useState();
  const addToCartRef = React.useRef<AddToCartType>(null);
  const isLoading = basketStatus !== 'fulfilled';
  const products = React.useMemo(
    () =>
      basketLines?.map((line) => ({
        ...line.product,
        currency: line.priceCurrency,
        price: line.stockrecord.price,
      })),
    [basketLines],
  );

  React.useEffect(() => {
    if (currentAddress) {
      getMerchantShippingMethods({ merchantId, addressId: currentAddress.id }).then((res: any) => {
        if (res?.data?.length) {
          setShipping(res.data[0]);
        } else {
          setErrorMessage(t('error.no-shipping'));
        }
      });
    }
  }, [basket, currentAddress]);

  const handleProductPress = (product: ProductType) => {
    dispatch(setStagedProduct(product));
    addToCartRef.current?.present();
  };

  const handleAddToBasketDismiss = () => {
    dispatch(resetStagedProduct());
  };

  const handleGoToMerchant = () => {
    navigation.navigate('MerchantHome');
  };

  const onDismissSnackBar = () => {
    setErrorMessage(undefined);
  };

  return (
    <AddToCartWidget.Provider>
      <View style={{ flex: 1 }}>
        <ScreenHeader
          headerTitle={t('shopping-cart')}
          actions={<ScreenHeaderButton label={t('add-more')} onPress={handleGoToMerchant} />}
        />
        {isLoading || products?.length ? (
          <ProductsFlatList
            items={products}
            onProductPress={handleProductPress}
            isLoading={isLoading}
            containerStyle={{ paddingBottom: 32 }}
          />
        ) : (
          <EmptyBasket style={{ paddingBottom: 32 }} />
        )}

        {basket ? <BasketTotal basket={basket} shipping={shipping} /> : null}
        <AddToCartWidget.Modal ref={addToCartRef} onDismiss={handleAddToBasketDismiss} />
        <Snackbar
          visible={!!errorMessage}
          onDismiss={onDismissSnackBar}
          action={{
            label: t('ok'),
            onPress: onDismissSnackBar,
          }}
        >
          {errorMessage}
        </Snackbar>
      </View>
    </AddToCartWidget.Provider>
  );
}
