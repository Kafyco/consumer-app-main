import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { unwrapResult } from '@reduxjs/toolkit';
import { useTranslation } from 'react-i18next';
import * as Sentry from 'sentry-expo';

import useDispatch from 'hooks/useDispatch';
import useSelector from 'hooks/useSelector';
import {
  clearStagedAddress,
  selectAddressById,
  selectStagedAddress,
  selectReturnTo,
  clearReturnTo,
  stageAddress,
  updateAddress,
  createNewAddress,
} from 'reducers/addresses';

import ScreenHeader, { Button as ScreenHeaderButton } from 'components/ScreenHeader';
import AddressForm from 'components/AddressForm';

type Props = StackScreenProps<MainNavigationParamList, 'AddressForm'>;

export default function AddressFormScreen({ navigation, route }: Props) {
  const [t] = useTranslation();
  const dispatch = useDispatch();
  const { addressId } = route.params;
  const returnTo = useSelector(selectReturnTo);
  const stagedAddress = useSelector(selectStagedAddress);
  const addressData = useSelector(
    (state) => stagedAddress || (addressId ? selectAddressById(state, addressId) : undefined),
  );

  const handleCancel = () => {
    navigation.goBack();
  };

  const handleSubmit = async (values: any) => {
    try {
      const dispatchAction = await dispatch(
        addressId ? updateAddress(values) : createNewAddress(values),
      );
      const address = unwrapResult(dispatchAction);

      if (returnTo) {
        if (returnTo?.name === 'OnboardingAddress') {
          navigation.navigate('Home', {});
        } else {
          navigation.navigate({
            ...returnTo,
            params: {
              ...returnTo?.params,
              addressId: address.id,
            },
          });
        }
        dispatch(clearReturnTo());
      } else {
        navigation.navigate('Addresses');
      }
    } catch (err) {
      Sentry.Native.captureException(err);
      return Promise.reject(err);
    }
  };

  const handleEditLocation = (values: any) => {
    dispatch(stageAddress(values));
    navigation.navigate('AddressLocation');
  };

  React.useEffect(
    () => () => {
      stagedAddress && dispatch(clearStagedAddress());
    },
    [],
  );

  return (
    <View style={styles.container}>
      <ScreenHeader
        headerTitle={addressId ? t('change-address') : t('add-new-address')}
        actions={
          addressId ? <ScreenHeaderButton label={t('cancel')} onPress={handleCancel} /> : null
        }
      />
      <AddressForm
        address={addressData}
        onSubmit={handleSubmit}
        onEditLocation={handleEditLocation}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    paddingBottom: 24,
  },
  menuWrap: {
    marginBottom: 16,
  },
});
