import React from 'react';
import { ScrollView, View, StyleSheet, Platform, KeyboardAvoidingView } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { useTranslation } from 'react-i18next';
import { debounce } from 'lodash';
import * as Linking from 'expo-linking';

import { MerchantRootParamList } from 'navigation/MerchantRoot';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import { ProductsByPartner } from 'api/models';
import Layout from 'constants/Layout';

import {
  selectAllResults,
  selectResultsLoading,
  selectHasMoreResults,
  fetchSearchResults,
  fetchMoreResults,
  clearSearchResults,
} from 'reducers/globalSearch';

import ProductsByPartners from 'components/ProductsByPartners';
import ScreenHeader from 'components/ScreenHeader';
import SearchInput from 'components/SearchInput';
import EmptyScreen from 'components/EmptyScreen';
import Text from 'components/Text';
import LoadingScreen from 'components/LoadingScreen';

const RESULTS_PER_PAGE = 20;
const PRODUCT_PER_SECTION = 5;

type Props = StackScreenProps<MerchantRootParamList, 'MerchantSearch'>;

export default function CategoryScreen({ route }: Props) {
  const dispatch = useDispatch();
  const [t] = useTranslation();

  // Initial search query
  const { search: searchParam } = route.params;

  // Get products from the store
  const searchResults = useSelector(selectAllResults) as ProductsByPartner[];
  const isLoading = useSelector(selectResultsLoading);
  const hasMoreResults = useSelector(selectHasMoreResults);

  // Stores value of the input
  const [search, setSearch] = React.useState(decodeURIComponent(searchParam || ''));
  // Stores search query for current search results
  const [latestSearch, setLatestSearch] = React.useState(decodeURIComponent(searchParam || ''));

  const seactionsData = React.useMemo(
    () =>
      searchResults?.length
        ? searchResults.map(({ id, name, total, logoThumbnail, hits }) => ({
            id,
            title: name,
            total,
            logoThumbnail,
            data: hits,
          }))
        : [],
    [searchResults],
  );

  const handleLoadMore = () => {
    hasMoreResults && dispatch(fetchMoreResults({ count: RESULTS_PER_PAGE }));
  };

  const handleResultPress = (merchantId: number | string) => {
    Linking.openURL(
      Linking.createURL(`merchant/${merchantId}/search/${encodeURIComponent(latestSearch)}`),
    );
  };

  const handleSearchChange = (value: string) => {
    setSearch(value);
    if (value) {
      handleSearch(value);
    } else {
      handleSearch.cancel();
      setLatestSearch('');
      dispatch(clearSearchResults());
    }
  };

  const handleSearch = React.useCallback(
    debounce(
      (value) => {
        if (value) {
          dispatch(
            fetchSearchResults({
              search: value,
              maxResults: PRODUCT_PER_SECTION,
            }),
          );
          setLatestSearch(value);
        } else {
          dispatch(clearSearchResults());
          setLatestSearch('');
        }
      },
      780,
      { trailing: true },
    ),
    [],
  );

  React.useEffect(() => {
    return () => {
      handleSearch.cancel();
      dispatch(clearSearchResults());
    };
  }, []);

  const renderContent = () => {
    if (!latestSearch) {
      return (
        <ScrollView
          style={styles.container}
          contentContainerStyle={styles.emptyStart}
          keyboardDismissMode="on-drag"
        >
          <Text size={14} color="secondary">
            {t('start-searching')}
          </Text>
        </ScrollView>
      );
    }

    if (isLoading && !searchResults.length) {
      return <LoadingScreen />;
    }

    if (searchResults.length) {
      return (
        <ProductsByPartners
          sections={seactionsData}
          isLoading={isLoading}
          ListEmptyComponent={null}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={1}
          keyboardDismissMode="on-drag"
          keyboardShouldPersistTaps="always"
          onProductPress={(_, { id }) => handleResultPress(id)}
          onShowMore={handleResultPress}
          onMerchantPress={handleResultPress}
        />
      );
    }

    return (
      <ScrollView keyboardDismissMode="on-drag">
        <EmptyScreen
          title={t('noproducts')}
          text={t('empty-search-desct', { search: latestSearch })}
          style={styles.empty}
        />
      </ScrollView>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == 'ios' ? 'padding' : undefined}
      style={[styles.container, { position: 'relative' }]}
    >
      <View>
        <ScreenHeader headerTitle={t('search')} />
        <View style={styles.search}>
          <SearchInput
            value={search}
            onChangeText={handleSearchChange}
            placeholder={t('search-global')}
            autoFocus
          />
        </View>
      </View>
      <View style={styles.container}>{renderContent()}</View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  emptyStart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  empty: {
    paddingTop: 80,
  },
  search: {
    paddingHorizontal: Layout.screenPadding,
    paddingBottom: 8,
  },
});
