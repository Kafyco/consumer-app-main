import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import * as Analytics from 'utils/analytics';
import Layout from 'constants/Layout';
import useDispatch from 'hooks/useDispatch';
import { fetchPaymentMethods } from 'reducers/paymentMethods';

import ScreenHeader from 'components/ScreenHeader';
import StripeAttachWeb from 'components/StripeAttachWeb';

type Props = StackScreenProps<MainNavigationParamList, 'CardAttachment'>;

export default function CardAttachmentScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();

  const handleSuccess = async () => {
    Analytics.logEvent('PAYMENT_METHOD_CARD_SUCCESS');
    await dispatch(fetchPaymentMethods());
    navigation.goBack();
  };

  const handleFail = (errorCode: string) => {
    Analytics.logEvent('PAYMENT_METHOD_CARD_FAIL', { errorCode });
  };

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      <ScreenHeader headerTitle={t('attach-new-card')} />
      <StripeAttachWeb onSuccess={handleSuccess} onFail={handleFail} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    paddingHorizontal: Layout.screenPadding,
  },
});
