import * as React from 'react';
import { View, Image, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { StackScreenProps } from '@react-navigation/stack';
import { MainNavigationParamList } from 'navigation/MainNavigator';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import {
  selectPaymentMethodsStatus,
  selectAllPaymentMethods,
  fetchPaymentMethods,
  deletePaymentMethod,
} from 'reducers/paymentMethods';
import Colors from 'constants/Colors';
import Layout from 'constants/Layout';

import ScreenHeader, { Button as ScreenHeaderButton } from 'components/ScreenHeader';
import LoadingScreen from 'components/LoadingScreen';
import Sheet from 'components/Sheet';
import PaymentCard from 'components/PaymentCard';
import Text from 'components/Text';
import Button from 'components/Button';
import DialogConfirm from 'components/DialogConfirm';
import EmptyScreen from 'components/EmptyScreen';

type Props = StackScreenProps<MainNavigationParamList, 'PaymentMethods'>;

export default function AccountScreen({ navigation }: Props) {
  const [t] = useTranslation();
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const [refreshing, setRefreshing] = React.useState<boolean>(false);
  const [deleting, setDeleting] = React.useState<number | string | null>(null);
  const [deleteLoading, setDeleteLoading] = React.useState<boolean>(false);
  const paymentMethodsStatus = useSelector(selectPaymentMethodsStatus);
  const paymentMethodsList = useSelector(selectAllPaymentMethods);

  const handleAddNew = () => {
    navigation.navigate('CardAttachment');
  };

  const handleDelete = (id: number | string) => {
    setDeleting(id);
  };

  const handleConfirmDelete = async () => {
    if (deleting) {
      setDeleteLoading(true);
      await dispatch(deletePaymentMethod(deleting));
      setDeleteLoading(false);
      setDeleting(null);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await dispatch(fetchPaymentMethods());
    setRefreshing(false);
  };

  React.useEffect(() => {
    if (paymentMethodsStatus === 'idle') {
      dispatch(fetchPaymentMethods());
    }
  }, []);

  return (
    <View style={styles.container}>
      <ScreenHeader
        headerTitle={t('payment-methods')}
        actions={
          paymentMethodsList.length ? (
            <ScreenHeaderButton label={t('add-new')} onPress={handleAddNew} />
          ) : null
        }
      />
      {paymentMethodsStatus === 'fulfilled' || paymentMethodsList.length ? (
        <FlatList
          data={paymentMethodsList}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <Sheet key={item.id} style={styles.item}>
              <PaymentCard info={item} />
              <View style={styles.itemActions}>
                {paymentMethodsList.length > 0 && (
                  <Button
                    color={Colors['text-secondary']}
                    icon="trash"
                    compact
                    micro
                    uppercase
                    onPress={() => handleDelete(item.id)}
                    style={styles.action}
                  >
                    {t('delete')}
                  </Button>
                )}
              </View>
            </Sheet>
          )}
          ListEmptyComponent={
            <EmptyScreen
              image={require('assets/images/Larry__Turn_on.png')}
              text={t('empty-payment-methods')}
              actionText={t('attach-new-card')}
              onActionPress={handleAddNew}
              style={{ paddingBottom: insets.bottom }}
            />
          }
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          contentContainerStyle={[styles.content, { paddingBottom: insets.bottom }]}
          style={styles.container}
        />
      ) : (
        <LoadingScreen />
      )}

      <DialogConfirm
        loading={deleteLoading}
        visible={!!deleting}
        onCancel={() => setDeleting(null)}
        onConfirm={handleConfirmDelete}
      >
        <Text>{t('payment-method-delete-confirm')}</Text>
      </DialogConfirm>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Layout.screenPadding,
    flexGrow: 1,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingStart: 24,
    paddingEnd: 24,
    paddingTop: 16,
    paddingBottom: 16,
  },
  itemActions: {
    flexShrink: 1,
    flexDirection: 'row',
    marginEnd: -8,
  },
  action: {},
});
