export const API_ERROR_GENERAL = '__root__';
export const ERROR_FORM_VALIDATION = 'ValidationError';
export const ERROR_BAD_REQUEST = 'BadRequestError';
