import queryString from 'query-string';
import keysToCamel from 'utils/keysToCamel';
import keysToSnake from 'utils/keysToSnake';
import snakeToCamel from 'utils/snakeToCamel';
import { ERROR_FORM_VALIDATION, API_ERROR_GENERAL } from './constants';
import { getEnvironmentProp } from 'utils/environment';

const assign = Object.assign;

export const BASE_URL = getEnvironmentProp('apiBaseUrl');

export interface ApiClientOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  token?: string | false;
  contentType?: string;
  limit?: number;
  offset?: number;
  params?: any;
  logErrors?: boolean;
}

export type ApiResponseSuccessType = {
  status: number;
  statusText: string;
  headers: any;
  data: any;
};

export type ApiResponseErrorType = {
  status: number;
  statusText: string;
  headers: any;
  data: any;
};

export type ApiFormErrorType = {
  code: string;
  data: string;
  headers?: any;
};

export type ApiResponse = Promise<ApiResponseSuccessType | ApiResponseErrorType | ApiFormErrorType>;

export const ApiResponseSuccess = (data: ApiResponseSuccessType): ApiResponseSuccessType => data;

export const ApiResponseError = (data: ApiResponseErrorType): ApiResponseErrorType => data;

const ApiClient = {
  _token: '',

  setToken: (token: string) => {
    ApiClient._token = token;
  },

  clearToken: () => {
    ApiClient._token = '';
  },

  getToken: (): string => ApiClient._token,

  request: (path: string, data: any, options: ApiClientOptions = {}): ApiResponse => {
    const { method: optionsMethod, token: optionsToken, logErrors = true } = options;
    const baseUrl = BASE_URL.replace(/\/$/, '');
    const method = optionsMethod?.toUpperCase() || 'GET';
    const token = optionsToken || ApiClient.getToken();

    // Headers
    const contentType = options?.contentType || 'application/json';
    const headers: { [key: string]: string } = {
      accept: 'application/json',
      'content-type': contentType,
      authorization: token ? `Bearer ${token}` : '',
    };

    // Query Params
    const { limit, offset, params } = options;
    let queryParams = {
      limit,
      offset,
      ...keysToSnake(params),
    };

    if (method === 'GET' && data) {
      queryParams = {
        ...queryParams,
        ...data,
      };
    }
    const queryStr = queryString.stringify(keysToSnake(queryParams));
    const query = queryStr ? `?${queryStr}` : '';

    // Form data
    let formData: any;
    if (method !== 'GET' && data) {
      if (contentType === 'application/json') {
        formData = JSON.stringify(keysToSnake(data));
      } else {
        formData = queryString.stringify(keysToSnake(data));
      }
    }

    const url = `${baseUrl}${path}${query}`;

    return fetch(url, {
      method,
      headers,
      body: formData,
    })
      .then((result) => {
        const { status, statusText } = result;
        const headers = {};

        result.headers.forEach((val: string, key: string) => {
          headers[key] = val;
        });

        if (status >= 200 && status < 300) {
          return result.json().then((data) => {
            return ApiResponseSuccess({
              status,
              statusText,
              headers,
              data: keysToCamel(data),
            });
          });
        }

        return result.text().then((text) => {
          let data = text;

          try {
            const json = JSON.parse(text);
            data = json.error || json;
          } catch (err) {}

          return Promise.reject(
            ApiResponseError({
              status,
              statusText,
              headers,
              data,
            }),
          );
        });
      })
      .catch((err: ApiResponseErrorType) => {
        if (Array.isArray(err.data)) {
          const data = err.data.reduce((res, errorBit) => {
            const message = errorBit.msg;

            errorBit.loc.forEach((loc: string) => {
              res[snakeToCamel(loc)] = message;
            });

            return res;
          }, {});

          if (!Object.keys(data).includes(API_ERROR_GENERAL)) {
            return Promise.reject({
              code: ERROR_FORM_VALIDATION,
              data,
            });
          }
        }

        if (logErrors) {
          console.warn(err);
          console.warn(
            'The error above happend while making request with following params:',
            '\nURL:',
            url,
            '\nMethod:',
            method,
            '\nHeaders:',
            headers,
            '\nBody:',
            formData,
          );
        }

        return Promise.reject(err);
      });
  },

  get: (path: string, data?: any, options?: ApiClientOptions): ApiResponse =>
    ApiClient.request(path, data, assign({}, options, { method: 'GET' })),

  post: (path: string, data?: any, options?: ApiClientOptions): ApiResponse =>
    ApiClient.request(path, data, assign({}, options, { method: 'POST' })),

  put: (path: string, data?: any, options?: ApiClientOptions): ApiResponse =>
    ApiClient.request(path, data, assign({}, options, { method: 'PUT' })),

  del: (path: string, data?: any, options?: ApiClientOptions): ApiResponse =>
    ApiClient.request(path, data, assign({}, options, { method: 'DELETE' })),
};

export default ApiClient;
