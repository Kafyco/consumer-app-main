import queryString from 'query-string';
import * as Sentry from 'sentry-expo';

import { getApiKey, getRequestHeaders } from './utils';
import { AutocompletePrediction, PlaceResult } from './models';

// Somewhere in the middle of Dubai
const DEFAULT_SEARCH_LOCATION = '25.117002,55.200594';
// Radius from location in meters
const DEFAULT_SEARCH_RADIUS = 50 * 1000;
// TODO: Replace with env variable
const GOOGLE_API_KEY = getApiKey();

const FORMAT = 'json';

type CallbackType = (value: any) => any;

const abortableRequest = (url: string, callback?: CallbackType) => {
  const abortController = new AbortController();
  const { signal } = abortController;
  const abort = () => abortController.abort();
  const headers = getRequestHeaders();

  const request = fetch(url, {
    headers,
    signal,
  })
    .then((res) => res.json())
    .then((res) => callback?.(res) || res)
    .catch((err) => {
      // Ignor canceled requests
      if (err.name !== 'AbortError') {
        Sentry.Native.captureException(err);
        return Promise.reject(err);
      }
    });

  return {
    abort,
    request,
  };
};

interface IAutocomplete {
  input: string;
  sessionToken: string;
  location?: string;
  radius?: number;
  language?: string;
}

export const autocomplete = ({
  input,
  sessionToken,
  location = DEFAULT_SEARCH_LOCATION,
  radius = DEFAULT_SEARCH_RADIUS,
  language = 'en',
}: IAutocomplete) => {
  const baseUrl = 'https://maps.googleapis.com/maps/api/place/autocomplete/';
  const query = queryString.stringify(
    {
      input,
      sessiontoken: sessionToken,
      location,
      radius,
      language,
      key: GOOGLE_API_KEY,
    },
    { arrayFormat: 'comma' },
  );

  return abortableRequest(`${baseUrl}${FORMAT}?${query}`, (res) => {
    if (res.status === 'OK' && res.predictions) {
      return res.predictions as AutocompletePrediction;
    } else if (res?.status === 'ZERO_RESULTS') {
      return [];
    } else {
      const err = new Error(JSON.stringify(res));
      err.name = '[GoogleMapsAPI][place/autocomplete]';

      throw err;
    }
  });
};

// ------------

interface IPlaceDetails {
  placeId: string;
  sessionToken: string;
  language?: string;
}

export const placeDetails = ({ placeId, sessionToken, language = 'en' }: IPlaceDetails) => {
  const baseUrl = 'https://maps.googleapis.com/maps/api/place/details/';
  const fields = [
    'geometry',
    'address_component',
    'adr_address',
    'formatted_address',
    'name',
    'place_id',
    'type',
  ];
  const query = queryString.stringify(
    {
      place_id: placeId,
      sessiontoken: sessionToken,
      fields,
      language,
      key: GOOGLE_API_KEY,
    },
    { arrayFormat: 'comma' },
  );

  return abortableRequest(`${baseUrl}${FORMAT}?${query}`, (res) => {
    if (res?.status === 'OK' && res?.result) {
      return res.result as PlaceResult;
    } else {
      const err = new Error(JSON.stringify(res));
      err.name = '[GoogleMapsAPI][place/details]';
      throw err;
    }
  });
};

// ------------

interface IGeocode {
  latitude: number;
  longitude: number;
  language?: string;
}

export const geocode = ({ latitude, longitude, language = 'en' }: IGeocode) => {
  const baseUrl = 'https://maps.googleapis.com/maps/api/geocode/';
  const query = queryString.stringify(
    {
      latlng: [latitude, longitude],
      language,
      key: GOOGLE_API_KEY,
    },
    { arrayFormat: 'comma' },
  );

  return abortableRequest(`${baseUrl}${FORMAT}?${query}`, (res) => {
    if (res?.status === 'OK' && res?.results) {
      return res.results as Array<any>;
    } else if (res?.status === 'ZERO_RESULTS') {
      return [];
    } else {
      const err = new Error(JSON.stringify(res));
      err.name = '[GoogleMapsAPI][geocode]';
      throw err;
    }
  });
};

export const getGeocodePlace = (list: Array<any>, types: Array<string>) => {
  for (const type of types) {
    const location = list.find((item) => item.types.includes(type));
    if (location) {
      return location;
    }
  }
  return null;
};
