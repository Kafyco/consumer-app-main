import { Platform } from 'react-native';
import Constants from 'expo-constants';

let key: string;
export const getApiKey = (): string => {
  if (key) {
    return key;
  }

  if (Platform.OS === 'ios') {
    key = Constants?.expoConfig?.extra?.googleApiKeyIOs;
  } else {
    key = Constants?.expoConfig?.extra?.googleApiKeyAndroid;
  }

  return key;
};

type HeadersType = { [key: string]: string };

let headers: HeadersType;
export const getRequestHeaders = (): HeadersType => {
  if (headers) {
    return headers;
  }

  if (Platform.OS === 'ios') {
    headers = {
      'x-ios-bundle-identifier': 'ae.supplyme.portal',
    };
  } else {
    headers = {
      'X-Android-Package': 'ae.supplyme.portal',
      'X-Android-Cert': 'CA:FF:B6:73:6C:2E:7D:91:56:22:69:6D:4F:96:F3:92:B1:77:8D:BC',
    };
  }

  return headers;
};
