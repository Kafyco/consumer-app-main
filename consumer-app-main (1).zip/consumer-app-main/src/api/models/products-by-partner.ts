/**
 *
 * @export
 * @interface ProductsByPartner
 */
export interface ProductsByPartner {
  /**
   *
   * @type {number}
   * @memberof ProductsByPartner
   */
  id: any;
  /**
   *
   * @type {string}
   * @memberof ProductsByPartner
   */
  name: any;
  /**
   *
   * @type {{ [key, string]: Thumbnail;}}
   * @memberof ProductsByPartner
   */
  logoThumbnail: any;
  /**
   *
   * @type {number}
   * @memberof ProductsByPartner
   */
  total: any;
  /**
   *
   * @type {Array&lt;Product&gt;}
   * @memberof ProductsByPartner
   */

  hits: any;
}
