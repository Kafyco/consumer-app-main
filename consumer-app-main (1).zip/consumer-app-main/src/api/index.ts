import ApiClient, { ApiClientOptions, ApiResponse, ApiResponseError } from './ApiClient';
import { Address, CheckoutPayment, LoginJson, CreateLeadJson } from './models';
import { ERROR_FORM_VALIDATION } from './constants';

// ---- User ----

export const createLead = (data: CreateLeadJson) => {
  return ApiClient.post('/zoho/create_lead/', {
    leadSource: 'App',
    ...data,
  });
};

export const register = (data: CreateLeadJson) => {
  return ApiClient.post('/auth/register', data);
};

export const login = (data: LoginJson) => {
  return ApiClient.post('/auth/login', data, { logErrors: false }).catch((err) => {
    if (err.status === 401) {
      return Promise.reject({
        code: ERROR_FORM_VALIDATION,
      });
    }

    return Promise.reject(err);
  });
};

export const suspendAccount = () => {
  return ApiClient.post('/auth/suspend_account', {});
};

export const getUserInfo = () => {
  return ApiClient.get('/auth/user_info');
};

export const registerUserToken = (token: string) => {
  return ApiClient.post('/auth/push_token', { token });
};

export const unregisterUserToken = (token: string) => {
  return ApiClient.del('/auth/push_token', { token });
};

interface IChangePassword {
  oldPassword: string;
  newPassword1: string;
  newPassword2: string;
}
export const changePassword = (data: IChangePassword) => {
  return ApiClient.post('/auth/password_change', data);
};

// ---- Catalogue ----

interface IGetMerchants {
  address: number | string;
  isFavouriteOnly?: boolean;
}
export const getMerchants = (data?: IGetMerchants, options?: ApiClientOptions): ApiResponse => {
  return ApiClient.get(
    '/partners',
    { addressId: data?.address, favoriteOnly: data?.isFavouriteOnly },
    options,
  );
};

export const getMerchantById = (id: string | number): ApiResponse => {
  return ApiClient.get(`/partners/${id}`);
};

interface ISetMerchantFavourite {
  merchantId: number | string;
  isFavourite: boolean;
}
export const setMerchantFavourite = ({
  merchantId,
  isFavourite,
}: ISetMerchantFavourite): ApiResponse => {
  return ApiClient.put(`/partners/${merchantId}/favourite`, { isFavourite });
};

interface IGetMerchantCategories {
  merchantId: number | string;
}
export const getMerchantCategories = (
  { merchantId }: IGetMerchantCategories,
  options?: ApiClientOptions,
): ApiResponse => {
  return ApiClient.get(`/partners/${merchantId}/catalogue/categories/list`, null, options);
};

interface IGetMerchantProducts {
  merchantId: number | string;
  categoryId?: number | string;
  search?: string;
  sortBy?: 'newest' | 'popularity' | 'price-asc' | 'price-desc' | 'relevancy' | 'rating';
}
export const getMerchantProducts = (
  { merchantId, ...data }: IGetMerchantProducts,
  options?: ApiClientOptions,
): ApiResponse => {
  return ApiClient.get(`/partners/${merchantId}/catalogue/products`, data, options);
};

interface IGetProductsByPartner {
  maxResults?: number;
  merchantId?: number | string;
  categoryId?: number | string;
  search?: string;
  sortBy?:
    | 'newest'
    | 'popularity'
    | 'price_high_to_low'
    | 'price_low_to_high'
    | 'relevancy'
    | 'top_rated';
}
export const getProductsByPartner = (
  { merchantId, ...data }: IGetProductsByPartner,
  options?: ApiClientOptions,
): ApiResponse => {
  return ApiClient.get(
    `/catalogue/products_by_partner`,
    { partnerId: merchantId, ...data },
    options,
  );
};

// ---- Basket ----

interface IGetMerchantBasket {
  merchantId: number | string;
}
export const getMerchantBasket = ({ merchantId }: IGetMerchantBasket): ApiResponse => {
  return ApiClient.get(`/partners/${merchantId}/basket`);
};

interface IAddToMerchantBasket {
  merchantId: number | string;
  productId: number | string;
  quantity: number;
}
export const addToMerchantBasket = ({
  merchantId,
  productId,
  quantity,
}: IAddToMerchantBasket): ApiResponse => {
  return ApiClient.post(`/partners/${merchantId}/basket/add_product`, null, {
    params: {
      productId,
      quantity,
    },
  });
};

interface IUpdateMerchantBasketLineQty {
  merchantId: number | string;
  lineId: number | string;
  quantity: number;
}
export const updateMerchantBasketLineQty = ({
  merchantId,
  lineId,
  quantity,
}: IUpdateMerchantBasketLineQty): ApiResponse => {
  return ApiClient.put(`/partners/${merchantId}/basket/lines/${lineId}`, { quantity });
};

interface IApplyMerchantBasketCoupon {
  merchantId: number | string;
  code: string;
}
export const applyMerchantBasketCoupon = ({
  merchantId,
  code,
}: IApplyMerchantBasketCoupon): ApiResponse => {
  return ApiClient.post(`/partners/${merchantId}/basket/vouchers`, { code });
};

interface IRemoveMerchantBasketVoucher {
  merchantId: number | string;
  voucherId: number | string;
}
export const removeMerchantBasketVoucher = ({
  merchantId,
  voucherId,
}: IRemoveMerchantBasketVoucher): ApiResponse => {
  return ApiClient.del(`/partners/${merchantId}/basket/vouchers/${voucherId}`);
};

// ---- Checkout -----

interface IGetMerchantShippingMethods {
  merchantId: number | string;
  addressId?: number | string;
}
export const getMerchantShippingMethods = ({
  merchantId,
  addressId,
}: IGetMerchantShippingMethods): ApiResponse => {
  return ApiClient.get(`/partners/${merchantId}/basket/shipping_methods`, { addressId });
};

export const getMerchantPaymentMethods = (merchantId: number | string): ApiResponse => {
  return ApiClient.get(`/partners/${merchantId}/basket/payment_methods`);
};

interface ICheckout {
  merchantId: number | string;
  shipping: {
    methodCode: string;
    userAddressId: number | string;
  };
  payment: CheckoutPayment;
  submission: {
    basketId: number | string;
  };
}
export const merchantCheckout = ({ merchantId, ...data }: ICheckout): ApiResponse => {
  return ApiClient.post(`/partners/${merchantId}/checkout`, {
    ...data,
    billing: {
      billingAddressSameAsShipping: true,
    },
    guest: {},
  });
};

interface IGetOrders {
  merchantId?: number | string;
}
export const getOrders = (params?: IGetOrders, options?: ApiClientOptions): ApiResponse => {
  if (params?.merchantId) {
    return ApiClient.get(`/partners/${params.merchantId}/orders`, null, options);
  }
  return ApiClient.get(`/orders`, null, options);
};

export const getOrderByNumber = (number: number | string): ApiResponse => {
  return ApiClient.get(`/orders/${number}`);
};

interface IReorder {
  merchantId: number | string;
  orderNumber: number | string;
}
export const reorder = ({ merchantId, orderNumber }: IReorder): ApiResponse => {
  return ApiClient.post(`/partners/${merchantId}/basket/reorder`, null, {
    params: { orderNumber },
  });
};

// ---- Addresses ----

interface IGetAddresses {}
export const getAddresses = (data?: IGetAddresses, options?: ApiClientOptions): ApiResponse => {
  return ApiClient.get('/addresses');
};

export const getAddressById = (id: number | string): ApiResponse => {
  return ApiClient.get(`/addresses/${id}`);
};

export const createAddress = (data: Address): ApiResponse => {
  return ApiClient.post('/addresses', {
    ...data,
    lat: String(data.lat),
    lon: String(data.lon),
  });
};

export const updateAddress = (data: Address): ApiResponse => {
  const { id, ...addressData } = data;
  return ApiClient.put(`/addresses/${id}`, {
    ...addressData,
    lat: String(addressData.lat),
    lon: String(addressData.lon),
  });
};

export const deleteAddress = (id: number | string): ApiResponse => {
  return ApiClient.del(`/addresses/${id}`);
};

interface IGetCities {
  countryId?: number | string;
  search?: string;
}
export const getCities = (
  { countryId, search }: IGetCities,
  options?: ApiClientOptions,
): ApiResponse => {
  return ApiClient.get('/addresses/cities', null, {
    ...options,
    params: {
      countryId,
      search,
    },
  });
};

interface IGetDistricts {
  cityId?: number | string;
  search?: string;
}
export const getDistricts = (
  { cityId, search }: IGetDistricts,
  options?: ApiClientOptions,
): ApiResponse => {
  return ApiClient.get('/addresses/districts', null, {
    ...options,
    params: {
      cityId,
      search,
    },
  });
};

// ---- Stipe ----

export const getStripeClientSecret = (): ApiResponse => {
  return ApiClient.post('/payment/stripe/create_setup_intent/').then((result) => result.data);
};

export const getStripePublishableKey = (): ApiResponse => {
  return ApiClient.get('/payment/stripe/public_key/').then((result) => result.data);
};

interface ICompleteSetupIntent {
  setupIntentId: string;
  clientSecret: string;
  paymentMethodId: string | null;
}
export const completeSetupIntent = (data: ICompleteSetupIntent): ApiResponse => {
  return ApiClient.post('/payment/stripe/complete_setup_intent/', data);
};

// ---- Payment Methods ----

export const getPaymentSetupUrl = (): ApiResponse => {
  return ApiClient.get('/payment/stripe/setup_intent_page_url/');
};

export const getPaymentMethods = (): ApiResponse => {
  return ApiClient.get('/payment/bankcards/');
};

export const getPaymentMethodById = (id: string | number): ApiResponse => {
  return ApiClient.get(`/payment/bankcards/${id}`);
};

export const deletePaymentMethod = (id: string | number): ApiResponse => {
  return ApiClient.del(`/payment/bankcards/${id}`);
};
