import i18n, { Module } from 'i18next';
import { initReactI18next } from 'react-i18next';
import * as Localization from 'expo-localization';
import en from './en.json';

const languageDetector: Module = {
  type: 'languageDetector',
  async: true, // flags below detection to be async
  detect: async (callback: Function) => {
    try {
      const { locale } = await Localization.getLocalizationAsync();
      callback(locale);
    } catch (err) {
      console.warn('[i18n/config]: Unable to detect system language');
    }
  },
  init: () => {},
  cacheUserLanguage: () => {},
};

export const resources = {
  en: {
    translation: en,
  },
} as const;

i18n
  .use(languageDetector)
  .use(initReactI18next)
  .init({
    fallbackLng: 'en',
    lng: 'en',
    // debug: __DEV__,
    interpolation: {
      escapeValue: false,
    },
    resources,
  });
