import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';
import { Product } from 'api/models';
import { getMerchantProducts } from '../api';
import { RootState } from '../store';

type FetchAllResultType = {
  data: Product[];
  total: number;
};

/**
 * Will fetch products with provided params
 */
export const fetchProducts = createAsyncThunk<
  FetchAllResultType,
  {
    merchantId: number | string;
    categoryId: number | string;
    count?: number;
  },
  { state: RootState }
>('products/fetchProducts', async ({ merchantId, categoryId, count }, { dispatch }) => {
  dispatch(clearProducts());
  dispatch(setParams({ merchantId, categoryId, sortBy: 'price-asc' }));

  const result = await getMerchantProducts(
    { merchantId, categoryId, sortBy: 'price-asc' },
    { limit: count },
  );

  return {
    data: result.data,
    total: result.headers['totalcount'],
  } as FetchAllResultType;
});

/**
 * Will fetch next batch of products with previous params
 */
export const fetchMoreProducts = createAsyncThunk<
  Product[],
  number | undefined,
  { state: RootState }
>('products/fetchMore', async (count, { getState }) => {
  const state = getState();
  const { params } = state.products;
  const totalProducts = selectTotalProducts(state);

  const result = await getMerchantProducts(params, {
    limit: count,
    offset: totalProducts,
  });

  return result.data as Product[];
});

export const productsAdapter = createEntityAdapter<Product>();

// Slice

type InitialStateType = {
  loading: boolean;
  hasMore: boolean;
  params: any;
  total: number | undefined;
};

const initialState = productsAdapter.getInitialState<InitialStateType>({
  loading: false,
  hasMore: true,
  params: undefined,
  total: undefined,
});

export const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    clearProducts: (state) => {
      productsAdapter.removeAll(state);
      state.total = undefined;
    },
    setParams: (state, { payload }) => {
      state.params = payload;
    },
    setHasMore: (state, { payload }) => {
      state.hasMore = payload;
    },
  },
  extraReducers: (builder) => {
    // FetchAll
    builder.addCase(fetchProducts.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchProducts.fulfilled, (state, { payload }) => {
      const { data, total } = payload;
      productsAdapter.setAll(state, data);
      state.total = total;
      state.loading = false;
    });

    // FetchMore
    builder.addCase(fetchMoreProducts.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchMoreProducts.fulfilled, (state, { payload }) => {
      productsAdapter.addMany(state, payload);
      state.loading = false;
    });
  },
});

export const { clearProducts, setParams, setHasMore } = productsSlice.actions;

export default productsSlice.reducer;

// Selectors

export const {
  selectById: selectProductById,
  selectIds: selectProductsIds,
  selectEntities: selectProducts,
  selectAll: selectAllProducts,
  selectTotal: selectTotalProducts,
} = productsAdapter.getSelectors((state: RootState) => state.products);

export const selectProductsLoading = (state: RootState) => {
  return state.products.loading;
};

export const selectHasMoreProducts = (state: RootState) => {
  const totalProducts = selectTotalProducts(state);
  const total = state.products.total;

  return !!total && totalProducts < total;
};
