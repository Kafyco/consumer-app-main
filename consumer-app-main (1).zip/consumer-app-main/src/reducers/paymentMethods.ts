import { createSlice, createAsyncThunk, createEntityAdapter, Dispatch } from '@reduxjs/toolkit';

import {
  getPaymentMethods,
  getPaymentMethodById,
  deletePaymentMethod as apiDeletePaymentMethod,
} from 'api/index';
import { Bankcard } from 'api/models';

import * as Analytics from 'utils/analytics';

export const fetchPaymentMethods = createAsyncThunk<Bankcard[]>(
  'paymentMethods/fetchAll',
  async () => {
    const result = await getPaymentMethods();
    return result.data;
  },
);

export const fetchPaymentMethodById = createAsyncThunk<Bankcard, string>(
  'paymentMethods/fetchById',
  async (id: string) => {
    const result = await getPaymentMethodById(id);
    return result.data;
  },
);

export const deletePaymentMethod = (id: number | string) => async (dispatch: Dispatch) => {
  await apiDeletePaymentMethod(id);
  Analytics.logEvent('PAYMENT_METHOD_DELETE');
  dispatch(removePaymentMethodEntry(id));
};

export const paymentMethodsAdapter = createEntityAdapter<Bankcard>();

interface IPaymentMerhodsSlice {
  fetchStatus: 'idle' | 'pending' | 'fulfilled';
}

const initialState = paymentMethodsAdapter.getInitialState<IPaymentMerhodsSlice>({
  fetchStatus: 'idle',
});

export const paymentMethodsSlice = createSlice({
  name: 'paymentMethods',
  initialState,
  reducers: {
    resetPaymentMethods(state) {
      paymentMethodsAdapter.removeAll(state);
      state.fetchStatus = 'idle';
    },
    removePaymentMethodEntry: paymentMethodsAdapter.removeOne,
  },
  extraReducers: (builder) => {
    builder.addCase(fetchPaymentMethods.pending, (state) => {
      state.fetchStatus = 'pending';
    });
    builder.addCase(fetchPaymentMethods.fulfilled, (state, { payload }) => {
      state.fetchStatus = 'fulfilled';
      paymentMethodsAdapter.setAll(state, payload);
    });
    builder.addCase(fetchPaymentMethods.rejected, (state, payload) => {
      state.fetchStatus = 'fulfilled';
      console.warn('fetchPaymentMethods.reject', payload);
    });
    builder.addCase(fetchPaymentMethodById.fulfilled, (state, { payload }) => {
      paymentMethodsAdapter.upsertOne(state, payload);
    });
  },
});

export const { resetPaymentMethods, removePaymentMethodEntry } = paymentMethodsSlice.actions;

export default paymentMethodsSlice.reducer;

// Selectors

export const {
  selectById: selectPaymentMethodById,
  selectIds: selectPaymentMethodIds,
  selectEntities: selectPaymentMethodEntities,
  selectAll: selectAllPaymentMethods,
  selectTotal: selectTotalPaymentMethods,
} = paymentMethodsAdapter.getSelectors((state: any) => state.paymentMethods);

export const selectPaymentMethodsStatus = (state: any) => state.paymentMethods.fetchStatus;
