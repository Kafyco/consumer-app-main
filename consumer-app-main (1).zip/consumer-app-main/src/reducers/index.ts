import { combineReducers } from '@reduxjs/toolkit';

import app from './app';
import globalSearch from './globalSearch';
import merchants from './merchants';
import categories from './categories';
import productsSections from './productsSections';
import products from './products';
import merchantSearch from './merchantSearch';
import basket from './basket';
import addresses from './addresses';
import paymentMethods from './paymentMethods';
import checkout from './checkout';
import orders from './orders';

const rootReducer = combineReducers({
  app,
  globalSearch,
  merchants,
  categories,
  productsSections,
  products,
  merchantSearch,
  basket,
  addresses,
  paymentMethods,
  checkout,
  orders,
});

export default rootReducer;
