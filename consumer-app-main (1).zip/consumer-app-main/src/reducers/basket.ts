import {
  createSlice,
  createAsyncThunk,
  createEntityAdapter,
  PayloadAction,
} from '@reduxjs/toolkit';

import { Basket, BasketLine, Product } from 'api/models';

import {
  getMerchantBasket,
  addToMerchantBasket,
  updateMerchantBasketLineQty,
  applyMerchantBasketCoupon,
  removeMerchantBasketVoucher,
} from 'api/index';
import * as Analytics from 'utils/analytics';
import { RootState } from '../store';

type ThunkApiType = { state: RootState };

export const fetchMerchantBasket = createAsyncThunk<Basket, number | string>(
  'basket/fetch',
  async (merchantId) => {
    const result = await getMerchantBasket({ merchantId });
    return result.data as Basket;
  },
);

interface AddToBasketParams {
  productId: number | string;
  quantity: number;
}
export const addToBasket = createAsyncThunk<Basket, AddToBasketParams, ThunkApiType>(
  'basket/add',
  async ({ productId, quantity }, { getState }) => {
    const merchantId = selectBasketMerchantId(getState());
    const payload = { merchantId, productId, quantity };

    Analytics.logEvent('BASKET_ADD_TO', payload);

    const result = await addToMerchantBasket(payload);
    return result.data as Basket;
  },
);

interface UpdateQtyParams {
  lineId: number | string;
  productId: number | string;
  quantity: number;
}
export const updateLineQty = createAsyncThunk<Basket, UpdateQtyParams, ThunkApiType>(
  'basket/update',
  async ({ lineId, productId, quantity }, { getState }) => {
    const state = getState();
    const merchantId = selectBasketMerchantId(state);

    Analytics.logEvent('BASKET_UPDATE_LINE_QTY', {
      merchantId,
      productId,
      quantity,
    });

    const result = await updateMerchantBasketLineQty({
      merchantId,
      lineId,
      quantity,
    });

    return result.data as Basket;
  },
);

interface RemoveBasketLineParams {
  lineId: number | string;
  productId: number | string;
}
export const removeBasketLine = createAsyncThunk<Basket, RemoveBasketLineParams, ThunkApiType>(
  'basket/removeLine',
  async ({ lineId, productId }, { getState }) => {
    const state = getState();
    const merchantId = selectBasketMerchantId(state);

    Analytics.logEvent('BASKET_UPDATE_LINE_QTY', {
      merchantId,
      productId,
    });

    const result = await updateMerchantBasketLineQty({
      merchantId,
      lineId,
      quantity: 0,
    });
    return result.data as Basket;
  },
);

export const applyVoucher = createAsyncThunk<Basket, string, ThunkApiType>(
  'basket/applyVoucher',
  async (code, { getState }) => {
    const state = getState();
    const merchantId = selectBasketMerchantId(state);

    const results = await applyMerchantBasketCoupon({ merchantId, code });
    return results.data as Basket;
  },
);

export const removeVoucher = createAsyncThunk<Basket, string | number, ThunkApiType>(
  'basket/removeVoucher',
  async (voucherId, { getState }) => {
    const state = getState();
    const merchantId = selectBasketMerchantId(state);

    const results = await removeMerchantBasketVoucher({ merchantId, voucherId });
    return results.data as Basket;
  },
);

/* Utility */
const updateBasket = (state: any, { payload }: PayloadAction<Basket>) => {
  if (payload.id === state.info?.id) {
    state.info = payload;
    basketAdapter.setAll(state, payload.allLines);
  }
};

export const basketAdapter = createEntityAdapter<BasketLine>();

type InitialStateType = {
  fetchStatus: 'idle' | 'pending' | 'fulfilled';
  info?: Basket;
  stagedProduct?: Product;
};

const initialState = basketAdapter.getInitialState<InitialStateType>({
  fetchStatus: 'idle',
  info: undefined,
  stagedProduct: undefined,
});

export const basketSlice = createSlice({
  name: 'basket',
  initialState,
  reducers: {
    resetBasket(state) {
      state.fetchStatus = 'idle';
      state.info = undefined;
      basketAdapter.removeAll(state);
    },
    setStagedProduct(state, { payload }) {
      state.stagedProduct = payload;
    },
    resetStagedProduct(state) {
      state.stagedProduct = undefined;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchMerchantBasket.pending, (state) => {
      state.fetchStatus = 'pending';
    });
    builder.addCase(fetchMerchantBasket.fulfilled, (state, { payload }) => {
      state.fetchStatus = 'fulfilled';
      state.info = payload;
      basketAdapter.setAll(state, payload.allLines);
    });
    builder.addCase(fetchMerchantBasket.rejected, (state) => {
      state.fetchStatus = 'fulfilled';
    });
    builder.addCase(addToBasket.fulfilled, updateBasket);
    builder.addCase(updateLineQty.fulfilled, updateBasket);
    builder.addCase(removeBasketLine.fulfilled, updateBasket);
    builder.addCase(applyVoucher.fulfilled, updateBasket);
    builder.addCase(removeVoucher.fulfilled, updateBasket);
  },
});

export const { resetBasket, setStagedProduct, resetStagedProduct } = basketSlice.actions;

export default basketSlice.reducer;

// Selectors

export const {
  selectById: selectBasketLineById,
  selectIds: selectBasketLinesIds,
  selectEntities: selectBasketLines,
  selectAll: selectAllBasketLines,
  selectTotal: selectTotalBasketLines,
} = basketAdapter.getSelectors((state: RootState) => state.basket);

export const selectBasketInfo = (state: RootState): Basket | undefined => state.basket.info;
// export const selectAllBasketLines = (state: RootState): BasketLine[] => state.basket.allLines;
export const selectBasketMerchantId = (state: RootState) => state.basket.info?.partner.id;
export const selectBasketFetchStatus = (state: RootState) => state.basket.fetchStatus;
export const selectBasketLineByProductId = (state: RootState, id: number | string) => {
  const allLines = selectAllBasketLines(state);
  return allLines.find((line) => line.product.id === id);
};
export const selectBasketStagedProduct = (state: RootState) => state.basket.stagedProduct;

export const getProductsQty = (basketLines: BasketLine[]) => {
  return basketLines.reduce((res, line) => {
    res[line.product.id] = line.quantity;
    return res;
  }, {});
};
