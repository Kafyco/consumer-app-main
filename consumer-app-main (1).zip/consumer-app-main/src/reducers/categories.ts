import {
  createSlice,
  createAsyncThunk,
  createEntityAdapter,
  createSelector,
} from '@reduxjs/toolkit';
import { getMerchantCategories } from 'api/index';
import { CategoryList as Category } from 'api/models';
import { RootState } from '../store';

export const fetchMerchantCategories = createAsyncThunk<
  Category[],
  number | string,
  {
    state: RootState;
  }
>('merchant/categories/fetchAll', async (merchantId, { dispatch }) => {
  dispatch(setCurrentMerchant(merchantId));

  const result = await getMerchantCategories({ merchantId });
  return result.data;
});

export const categoriesAdapter = createEntityAdapter<Category>();

const initialState = categoriesAdapter.getInitialState({
  loading: false,
  merchantId: undefined,
});

export const categoriesSlice = createSlice({
  name: 'categories',
  initialState,
  reducers: {
    resetCategories: (state) => {
      categoriesAdapter.removeAll(state);
      state.merchantId = undefined;
      state.loading = false;
    },
    setCurrentMerchant: (state, { payload }) => {
      state.merchantId = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchMerchantCategories.pending, (state, p) => {
      state.loading = true;
    });
    builder.addCase(fetchMerchantCategories.fulfilled, (state, { payload }) => {
      state.loading = false;
      categoriesAdapter.setAll(state, payload);
    });
    builder.addCase(fetchMerchantCategories.rejected, (state) => {
      state.loading = false;
    });
  },
});

export const { resetCategories, setCurrentMerchant } = categoriesSlice.actions;

export default categoriesSlice.reducer;

export const {
  selectById: selectCategoryById,
  selectIds: selectCategoriesIds,
  selectEntities: selectCategories,
  selectAll: selectAllCategories,
  selectTotal: selectTotalCategories,
} = categoriesAdapter.getSelectors((state: RootState) => state.categories);

export const selectRootCategories = createSelector([selectAllCategories], (categories) =>
  categories?.filter((c) => !c.parentPath),
);

export const selectDecedentCategories = createSelector(
  [selectCategoryById, selectAllCategories],
  (parent, categories) => (parent ? categories?.filter((c) => c.parentPath === parent.path) : []),
);

export const selectCategoriesLoading = (state: RootState) => state.categories.loading;

export const selectCategoriesCurrentMerchant = (state: RootState) => {
  return state.categories.merchantId;
};
