import * as Sentry from 'sentry-expo';
import { createSlice, createAsyncThunk, createSelector, unwrapResult } from '@reduxjs/toolkit';

import { Order, PaymentMethod, ShippingMethod, CheckoutPayment } from 'api/models';
import {
  merchantCheckout,
  getOrderByNumber,
  getMerchantShippingMethods,
  getMerchantPaymentMethods,
} from 'api/index';

import * as Analytics from 'utils/analytics';

import { RootState } from '../store';

type ThunkApiConfig = { state: RootState };

type PrepareCheckoutActionProps = {
  merchantId: string | number;
  addressId: string | number;
};
type PrepareCheckoutActionReturnType = [ShippingMethod | null, PaymentMethod[]];

export const prepareCheckout = createAsyncThunk<
  PrepareCheckoutActionReturnType,
  PrepareCheckoutActionProps,
  ThunkApiConfig
>('checkout/prepare', async ({ merchantId, addressId }, { dispatch, rejectWithValue }) => {
  try {
    const results = await Promise.all([
      // 1. Check that shipping is possible and set the default shipping method.
      dispatch(fetchShippingMethod({ merchantId, addressId })),
      // 2. Fetch all payment methods accepted by merchant.
      dispatch(fetchMerchantPaymentMethods({ merchantId })),
    ]);
    const res = results.map(unwrapResult);

    return [res[0], res[1]] as PrepareCheckoutActionReturnType;
  } catch (err) {
    Sentry.Native.captureException(err);
    return rejectWithValue('general_error');
  }
});

type FetchShippingMethodProps = PrepareCheckoutActionProps;
export const fetchShippingMethod = createAsyncThunk<
  ShippingMethod | null,
  FetchShippingMethodProps
>('checkout/shippingMethod', async ({ merchantId, addressId }) => {
  const results = await getMerchantShippingMethods({ merchantId, addressId });

  if (results.data?.length) {
    return results.data[0];
  }

  return null;
});

export const fetchMerchantPaymentMethods = createAsyncThunk<
  PaymentMethod[],
  { merchantId: number | string }
>('checkout/merchantPaymentMethods', async ({ merchantId }) => {
  const results = await getMerchantPaymentMethods(merchantId);
  return results.data;
});

type CheckoutActionType = {
  basketId: string | number;
  merchantId: string | number;
  userAddressId: string | number;
  payment: CheckoutPayment;
  shippingMethodCode: string;
};
export const checkout = createAsyncThunk<Order, CheckoutActionType>(
  'checkout/checkout',
  async ({ basketId, merchantId, userAddressId, payment, shippingMethodCode }) => {
    Analytics.logEvent('CHECKOUT_ATTEMPT', {
      basketId,
      merchantId,
      paymentType: payment.method,
    });

    const result = await merchantCheckout({
      merchantId,
      payment,
      shipping: {
        userAddressId,
        methodCode: shippingMethodCode,
      },
      submission: {
        basketId,
      },
    });

    return result?.data as Order;
  },
);

export const fetchConfirmedOrder = createAsyncThunk<Order, string | number>(
  'checkout/fetchOrder',
  async (orderNumber) => {
    const results = await getOrderByNumber(orderNumber);
    return results?.data;
  },
);

type InitialState = {
  status: 'idle' | 'pending' | 'ready' | 'error';
  errorCode?: string;
  shippingMethod?: ShippingMethod | null;
  paymentMethods?: PaymentMethod[];
  selectedPaymentMethod?: CheckoutPayment;
  order?: Order;
};

const initialState: InitialState = {
  status: 'idle',
  shippingMethod: undefined,
  paymentMethods: undefined,
  selectedPaymentMethod: undefined,
  order: undefined,
};

export const checkoutSlice = createSlice({
  name: 'checkout',
  initialState,
  reducers: {
    clear() {
      return initialState;
    },
    setStatus(state, { payload }) {
      state.status = payload;
    },
    setError(state, { payload }) {
      state.status = 'error';
      state.errorCode = payload;
    },
    setSelectedPaymentMethod(state, { payload }) {
      state.selectedPaymentMethod = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(checkout.fulfilled, (state, { payload }) => {
      state.order = payload;
    });
    builder.addCase(fetchConfirmedOrder.fulfilled, (state, { payload }) => {
      state.order = payload;
    });
    builder.addCase(prepareCheckout.pending, (state, { payload }) => {
      state.status = 'pending';
    });
    builder.addCase(prepareCheckout.fulfilled, (state, { payload }) => {
      const [shippingMethod, paymentMethods] = payload;

      state.status = 'ready';
      state.shippingMethod = shippingMethod;
      state.paymentMethods = paymentMethods;
    });
    builder.addCase(prepareCheckout.rejected, (state, { payload }) => {
      state.status = 'error';
      state.errorCode = payload as string;
    });
  },
});

export const { clear, setStatus, setError, setSelectedPaymentMethod } = checkoutSlice.actions;

export default checkoutSlice.reducer;

export const selectConfirmedOrder = (state: RootState, number: number | string) => {
  if (String(state.checkout.order?.number) === String(number)) {
    return state.checkout.order;
  }
};

export const selectCheckoutStatus = (state: RootState) => state.checkout.status;

export const selectCheckoutErrorCode = (state: RootState) => state.checkout.errorCode;

export const selectSelectedPaymentMethod = (state: RootState) =>
  state.checkout.selectedPaymentMethod;

export const selectCheckout = (state: RootState) => state.checkout;

export const selectCheckoutData = createSelector([selectCheckout], (chekoutState) => {
  const { status, shippingMethod, paymentMethods, selectedPaymentMethod } = chekoutState;
  const canDeliver = shippingMethod !== null;

  return { status, canDeliver, shippingMethod, paymentMethods, selectedPaymentMethod };
});
