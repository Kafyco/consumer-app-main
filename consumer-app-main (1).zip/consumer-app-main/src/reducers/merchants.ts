import {
  createSlice,
  createAsyncThunk,
  createEntityAdapter,
  createSelector,
} from '@reduxjs/toolkit';

import { getMerchantById, getMerchants, setMerchantFavourite } from 'api/index';
import { Partner } from 'api/models';

import { RootState } from '../store';

interface FetchMerchantsProps {
  address: number | string;
  isFavouriteOnly?: boolean;
}
export const fetchMerchants = createAsyncThunk<Partner[], FetchMerchantsProps>(
  'merchants/fetchAll',
  async ({ address, isFavouriteOnly }) => {
    const result = await getMerchants({ address, isFavouriteOnly });
    return result.data;
  },
);

export const fetchMerchantById = createAsyncThunk<Partner, string | number>(
  'merchants/fetchById',
  async (id) => {
    const result = await getMerchantById(id);
    return result.data;
  },
);

export const getAndSetCurrentMerchant = createAsyncThunk<void, string, { state: RootState }>(
  'merchants/getAndSetCurrentMerchant',
  (merchantId, { getState, dispatch }) => {
    const state = getState();
    const { currentMerchantId } = state.merchants;

    if (currentMerchantId !== merchantId) {
      dispatch(setCurrentMerchantId(merchantId));
      dispatch(fetchMerchantById(merchantId));
    }
  },
);

interface SetFavouriteProps {
  merchantId: number | string;
  isFavourite: boolean;
}
export const setFavourite = createAsyncThunk<void, SetFavouriteProps>(
  'merchants/favourite',
  async ({ merchantId, isFavourite }, { dispatch }) => {
    await setMerchantFavourite({ merchantId, isFavourite });
    dispatch(updateFavourite({ merchantId, isFavourite }));
  },
);

export const merchantsAdapter = createEntityAdapter<Partner>();

interface IMerchantsSlice {
  fetchStatus: 'idle' | 'pending' | 'fulfilled';
  currentMerchantId?: number | string;
}
const initialState = merchantsAdapter.getInitialState<IMerchantsSlice>({
  fetchStatus: 'idle',
  currentMerchantId: undefined,
});

export const merchantsSlice = createSlice({
  name: 'merchants',
  initialState,
  reducers: {
    updateFavourite(state, { payload: { merchantId, isFavourite } }) {
      merchantsAdapter.updateOne(state, { id: merchantId, changes: { isFavourite } });
    },
    setCurrentMerchantId(state, { payload }) {
      state.currentMerchantId = payload;
    },
    resetCurrentMerchant(state) {
      state.currentMerchantId = undefined;
    },
    resetMerchants(state) {
      merchantsAdapter.removeAll(state);
      state.fetchStatus = 'idle';
      state.currentMerchantId = undefined;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchMerchants.pending, (state) => {
      state.fetchStatus = 'pending';
    });
    builder.addCase(fetchMerchants.fulfilled, (state, { payload }) => {
      const merchants = payload.map(({ categories, ...attrs }) => {
        return {
          ...attrs,
          categories,
        };
      });

      state.fetchStatus = 'fulfilled';
      merchantsAdapter.setAll(state, merchants);
    });
    builder.addCase(fetchMerchants.rejected, (state, payload) => {
      state.fetchStatus = 'fulfilled';
      console.warn('fetchMerchants.reject', payload);
    });
    builder.addCase(fetchMerchantById.fulfilled, (state, { payload }) => {
      const { categories, ...attrs } = payload;
      merchantsAdapter.upsertOne(state, {
        ...attrs,
        categories,
      });
    });
  },
});

export const { updateFavourite, setCurrentMerchantId, resetCurrentMerchant, resetMerchants } =
  merchantsSlice.actions;

export default merchantsSlice.reducer;

// Selectors

export const {
  selectById: selectMerchantById,
  selectIds: selectMerchantIds,
  selectEntities: selectMerchantEntities,
  selectAll: selectAllMerchants,
  selectTotal: selectTotalMerchants,
} = merchantsAdapter.getSelectors((state: RootState) => state.merchants);

export const selectMerchantsStatus = (state: RootState) => state.merchants.fetchStatus;

export const selectCurrentMerchant = (state: RootState) => {
  const currentMerchantId = state.merchants.currentMerchantId;

  return currentMerchantId ? selectMerchantById(state, currentMerchantId) : undefined;
};

export const selectFavouriteMerchants = createSelector([selectAllMerchants], (merchants) =>
  merchants.filter((m) => m.isFavourite),
);
