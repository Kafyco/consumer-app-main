import { createSlice } from '@reduxjs/toolkit';
import { uniqBy } from 'lodash';

import { getMerchantProducts } from 'api/index';
import { CategoryList as Category, Product } from 'api/models';
import { RootState } from '../store';

export type ProductsSectionType = {
  id: number | string;
  title: string;
  data: Product[];
  count: number;
  merchantId: number | string;
};
type ProdutsSectionsSliceState = {
  loading: boolean;
  merchantId?: number | string;
  categories?: Category[];
  entities: ProductsSectionType[];
};

const initialState: ProdutsSectionsSliceState = {
  loading: false,
  merchantId: undefined,
  categories: undefined,
  entities: [],
};

export const produtsSectionsSlice = createSlice({
  name: 'productsSections',
  initialState,
  reducers: {
    clear: () => {
      return initialState;
    },
    configure: (state, { payload: { merchantId, categories } }) => {
      return {
        ...initialState,
        merchantId,
        categories,
      };
    },
    setLoading: (state, { payload }) => {
      state.loading = payload;
    },
    // This will replace current entries list
    setAll: (state, { payload }) => {
      state.entities = payload;
    },
    addMany: (state, { payload }) => {
      state.entities = uniqBy(state.entities.concat(payload), 'id');
    },
  },
});

export const {
  clear: clearProductsSections,
  setLoading,
  setAll,
  addMany,
  configure: configureProductsSections,
} = produtsSectionsSlice.actions;

export default produtsSectionsSlice.reducer;

// This method will fetch next products section in queue
export const fetchMoreSections =
  (count = 5, perSection = 3) =>
  (dispatch, getState) => {
    const { categories, entities, merchantId, loading } = getState().productsSections;
    const nextCategories = categories.slice(entities.length, entities.length + count);

    if (loading) {
      return;
    }

    // Nothing to fetch anymore
    if (!nextCategories.length) {
      return Promise.resolve();
    }

    dispatch(setLoading(true));

    const requests = nextCategories.map(({ id, name }: Category) => {
      return getMerchantProducts(
        {
          merchantId,
          categoryId: id,
          sortBy: 'price-asc',
        },
        {
          limit: perSection,
        },
      ).then(({ data, headers }: any) => {
        return {
          id,
          data,
          title: name,
          count: headers['totalcount'],
          merchantId,
        };
      });
    });

    return Promise.all(requests)
      .then((values) => {
        dispatch(addMany(values));
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

export const selectAllSections = (state: RootState) => state.productsSections.entities;

export const selectProductsLoading = (state: RootState) => state.productsSections.loading;
