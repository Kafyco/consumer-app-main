import { createSlice, createAsyncThunk, unwrapResult } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import * as Sentry from 'sentry-expo';

import ApiClient from 'api/ApiClient';
import { register as apiRegister, createLead, login, getUserInfo, suspendAccount } from 'api/index';
import { UserInfo, CheckoutPayment, Address, LoginJson, CreateLeadJson } from 'api/models';
import getAddressName from 'utils/getAddressName';
import { unregisterExpoToken } from 'utils/expoPushToken';
import { getEnvironmentProp } from 'utils/environment';
import * as Analytics from 'utils/analytics';

import { resetAddresses } from './addresses';
import { resetMerchants } from './merchants';
import { resetPaymentMethods } from './paymentMethods';
import { RootState } from '../store';

export type AppStateAddress = {
  id: string | number;
  title: string;
};

type RestoredAppStateType = {
  token: string | null;
  currentAddress?: AppStateAddress;
  hasOrders?: boolean;
  user?: UserInfo;
  paymentMethod?: CheckoutPayment;
};

const clearStores = () =>
  Promise.all([
    SecureStore.deleteItemAsync('token'),
    AsyncStorage.removeItem('currentAddress'),
    AsyncStorage.removeItem('paymentMethod'),
    AsyncStorage.removeItem('hasOrders'),
  ]);

export const fetchCurrentUser = createAsyncThunk<UserInfo>('app/currentUser', async () => {
  const result = await getUserInfo();
  return result.data;
});

export const restoreAppState = createAsyncThunk<RestoredAppStateType>(
  'app/restore',
  async (_, { dispatch }) => {
    let token: string | null = null;
    let currentAddress: any;
    let paymentMethod: any;
    let hasOrders: any;

    const results = () => ({
      token,
      currentAddress,
      paymentMethod,
      hasOrders,
    });

    try {
      const storedEnvName = await SecureStore.getItemAsync('envName');
      const currentEnv = getEnvironmentProp('envName');

      // Check that environment is the same, otherview clear.
      if (currentEnv !== storedEnvName) {
        await clearStores();
        await SecureStore.setItemAsync('envName', currentEnv);

        return results();
      }

      const rawToken = await SecureStore.getItemAsync('token');

      if (rawToken) {
        const provisionaltoken = JSON.parse(rawToken);
        ApiClient.setToken(provisionaltoken);

        // Track current user

        const fetchCurrentUserAction = await dispatch(fetchCurrentUser());
        const user = unwrapResult(fetchCurrentUserAction);

        Analytics.identify(user.pk, user);

        const store = await Promise.all([
          AsyncStorage.getItem('currentAddress'),
          AsyncStorage.getItem('paymentMethod'),
          AsyncStorage.getItem('hasOrders'),
        ]);
        token = provisionaltoken;
        currentAddress = store[0] ? (JSON.parse(store[0]) as AppStateAddress) : undefined;
        paymentMethod = store[1] ? (JSON.parse(store[1]) as CheckoutPayment) : undefined;
        hasOrders = store[2] ? (JSON.parse(store[2]) as boolean) : undefined;
      }

      return results();
    } catch (err) {
      console.warn('Error restoring app state\n', err);

      const sentryError = new Error(JSON.stringify(err));
      sentryError.name = '[APP][RESTORE]';
      Sentry.Native.captureException(sentryError);

      // Make sure that token is clear.
      ApiClient.clearToken();

      return results();
    }
  },
);

export const register = createAsyncThunk<string, CreateLeadJson>(
  'app/register',
  async (data, { rejectWithValue }) => {
    try {
      const result = await apiRegister(data);
      Analytics.logEvent('USER_REQUEST_ACCOUNT', data);

      await createLead(data);

      return result.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  },
);

export const signIn = createAsyncThunk<string, LoginJson>(
  'app/signIn',
  async (credentials, { dispatch }) => {
    const result = await login(credentials);
    const { jwt: token } = result.data;

    // Store token
    ApiClient.setToken(token);
    await SecureStore.setItemAsync('token', JSON.stringify(token));

    // Track current user
    const fetchCurrentUserAction = await dispatch(fetchCurrentUser());
    const user = unwrapResult(fetchCurrentUserAction);

    Analytics.identify(user.pk, user);
    Analytics.logEvent('USER_LOGGED_IN');

    return token;
  },
);

export const signOut = createAsyncThunk<void, void>('app/signOut', async (_, { dispatch }) => {
  try {
    // Assign token to anonymous. Don't wait for results.
    await unregisterExpoToken();

    ApiClient.clearToken();
    dispatch(resetMerchants());
    dispatch(resetAddresses());
    dispatch(resetPaymentMethods());

    await clearStores();

    Analytics.logEvent('USER_LOGGED_OUT');
    Analytics.identify(null);
  } catch (err) {
    console.warn('Error while signing out', err);
    Sentry.Native.captureException(err);
  }
});

export const deleteAccount = createAsyncThunk<void, void>('app/deleteAccount', async () => {
  try {
    Analytics.logEvent('USER_DELETE_ACCOUNT');
    await suspendAccount();
  } catch (err) {
    console.warn('Error while deleting account', err);
    Sentry.Native.captureException(err);
  }
});

export const setCurrentAddress = createAsyncThunk<AppStateAddress, Address>(
  'app/setCurrentAddress',
  async (address) => {
    const appStateAddress: AppStateAddress = {
      id: address.id,
      title: getAddressName(address),
    };

    try {
      await AsyncStorage.setItem('currentAddress', JSON.stringify(appStateAddress));
    } catch (err) {
      console.warn('Error while saving address', err);
      Sentry.Native.captureException(err);
    }

    Analytics.logEvent('ADDRESS_SWITCH');

    return appStateAddress;
  },
);

export const setHasOrders = createAsyncThunk<boolean, boolean>(
  'app/setHasOrders',
  async (hasOrders) => {
    try {
      await AsyncStorage.setItem('hasOrders', JSON.stringify(hasOrders));
    } catch (err) {
      console.warn('Error while saving address', err);
      Sentry.Native.captureException(err);
    }

    return hasOrders;
  },
);

export const setPaymentMethod = createAsyncThunk<CheckoutPayment, CheckoutPayment>(
  'app/setPaymentMethod',
  async (payment) => {
    try {
      await AsyncStorage.setItem('paymentMethod', JSON.stringify(payment));
    } catch (err) {
      console.warn('Error while saving address', err);
      Sentry.Native.captureException(err);
    }

    return payment;
  },
);

type InitialStateType = {
  token: string | null;
  isAuthResolved: boolean;
  currentAddress?: AppStateAddress;
  hasOrders?: boolean;
  user?: UserInfo;
  paymentMethod?: CheckoutPayment;
  authenticatedNavigationResolved?: boolean;
  notificationsStatus?: string;
};

const initialState = {
  token: null,
  isAuthResolved: false,
  currentAddress: undefined,
  hasOrders: undefined,
  user: undefined,
  paymentMethod: undefined,
  notificationsStatus: undefined,
} as InitialStateType;

export const appSlice = createSlice({
  name: 'app',
  initialState,
  reducers: {
    setCurrentUser(state, { payload }) {
      state.user = payload;
    },
    setNotificationsStatus(state, { payload }) {
      state.notificationsStatus = payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(restoreAppState.fulfilled, (state, { payload }) => {
      const { token, currentAddress, paymentMethod, hasOrders } = payload;

      state.isAuthResolved = true;
      state.token = token;
      state.hasOrders = hasOrders;
      state.currentAddress = currentAddress;
      state.paymentMethod = paymentMethod;
    });
    builder.addCase(fetchCurrentUser.fulfilled, (state, { payload }) => {
      state.user = payload;
    });
    builder.addCase(setCurrentAddress.fulfilled, (state, { payload }) => {
      state.currentAddress = payload;
    });
    builder.addCase(setHasOrders.fulfilled, (state, { payload }) => {
      state.hasOrders = payload;
    });
    builder.addCase(signIn.fulfilled, (state, { payload }) => {
      state.token = payload;
      state.isAuthResolved = true;
    });
    builder.addCase(signOut.fulfilled, (state) => {
      state.token = null;
      state.isAuthResolved = true;
      state.currentAddress = undefined;
      state.hasOrders = undefined;
      state.user = undefined;
      state.paymentMethod = undefined;
    });
    builder.addCase(setPaymentMethod.fulfilled, (state, { payload }) => {
      state.paymentMethod = payload;
    });
  },
});

export const { setNotificationsStatus } = appSlice.actions;

export const selectAuthResolutionFlag = (state: RootState) => state.app.isAuthResolved;
export const selectIsAuthenticated = (state: RootState) => !!state.app.token;
export const selectUserHasOrdersFlag = (state: RootState) => state.app.hasOrders;
export const selectCurrentAddress = (state: RootState) => state.app.currentAddress;
export const selectCurrentUser = (state: RootState) => state.app.user;
export const selectPaymentMethod = (state: RootState) => state.app.paymentMethod;
export const selectNotificationsStatus = (state: RootState) => state.app.notificationsStatus;

export default appSlice.reducer;
