import { createSlice, createAsyncThunk, createEntityAdapter, Dispatch } from '@reduxjs/toolkit';

import {
  getAddresses,
  getAddressById,
  updateAddress as apiUpdateAddress,
  createAddress as apiCreateAddress,
  deleteAddress as apiDeleteAddress,
  getCities,
  getDistricts,
} from 'api/index';
import { Address, City, District } from 'api/models';
import { ParamListBase } from '@react-navigation/native';
import { RootState } from '../store';

export const fetchAddresses = createAsyncThunk<Address[]>('addresses/fetchAll', async () => {
  const result = await getAddresses();
  return result.data;
});

export const fetchAddressById = createAsyncThunk<Address, string | number>(
  'addresses/fetchById',
  async (id) => {
    const result = await getAddressById(id);
    return result.data;
  },
);

export const updateAddress = createAsyncThunk<Address, Address>(
  'address/update',
  async (data, { rejectWithValue }) => {
    try {
      const result = await apiUpdateAddress(data);
      return result.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  },
);
export const createNewAddress = createAsyncThunk<Address, Address>(
  'address/create',
  async (data, { rejectWithValue }) => {
    try {
      const result = await apiCreateAddress(data);
      return result.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  },
);

export const deleteAddress = createAsyncThunk<number | string, number | string>(
  'addresses/delete',
  async (addressId) => {
    await apiDeleteAddress(addressId);
    return addressId;
  },
);

export const fetchAllCities = (country: string) => async (dispatch: Dispatch) => {
  const result = await getCities({ countryId: country });
  dispatch(setCities(result.data as City[]));
};

export const fetchCityDistricts = async (cityId: string | number) => {
  const result = await getDistricts({ cityId });
  return result.data as District[];
};

export const addressesAdapter = createEntityAdapter<Address>();

interface IAddressesSlice {
  fetchStatus: 'idle' | 'pending' | 'fulfilled';
  cities: City[] | null;
  stagedAddress?: Address;
  returnTo?: ParamListBase;
}

const initialState = addressesAdapter.getInitialState<IAddressesSlice>({
  fetchStatus: 'idle',
  cities: null,
  stagedAddress: undefined,
  returnTo: undefined,
});

export const addressesSlice = createSlice({
  name: 'addresses',
  initialState,
  reducers: {
    setReturnTo(state, { payload }) {
      state.returnTo = payload;
    },
    clearReturnTo(state) {
      state.returnTo = undefined;
    },
    stageAddress(state, { payload }) {
      state.stagedAddress = payload;
    },
    clearStagedAddress(state) {
      state.stagedAddress = undefined;
    },
    resetAddresses(state) {
      addressesAdapter.removeAll(state);
      state.fetchStatus = 'idle';
      state.stagedAddress = undefined;
      state.returnTo = undefined;
    },
    updateAddressEntry: addressesAdapter.updateOne,
    addAddressEntry: addressesAdapter.addOne,
    removeAddressEntry: addressesAdapter.removeOne,

    // Depricated
    setCities(state, { payload }) {
      state.cities = payload;
    },
    clearCities(state) {
      state.cities = null;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchAddresses.pending, (state) => {
      state.fetchStatus = 'pending';
    });
    builder.addCase(fetchAddresses.fulfilled, (state, { payload }) => {
      state.fetchStatus = 'fulfilled';
      addressesAdapter.setAll(state, payload);
    });
    builder.addCase(fetchAddresses.rejected, (state, payload) => {
      state.fetchStatus = 'fulfilled';
      console.warn('fetchAddresses.reject', payload);
    });
    builder.addCase(fetchAddressById.fulfilled, (state, { payload }) => {
      addressesAdapter.upsertOne(state, payload);
    });
    builder.addCase(deleteAddress.fulfilled, (state, { payload }) => {
      addressesAdapter.removeOne(state, payload);
    });
    builder.addCase(updateAddress.fulfilled, (state, { payload }) => {
      addressesAdapter.upsertOne(state, payload);
    });
    builder.addCase(createNewAddress.fulfilled, (state, { payload }) => {
      addressesAdapter.upsertOne(state, payload);
    });
  },
});

export const {
  setReturnTo,
  clearReturnTo,
  stageAddress,
  clearStagedAddress,
  addAddressEntry,
  updateAddressEntry,
  removeAddressEntry,
  setCities,
  clearCities,
  resetAddresses,
} = addressesSlice.actions;

export default addressesSlice.reducer;

// Selectors

export const {
  selectById: selectAddressById,
  selectIds: selectAddressIds,
  selectEntities: selectAddressEntities,
  selectAll: selectAllAddresses,
  selectTotal: selectTotalAddresses,
} = addressesAdapter.getSelectors((state: RootState) => state.addresses);

export const selectAddressesStatus = (state: RootState) => state.addresses.fetchStatus;
export const selectStagedAddress = (state: RootState) => state.addresses.stagedAddress;
export const selectReturnTo = (state: RootState) => state.addresses.returnTo;

export const selectCities = (state: RootState) => state.addresses.cities;
