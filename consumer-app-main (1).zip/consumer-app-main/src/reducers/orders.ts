import { createSlice, createAsyncThunk, createEntityAdapter } from '@reduxjs/toolkit';

import { getOrders, getOrderByNumber, reorder as apiReorder } from 'api/index';
import { Basket, Order } from 'api/models';
import * as Analytics from 'utils/analytics';

import { RootState } from '../store';

type FetchAllResultType = {
  data: Order[];
  total: number;
};
type FetchOrdersProps = {
  merchantId?: number;
  limit?: number;
};
export const fetchOrders = createAsyncThunk<FetchAllResultType, FetchOrdersProps | undefined>(
  'orders/fetchAll',
  async (props) => {
    const { limit, merchantId } = props || {};
    const results = await getOrders({ merchantId }, { limit });

    return {
      data: results.data,
      total: Number(results.headers['totalcount']),
    } as FetchAllResultType;
  },
);

export const fetchMoreOrder = createAsyncThunk<Order[], FetchOrdersProps, { state: RootState }>(
  'order/fetchMore',
  async (props = {}, { getState }) => {
    const { limit, merchantId } = props;
    const totalOrders = selectTotalOrders(getState());

    const results = await getOrders(
      { merchantId },
      {
        limit,
        offset: totalOrders,
      },
    );

    return results.data as Order[];
  },
);

export const fetchOrderByNumber = createAsyncThunk<Order, number | string>(
  'orders/fetchByNumber',
  async (orderNumber) => {
    const results = await getOrderByNumber(orderNumber);
    return results.data as Order;
  },
);

export const reorder = createAsyncThunk<Basket, Order>('orders/reorder', async (order) => {
  const { partner, number } = order;

  Analytics.logEvent('REORDER');

  const results = await apiReorder({
    merchantId: partner.id,
    orderNumber: number,
  });

  return results.data as Basket;
});

export const ordersAdapter = createEntityAdapter<Order>({
  selectId: (order) => order.number,
});

interface IOrdersSlice {
  loading: boolean;
  total?: number;
}
const initialState = ordersAdapter.getInitialState<IOrdersSlice>({
  loading: true,
  total: undefined,
});

export const merchantsSlice = createSlice({
  name: 'merchants',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchOrders.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchOrders.fulfilled, (state, { payload }) => {
      const { data, total } = payload;

      state.total = total;
      state.loading = false;
      ordersAdapter.setAll(state, data);
    });
    builder.addCase(fetchOrders.rejected, (state) => {
      state.loading = false;
    });

    builder.addCase(fetchMoreOrder.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchMoreOrder.fulfilled, (state, { payload }) => {
      state.loading = false;
      ordersAdapter.addMany(state, payload);
    });
    builder.addCase(fetchMoreOrder.rejected, (state) => {
      state.loading = false;
    });

    builder.addCase(fetchOrderByNumber.fulfilled, (state, { payload }) => {
      ordersAdapter.upsertOne(state, payload);
    });
  },
});

export const {} = merchantsSlice.actions;

export default merchantsSlice.reducer;

// Selectors

export const {
  selectById: selectOrderById,
  selectIds: selectOrderIds,
  selectEntities: selectOrderEntities,
  selectAll: selectAllOrders,
  selectTotal: selectTotalOrders,
} = ordersAdapter.getSelectors((state: RootState) => state.orders);

export const selectOrdersLoading = (state: RootState) => state.orders.loading;

export const selectHasMoreProducts = (state: RootState) => {
  const ordersLength = selectTotalOrders(state);
  const total = state.orders.total;

  return !!total && ordersLength < total;
};
