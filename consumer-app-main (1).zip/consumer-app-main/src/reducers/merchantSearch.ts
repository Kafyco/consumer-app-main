import {
  createSlice,
  createAsyncThunk,
  createEntityAdapter,
  createSelector,
} from '@reduxjs/toolkit';
import { Product } from 'api/models';
import { getMerchantProducts } from '../api';
import { RootState } from '../store';

type FetchAllResultType = {
  data: Product[];
  total: number;
};

/**
 * Will fetch products with provided params
 */
export const fetchSearchResults = createAsyncThunk<
  FetchAllResultType,
  {
    search: string;
    merchantId: number | string;
    count?: number;
  },
  { state: RootState }
>('merchantSearch/fetchAll', async ({ merchantId, search, count }, { dispatch }) => {
  dispatch(clearSearchResults());
  dispatch(setParams({ merchantId, search }));

  const result = await getMerchantProducts({ merchantId, search }, { limit: count });

  return {
    data: result.data,
    total: result.headers['totalcount'],
  } as FetchAllResultType;
});

/**
 * Will fetch next batch of products with previous params
 */
export const fetchMoreResults = createAsyncThunk<
  Product[],
  { count?: number },
  { state: RootState }
>('merchantSearch/fetchMore', async ({ count }, { getState }) => {
  const state = getState();
  const { params } = state.products;
  const totalProducts = selectTotalResults(state);

  const result = await getMerchantProducts(params, {
    limit: count,
    offset: totalProducts,
  });

  return result.data as Product[];
});

export const resultsAdapter = createEntityAdapter<Product>();

// Slice

type InitialStateType = {
  loading: boolean;
  hasMore: boolean;
  params: any;
  total: number | undefined;
};

const initialState = resultsAdapter.getInitialState<InitialStateType>({
  loading: false,
  hasMore: true,
  params: undefined,
  total: undefined,
});

export const merchantSearchSlice = createSlice({
  name: 'merchantSearch',
  initialState,
  reducers: {
    clearSearchResults: (state) => {
      resultsAdapter.removeAll(state);
      state.total = undefined;
    },
    setParams: (state, { payload }) => {
      state.params = payload;
    },
    setHasMore: (state, { payload }) => {
      state.hasMore = payload;
    },
  },
  extraReducers: (builder) => {
    // FetchAll
    builder.addCase(fetchSearchResults.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchSearchResults.fulfilled, (state, { payload }) => {
      const { data, total } = payload;
      resultsAdapter.setAll(state, data);
      state.total = total;
      state.loading = false;
    });

    // FetchMore
    builder.addCase(fetchMoreResults.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchMoreResults.fulfilled, (state, { payload }) => {
      resultsAdapter.addMany(state, payload);
      state.loading = false;
    });
  },
});

export const { clearSearchResults, setParams, setHasMore } = merchantSearchSlice.actions;

export default merchantSearchSlice.reducer;

// Selectors

export const {
  selectById: selectResultById,
  selectIds: selectResultsIds,
  selectEntities: selectResults,
  selectAll: selectAllResults,
  selectTotal: selectTotalResults,
} = resultsAdapter.getSelectors((state: RootState) => state.merchantSearch);

export const selectResultsLoading = (state: RootState) => {
  return state.merchantSearch.loading;
};

export const selectMerchantsSearchTotal = (state: RootState) => state.merchantSearch.total;
export const selectHasMoreResults = createSelector(
  [selectTotalResults, selectMerchantsSearchTotal],
  (totalResults, total) => !!total && totalResults < total,
);
