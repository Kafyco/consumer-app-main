import { Dimensions } from 'react-native';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export const SPRING_SIZE = 120;

export default {
  window: {
    width,
    height,
  },
  isSmallDevice: width < 375,
  screenPadding: 12,
};
