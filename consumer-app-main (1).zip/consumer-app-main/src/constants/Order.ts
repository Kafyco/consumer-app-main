export const ORDER_PLACED = 'Placed';
export const ORDER_IN_PROGRESS = 'In progress';
export const ORDER_DISPATCHED = 'Dispatched';
export const ORDER_DELIVERED = 'Delivered';
export const ORDER_CANCELED = 'Canceled';
export const ORDER_FAILED = 'Delivery failed';

export const ORDER_PIPELINE = [ORDER_PLACED, ORDER_IN_PROGRESS, ORDER_DISPATCHED, ORDER_DELIVERED];

export const ORDER_STATUSES_COMPLETE = [ORDER_DELIVERED, ORDER_CANCELED, ORDER_FAILED];
