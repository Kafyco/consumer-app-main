const tintColorLight = '#2f95dc';
const tintColorDark = '#fff';

export const white = '#fff';
export const black = '#000';
// export const primary = '#125F52';
export const primary = '#B62126';
export const success = '#125F52';
export const warning = '#BC782A';
export const danger = '#A92E20';
export const disabled = 'rgba(0,0,0,0.25)';

export default {
  primary,
  success,
  warning,
  danger,
  disabled,
  black,
  white,
  light: '#DEDEDE',
  brand: primary,
  splash: '#D70216',
  placeholder: '#919191',
  background: '#F0F2F2',
  // background: '#EDEDE1',
  heading: '#393A3B',
  text: '#393A3B',
  'text-regular': '#393A3B',
  'text-primary': primary,
  'text-secondary': '#787878',
  'text-success': success,
  'text-warning': warning,
  'text-danger': danger,
  'text-disabled': disabled,
  'text-white': white,
};
