export const CARD_PAYMENT_CODES = ['stripe', 'paytabs'];
export const ACTIVE_CARD_PAYMENT_CODES = ['stripe'];
