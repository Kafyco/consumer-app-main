export const landingBackground =
  'https://images.unsplash.com/photo-1540331547168-8b63109225b7?auto=format&fit=crop&w=1280&q=51';

export default {
  imageUrls: [landingBackground],
  fonts: [
    { phosphor: require('assets/fonts/Phosphor.ttf') },
    { 'lora-semi-bold': require('assets/fonts/Lora-SemiBold.ttf') },
    {
      'lora-semi-bold-italic': require('assets/fonts/Lora-SemiBoldItalic.ttf'),
    },
    { 'lato-regular': require('assets/fonts/Lato-Regular.ttf') },
    { 'lato-semi-bold': require('assets/fonts/Lato-SemiBold.ttf') },
    { 'lato-medium': require('assets/fonts/Lato-Medium.ttf') },
    { 'lato-bold': require('assets/fonts/Lato-Bold.ttf') },
  ],
};
