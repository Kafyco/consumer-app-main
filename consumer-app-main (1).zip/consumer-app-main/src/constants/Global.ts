export const SUPPORT_EMAIL = 'support@kafy.co';
export const SUPPORT_PHONE_NUMBER = null;
export const SUPPORT_PHONE_NUMBER_TEXT = null;
