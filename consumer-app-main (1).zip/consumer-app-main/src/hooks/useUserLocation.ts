import { useState, useEffect, useRef } from 'react';
import * as Location from 'expo-location';

type UseUserLocationReturn = Location.LocationObject | undefined;

export default function useUserLocation(): UseUserLocationReturn {
  const [loc, setLoc] = useState<Location.LocationObject>();
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;

    const getUserLocation = async () => {
      let location = await Location.getLastKnownPositionAsync();

      // Return rough location if known
      if (location && isMountedRef.current) {
        setLoc(location);
      }

      // Specify exact location after.
      location = await Location.getCurrentPositionAsync();
      if (isMountedRef.current) {
        // setLoc(location);
      }
    };

    const requestLocationPermission = async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();

      if (status === 'granted') {
        getUserLocation();
      }
    };

    const checkLocationPermission = async () => {
      const { status } = await Location.getForegroundPermissionsAsync();

      if (status === 'granted') {
        getUserLocation();
      } else {
        requestLocationPermission();
      }
    };

    checkLocationPermission();

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return loc;
}
