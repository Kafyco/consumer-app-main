import * as React from 'react';
import { Platform } from 'react-native';
import { registerExpoPushToken } from 'utils/expoPushToken';
import * as Notifications from 'expo-notifications';

import useNotificationsPermissionStatus from 'hooks/useNotificationsPermissionStatus';
import useSelector from 'hooks/useSelector';
import useDispatch from 'hooks/useDispatch';
import { selectAuthResolutionFlag, setNotificationsStatus } from 'reducers/app';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const useAppStartupEffect = () => {
  const dispatch = useDispatch();
  const notificationsStatus = useNotificationsPermissionStatus();
  const isAuthStateReloved = useSelector(selectAuthResolutionFlag);

  // ---

  if (Platform.OS === 'android') {
    Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#D702167C',
    });
  }

  React.useEffect(() => {
    dispatch(setNotificationsStatus(notificationsStatus));
  }, [notificationsStatus]);

  React.useEffect(() => {
    if (isAuthStateReloved && notificationsStatus === 'granted') {
      registerExpoPushToken();
    }
  }, [notificationsStatus, isAuthStateReloved]);
};

export default useAppStartupEffect;
