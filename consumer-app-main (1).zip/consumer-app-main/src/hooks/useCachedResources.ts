import React, { useState, useEffect } from 'react';
import { Image } from 'react-native';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';

export type UseCachedResourcesParams = {
  imageUrls?: Array<string>;
  images?: Array<number | string>;
  videos?: Array<number | string>;
  fonts?: Array<any>;
};

export default function useCachedResources({
  fonts = [],
  imageUrls = [],
  images = [],
  videos = [],
}: UseCachedResourcesParams) {
  const isAny = !!(fonts.length || images.length || videos.length);
  const [isLoadingComplete, setLoadingComplete] = useState(!isAny);

  useEffect(() => {
    function loadResourcesAndDataAsync() {
      return Promise.all([
        ...cacheFonts(fonts),
        ...remoteImages(imageUrls),
        ...cacheImages(images),
        ...cacheVideos(videos),
      ])
        .catch((e) => {
          console.warn('Error while loading resources `useCachedResources`:');
          console.warn(e);
        })
        .finally(() => {
          setLoadingComplete(true);
        });
    }

    if (isAny) {
      loadResourcesAndDataAsync();
    }
  }, [fonts, images, videos]);

  return isLoadingComplete;
}

function remoteImages(images: Array<string>): Array<Promise<any>> {
  return images.map((image) => Image.prefetch(image));
}

function cacheImages(images: Array<number | string>): Array<Promise<any>> {
  return images.map((image) => Asset.fromModule(image).downloadAsync());
}

function cacheVideos(videos: Array<number | string>): Array<Promise<any>> {
  return videos.map((video) => Asset.fromModule(video).downloadAsync());
}

function cacheFonts(fonts: Array<any>): Array<Promise<void>> {
  return fonts.map((font) => Font.loadAsync(font));
}
