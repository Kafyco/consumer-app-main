import { useState, useEffect } from 'react';
import { Image } from 'react-native';

export default function usePrefetchImages(images: Array<string>) {
  const [isLoadingComplete, setLoadingComplete] = useState<Boolean>(false);

  useEffect(() => {
    Promise.all(images.map((url) => Image.prefetch(url))).finally(() => {
      setLoadingComplete(true);
    });
  }, [images]);

  return isLoadingComplete;
}
