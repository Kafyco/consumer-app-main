import * as React from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

export type NotificationsPermisionsStatus = 'granted' | 'denied' | undefined;

const useNotificationsPermissionStatus = (): NotificationsPermisionsStatus => {
  const [status, setStatus] = React.useState<NotificationsPermisionsStatus>();

  React.useEffect(() => {
    const checkPermissionStatus = async () => {
      if (Device.isDevice) {
        const notificationPermision = await Notifications.getPermissionsAsync();

        if (
          notificationPermision.granted ||
          notificationPermision.ios?.status === Notifications.IosAuthorizationStatus.PROVISIONAL
        ) {
          // Permisions granted.
          setStatus('granted');
        } else if (
          (notificationPermision.status === 'denied' ||
            notificationPermision.ios?.status === Notifications.IosAuthorizationStatus.DENIED) &&
          !notificationPermision.canAskAgain
        ) {
          // Notificaitons are not allowed and we can't ask permisions again.
          setStatus('denied');
        }
        // Leave user on current screen to promt permisions.
      } else {
        console.log('Must use physical device for Push Notifications');
        setStatus('denied');
      }
    };
    checkPermissionStatus();
  }, []);

  return status;
};

export default useNotificationsPermissionStatus;
